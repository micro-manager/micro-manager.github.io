//////////////////////////////////////////////////////////////////////
//	7.7.2004
//  Copyright 2005. Instrutech Corp.
//	Control Codes
//////////////////////////////////////////////////////////////////////

#ifndef __itcusb_h_	//ignore whole file, if already processed
#define __itcusb_h_

#define _USB_REINITIALIZE		0xB7			// re-initialize, call TD_Init( );

#define _USB_GETBOX_INFO		0xC5			// read REVCTL-Version-Speed-SERIALNUMBER register

#define _USB_READ_ROM4_N_TIMES		0xD0
#define _USB_GET_FIFO_STATUS		0xD1
#define _USB_WAIT_TXHEM			0xD2

#define _USB_START			0xD3			// ITC Start
#define _USB_STOP			0xD4			// ITC Stop
#define _USB_GETFIFOOVERFLOW		0xD5			// ITC GetFIFOOverflow
#define _USB_SETSAMPLING		0xD6			// ITC SetSampling
#define _USB_SETSSEQUENCE		0xD7			// ITC SetSequence
#define _USB_GETFIFOPOINTER		0xD9			// ITC Get FIFO Pointer
#define _USB_READ_SCSI_PORTC		0xDA			// Read SCSI Port "C"

#define _USB_WRITE_SCSI_PORTC		0xDB			// Write SCSI Port "C"
#define _USB_SET_RESET_USER_LINE 	0xDC			// Set/Reset User Line

#define _USB_READ_EEPROM		0xDD			// Read One EPROM location

#define _USB_INITIALIZE_ACQ		0xDE			// Initialize Acquisition
#define _USB_READ_LIFETIMER		0xDF			// Read LifeTimer

#define _USB_READ_S_TIMER		0xE0			// Read Start/Stop Timers
#define _USB_CONTROL_TIMERS		0xE1			// Control Timer 1/2
#define _USB_EXTERNAL_TRIGGER		0xE2			// Start by external trigger
#define _USB_START_BY_TIMER		0xE3			// Start by timer
#define _USB_IS_CLIPPING		0xE4			// Is Clipping?
#define _USB_STOP_INITIALIZE		0xE5			// StopAndInitialize
#define _USB_SETUP_ACQUISITON		0xE6			// SetupAcquisition
#define _USB_SMALL_RUN			0xE7			// SmallRun
#define _USB_SET_MODE			0xE8			// Set Mode
#define _USB_WRITE_ROM3			0xE9			// Setup to "Write ROM3"
#define _USB_A_WRITE_ROM3		0xEA			// Actual Single Write ROM3 or ROM4
#define _USB_GET_SIGNATURE		0xEB			// Get ITC18 Signature
#define _USB_A_READ_ROM4		0xEC			// Actual Single Read ROM4
#define _USB_READ_FIFO_S		0xED			// ReadFIFO (small amount)
#define _USB_WRITE_AUX_OUT		0xEE			// ITC18_WriteAuxiliaryDigitalOutput

#endif //__itcusb_h_