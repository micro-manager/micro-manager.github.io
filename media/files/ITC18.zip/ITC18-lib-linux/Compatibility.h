
#ifndef BYTE
#define BYTE char
#endif

#ifndef UBYTE
#define UBYTE unsigned char
#endif

#ifndef WORD
#define WORD short
#endif

#ifndef UWORD
#define UWORD unsigned short
#endif

#ifndef DWORD
#define DWORD int
#endif

#ifndef UDWORD
#define UDWORD unsigned int
#endif

#ifndef LONG
#define LONG long
#endif

#ifndef ULONG
#define ULONG unsigned long
#endif

#ifndef LONGLONG
#define LONGLONG long long
#endif

#ifndef MAX_PATH
#define MAX_PATH PATH_MAX
#endif 

//#ifndef ZeroMemory
//#define ZeroMemory(a,b) bzero(a, b);
//#endif

#ifndef max
#define max(a, b) (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a, b)  ((a) < (b) ? (a) : (b))
#endif

#ifndef CopyMemory
#define CopyMemory(a,b,c)	memcpy((a),(b),(c))
#endif


