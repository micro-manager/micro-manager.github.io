To use this library, the USB18 must be readable by the user. This depends up the linux distribution you are using.

For our distribution, it requires writing a udev rule"
echo "ATTRS{idVendor}=="1482", ATTRS{idProduct}=="0011", MODE="0666" > /etc/udev/rules.d/itc18.rules

Karl Bellve
Biomedical Imaging Group
University of Massachusetts
Karl.Bellve@umassmed.edu