//  Interface procedures for the Instrutech ITC18.
//
//  Copyright (c) 1991 - 2002 Instrutech Corporation, Port Washington, NY, USA
//
//  Created by Bruxton Corporation, Seattle, WA, USA and Instrutech Corporation

/// *** Released under the Gnu Lesser Public License ***

/* This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// Modified by David J. Perkel, University of Washington
// perkel@u.washington.edu
// to support operation under Linux
// All Macintosh and Windows-specific code removed Feb. 8, 2000 -- DJP
// removed all code that didn't support the driver using USB18 under Linux, April 1, 2009 -- kdb
// Karl.Bellve@umassmed.edu

#ifdef __linux__
#define _LINUX
#endif

/* #include "ITC18_IOCtl.h"
#endif 

#include <slots.h> */

#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <libusb-1.0/libusb.h>
#include <unistd.h> // for usleep
#include "itc18_ioctl.h"
#include <stdlib.h>
#define TIMEOUT_ONE_SEC 1000 // this is in millseconds

// Platforms: _WINDOWS, __APPLE__ (MacOSX), _MACINTOSH (machintosh) = __powerpc & __nubus
//STUB: Mike: what is NUBUS definition???

#ifdef macintosh
	#define _MACINTOSH
	#include <stdlib.h>
	#include "Compatibility.h"
#endif

#ifdef __APPLE__
	#undef _MACINTOSH
	#undef __powerc
	#include <ApplicationServices/ApplicationServices.h>
	#include <unistd.h>

	#include <stdio.h>
	#include <ppc/limits.h>
	#include <mach/mach.h>
	#include <CoreFoundation/CoreFoundation.h>
	#include <IOKit/IOKitLib.h>
	#include <time.h>
	#include <fcntl.h>	//For O_RDONLY in XCode 2.1
	//USB
	#include <IOKit/IOCFPlugIn.h>
	#include <IOKit/usb/IOUSBLib.h>

	#include "Compatibility.h"
	
//	#include <OSAtomic.h>	//eieio

	enum {kITC18_Regs};
        enum
        {
        kITC18ConfigRead,
        kITC18ConfigWrite,
        kITC18IORead,
        kITC18IOWrite,
        kITC18GetVersion,
        kITC18AllocateMemory,
        kITC18FreeMemory,
		kITC18SetRegistry,
		kITC18GetRegistry,
        kITC18NumberOfMethods
        };
        enum
        {
        kUSB18GetVersion,
        kUSB18AllocateMemory,
        kUSB18FreeMemory,
		kUSB18SetRegistry,
		kUSB18GetRegistry,
        kUSB18NumberOfMethods
        };
#endif // __APPLE__

#ifdef _WINDOWS
	#include <windows.h>
	#include <winioctl.h>
	#include <io.h>					//For _access
	#include <stdio.h>				//For Loading USB
	#include "ITC18_IOCtl.h"
#endif

#ifdef _MACINTOSH
	#include <errors.h>
	#include <files.h>
	#include <folders.h>
	#include <gestalt.h>
	#include <timer.h>

	#ifdef __powerc
		#include <Devices.h>
		#include <Interrupts.h>
		#include <DriverServices.h>
	#endif

	#include <slots.h>
	#ifdef __powerc
		#include <PCI.h>
		#include "NameRegistry.h"
		#include "CodeFragments.h"
	#endif
#endif

#ifdef __linux__
    #include <limits.h>
    #include "Compatibility.h" 
    #include <sys/time.h>
#endif

#include "ITC18.h"
#include "fifodcod.h"
#include "ITC18_LCA.h"

#define _USB_OUTPUT_TRANSFER_SIZE_18_	64 * 1024 * 2
#define __USE_USB_COMMANDS__

#define ITC18_VENDOR_ID 0x1482
#define ITC18_PRODUCT_ID 0x0011

#define	PCI18_DEVICE_TYPE		0
#define	USB18_DEVICE_TYPE		1

#define USB18_ROM3_PORT				0

#define USB18_PIPE1_IN			5
#define USB18_PIPE1_OUT			4
#define USB18_ROM3_PIPE			2
#define USB18_ROM4_PIPE			1
#define USB18_ROM4_PIPE_READ		0

#define USB18_PIPE1_IN_LIBUSB		0x81	/* EP 1 IN  */  
#define USB18_PIPE1_OUT_LIBUSB		0x01	/* EP 1 OUT */
#define USB18_ROM3_PIPE_LIBUSB		0x08	/* EP 8 OUT */
#define USB18_ROM4_PIPE_LIBUSB		0x06	/* EP 6 OUT */
#define USB18_ROM4_PIPE_READ_LIBUSB	0x82	/* EP 2 IN  */

#define CTRL_IN		(LIBUSB_RECIPIENT_DEVICE | LIBUSB_REQUEST_TYPE_VENDOR | LIBUSB_ENDPOINT_IN)
#define CTRL_OUT	(LIBUSB_RECIPIENT_DEVICE | LIBUSB_REQUEST_TYPE_VENDOR | LIBUSB_ENDPOINT_OUT)

#include "itcusb.h"
#include "Instr_U2F.h"

// ITC18_STATUS values
//
// Functions that return a value generally return an ITC18_STATUS value.
// If a function succeeds, it returns ITC18_STATUS_SUCCESS. Note that
// ITC18_STATUS_SUCCESS is guaranteed to be zero. All other values
// represent errors.

enum
{
	ITC18_STATUS_SUCCESS = 0,

	// Status values are in alphabetical order. Please keep them that way.

	ITC18_STATUS_BOARD_NOT_FOUND,
	ITC18_STATUS_CREATE_RESERVE_FILE,
	ITC18_STATUS_DRIVER_OPEN,
	ITC18_STATUS_FIFO_OVERFLOW,
	ITC18_STATUS_FIFO_UNDERFLOW,
	ITC18_STATUS_GET_VERSION,
	ITC18_STATUS_OPEN_REGISTRY_KEY,
	ITC18_STATUS_OPEN_RESERVE_FILE,
	ITC18_STATUS_PCI_NOACCESS,
	ITC18_STATUS_PCI_NOLINK,
	ITC18_STATUS_PCI_NOMAP,
	ITC18_STATUS_PREFERENCES_FOLDER,
	ITC18_STATUS_READ_ERROR,
	ITC18_STATUS_READ_INVALID,
	ITC18_STATUS_READ_LENGTH,
	ITC18_STATUS_RELEASE,
	ITC18_STATUS_RESERVE,
	ITC18_STATUS_ROM_INVALID_ADDRESS,
	ITC18_STATUS_ROM_WRITE,
	ITC18_STATUS_SET_PORT,
	ITC18_STATUS_SIGNATURE_INTERFACE,
	ITC18_STATUS_SIGNATURE_ISOLATED,
	ITC18_STATUS_SIGNATURE_LOADER,
	ITC18_STATUS_TXHEM_TIMEOUT,
	ITC18_STATUS_UNKNOWN_STATUS,
	ITC18_STATUS_VALUE_MODEL_VARIANT,
	ITC18_STATUS_WRITE_ERROR,
	ITC18_STATUS_WRITE_INVALID,
//  Mike
	ITC18_STATUS_PCI_NOMULTIPLE,  	//29
	ITC18_STATUS_NO_MEMORY,
	ITC18_STATUS_NOT_IMPLEMENTED,
	ITC18_STATUS_ROM_NOT_SUPPORTED,
	ITC18_STATUS_ROM_TIMEOUT,
	ITC18_STATUS_USB_NOT_SUPPORTED,
	ITC18_STATUS_USB_ERROR,
	ITC18_STATUS_USB_BOARD_NOT_FOUND,
	ITC18_STATUS_USB_OLD_VERSION,
	ITC18_STATUS_USB_ONLY

};


// Structure ITC18
//
// This structure defines an ITC18 to the driver.
//
// Port is the ITC18 I/O port base address.
//
// DataRead is the number of data points read from the FIFO since the start
// of acquisition. It is reset to zero each time acquisition is started.
//
// DataWritten is the number of data points written to the FIFO since the
// start of acquisition. It is reset to zero each time WriteFIFOReset is
// called.

#include "ITC18Structure.h"

#define MAJOR_VERSION	6
#define MINOR_VERSION	12
#define DESCRIPTION	"ITC-18 (USB) driver for Linux"
#define DATE		"March 30, 2009"

typedef struct
	{
	long major_version;
	long minor_version;
	char description[80];
	char date[80];
	}
version_struct;

// ITC18 Hardware parameters
#define INTERFACE_LCA_SIZE 8064
#define ISOLATED_LCA_SIZE 11904
#define LOADER_SIGNATURE 0x3c
#define ISOLATED_SIGNATURE 0x3c
#define INTERFACE_SIGNATURE 0x3b

#define ITC18_1M_FIFO (1024*1024)
#define ITC18_256K_FIFO (256*1024)

#define ROM_FIFO_SIZE_MASK 0x00000001
#define ROM_FIFO_SIZE 3
#define ROM_WRITE_RETRY 3

// Offsets from the base port address.
// updated 6/26/02 TG

#define PORT_LATCH 	0x0
#define PORT_DATA 	0x4
#define PORT_PCI 	0x8
#define PORT_PCI_DATA 	0xA

// ITC18 Control and Data Registers
//
// Use these constants to form bitfields where the upper four bits select
// which register is being written to, and the remaining bits are the values
// of the control bits in the register.

// LCA_CONTROL controls the programming of the LCAs.  Note that the LCAs CCLK
// connects to itc->port_data.

#define LCA_CONTROL 	0x8000

#define LC_PROG 	0x0001 // Set to program the LCA.
// This is the data bit when programming the LCA, and the Read control bit.
#define LC_DATA		0x0002
#define LC_RESET 	0x0004
#define LC_CS 		0x0008

// FIFO_CONTROL

#define FIFO_CONTROL 0x4000

#define FC_FIFO_RESET 	0x0000
#define FC_FIFO_ENABLE 	0x0001 // enables FIFO
#define FC_STOP_OVR 	0x0002 // stop acquisition on A/D overflow
#define FC_DA_INHIBIT 	0x0004 // stop acquisition on D/A underflow

// ACQ_CONTROL

#define ACQ_CONTROL 			0x2000

#define AC_STOP_ACQ 			0x0000
#define AC_START_ACQ 			0x0001
#define AC_ACQ_ON_TRIGGER 		0x0002
#define AC_INVERT_DIGITAL_INPUTS	0x000C
#define AC_READY_LIGHT_OFF 		0x0010
#define AC_READY_LIGHT_ON 		0x0011
#define AC_LATCH_ENABLE 		0x0012
#define AC_EXTERNAL_CLOCK 		0x0018
#define AC_EXTERNAL_TRIGGER_INVERT 	0x0024
#define AC_EXTERNAL_TRIGGER_TRANSITION 	0x0028
#define AC_BANK_SELECT 			0x0030
#define AC_DAC_SHIFT 			0x0080

// 0x002x and 0x003x are reserved, do not use

// OR the selected nibble's timer data into the lower four bits when using
// the AC_SEND_TIMER masks.

#define AC_SEND_TIMER_N0 0x0040
#define AC_SEND_TIMER_N1 0x0050
#define AC_SEND_TIMER_N2 0x0060
#define AC_SEND_TIMER_N3 0x0070

// OR the selected nibble's sequence RAM data into the lower four bits when
// using the AC_SEND_SEQL masks.

#define AC_SEND_SEQL_N0 0x0080
#define AC_SEND_SEQL_N1 0x0090
#define AC_SEND_SEQL_N2 0x00a0

// This writes the previously loaded data into the sequence RAM and advances the
// sequencer pointer.  The sequencer write operation must be preceded by a write
// of 0x2000 to COMMAND_PORT to stop acquisition and perform a sequencer reset.

#define AC_SEQ_WRITE 0x00b0

// DATA_SELECT and its control bits determine where the data written to or read
// from itc->port_data goes to or came from. The EPC-9 clipping bit may also be
// accessed.

#define DATA_SELECT 0x1000

#define DS_READ_FIFO_DATA 	0x0000
#define DS_READ_FIFO_PTR 	0x0001 // low 16 bits only, upper 4 in status word
#define DS_READ_STATUS 		0x0002 // bits 0...3 are bits 15...19 of the FIFO pointer
#define DS_WRITE_FIFO_DATA 	0x0003
#define DS_CLIPPING_RESET 	0x0006

#define STATUS_RORERR 		0x8000
#define STATUS_TURERR 		0x4000
#define STATUS_CLIPERR 		0x2000
// reserved do not use 	0x1000
#define STATUS_TXHEM 		0x0800
// bits 4 through 10 access the LCAs' signatures
// bits 0 through 3 access bits 16 through 19 of the FIFO pointer.

// PCI control fields

#define PCI_SWAP 0x0008
#ifdef __linux
void Delay(unsigned long, unsigned long *microseconds);
#endif
int DelayXYZ(void* device, int microseconds);
int WaitROM(void* device, int address);
int SetROMMode(void* device, int mode);
int GetROMSoftID(void* device, unsigned* SoftID);
int ITC18_WaitPCIROM(void* device, int address);
int ITC18_SetPCIROMMode(void* device, int mode);
int ITC18_GetPCIROMSoftID(void* device, unsigned* SoftID);

// Function local_strcpy( char* target, char* source, int length)
//
// Do not use the standard "C" "strcpy", since this would pull in the 
// C library, which may not be desired.
// TG 6/27/2000

static void local_strcpy(char* target, char* source, int length);

void local_strcpy(char* target, char* source, int length)
{
	while ((--length > 0) && (*source != '\0'))
	{
		*target++ = *source++;
	}

	*target = '\0';
}


// Function ITC18_GetStatusText
//
// Return a status value as a text string in "text". The
// array "text" contains "length" characters.

ITC_CALL int ITC18_GetStatusText(void* device, int status, char* text, int length)
{
	char* message;

	int result = ITC18_STATUS_SUCCESS;

	switch (status)
	{
	case ITC18_STATUS_SUCCESS:
		message = "Success";
		break;
	case ITC18_STATUS_BOARD_NOT_FOUND:
		message = "ITC-18 Interface could not be located.";
		break;

	case ITC18_STATUS_CREATE_RESERVE_FILE:
		message = "Unable to create the reserve file.";
		break;

	case ITC18_STATUS_DRIVER_OPEN:
//Mike: This message may have "Hardware missing" problem
//		message = "Driver not installed. Please install driver.";
		message = "Driver or host interface card not installed.";
		break;

	case ITC18_STATUS_FIFO_OVERFLOW:
		message = "Input FIFO overflow. Data acquisition too fast for program.";
		break;

	case ITC18_STATUS_FIFO_UNDERFLOW:
		message = "Input FIFO underflow. Internal program error.";
		break;

	case ITC18_STATUS_GET_VERSION:
		message = "GetVersionEx system call failed. Operating system conflict.";
		break;

	case ITC18_STATUS_OPEN_REGISTRY_KEY:
		message = "Driver registry entry missing. Please install driver.";
		break;
	
	case ITC18_STATUS_OPEN_RESERVE_FILE:
		message = "Unable to open the reserve file.";
		break;

	case ITC18_STATUS_PCI_NOACCESS:
		message = "Unable to access PCI board using I/O space";
		break;

	case ITC18_STATUS_PCI_NOLINK:
		message = "Unable to link to PCI dynamic libraries";
		break;

	case ITC18_STATUS_PCI_NOMAP:
		message = "Unable to map PCI board I/O into accessable space.";
		break;

	case ITC18_STATUS_PREFERENCES_FOLDER:
		message = "Unable to find the preferences folder.";
		break;

	case ITC18_STATUS_READ_ERROR:
		message = "Read from kernel driver or VxD failed. Internal error.";
		break;

	case ITC18_STATUS_READ_INVALID:
		message = "Read length invalid. Internal error.";
		break;

	case ITC18_STATUS_RELEASE:
		message = "Unable to release the device. The kernel driver may need to be updated.";
		break;

	case ITC18_STATUS_RESERVE:
		message = "Unable to reserve the device. The kernel driver may need to be updated.";
		break;

	case ITC18_STATUS_ROM_INVALID_ADDRESS:
		message = "Invalid ROM address.";
		break;

	case ITC18_STATUS_ROM_WRITE:
		message = "Write to ROM failed.";
		break;

	case ITC18_STATUS_SET_PORT:
		message = "Set port to kernel driver or VxD failed. Internal error.";
		break;

	case ITC18_STATUS_SIGNATURE_INTERFACE:
		message = "Incorrect interface LCA signature. Check device.";
		break;

	case ITC18_STATUS_SIGNATURE_ISOLATED:
		message = "Incorrect isolated LCA signature. Check device.";
		break;

	case ITC18_STATUS_SIGNATURE_LOADER:
		message = "Incorrect loader LCA signature. Check device.";
		break;

	case ITC18_STATUS_TXHEM_TIMEOUT:
		message = "Device TXHEM signal timed out. Device error.";
		break;

	case ITC18_STATUS_UNKNOWN_STATUS:
		message = "Unknown driver status value. Internal error.";
		break;

	case ITC18_STATUS_VALUE_MODEL_VARIANT:
		message = "Incorrect model variant. Please install driver.";
		break;

	case ITC18_STATUS_WRITE_ERROR:
		message = "Write to kernel driver or VxD failed. Internal error.";
		break;

	case ITC18_STATUS_WRITE_INVALID:
		message = "Write length invalid. Internal error.";
		break;

//Mike
	case ITC18_STATUS_PCI_NOMULTIPLE:
		message = "This Driver does not support multiple ITC18's.";
		break;

	case ITC18_STATUS_NO_MEMORY:
		message = "Out of memory.";
		break;

	case ITC18_STATUS_NOT_IMPLEMENTED:
		message = "This function is not implemented.";
		break;
		
	case ITC18_STATUS_ROM_NOT_SUPPORTED:
		message = "ROM is not supported.";
		break;

	case ITC18_STATUS_ROM_TIMEOUT:
		message = "ROM communication error.";
		break;

	case ITC18_STATUS_USB_NOT_SUPPORTED:
		message = "USB-18 Device is not supported.";
		break;
		
	case ITC18_STATUS_USB_ERROR:
		message = "USB-18 communication error";
		break;
		
	case ITC18_STATUS_USB_BOARD_NOT_FOUND:
		message = "USB-18 board not found";
		break;


	default:
		message = "Unknown driver status value. Internal error.";
		result = ITC18_STATUS_UNKNOWN_STATUS;
		break;
	}

	local_strcpy(text, message, length);

	return result;
}



// Function DelayMicroseconds
//
// Perform a delay of at least the specified number of microseconds.

static void DelayMicroseconds(int period)
{
#ifdef _WINDOWS
    int milliseconds;
    OSVERSIONINFO OsVersionInfo;

    milliseconds = (period + 999) / 1000;

    OsVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    
    GetVersionEx(&OsVersionInfo);

    if (OsVersionInfo.dwPlatformId == VER_PLATFORM_WIN32s)
	    {
	    DWORD start = GetTickCount();

	    while (((int) (GetTickCount() - start)) < milliseconds)
		    {
		    Sleep(milliseconds);
		    }
	    } 
    else 
	    {
	    Sleep(milliseconds);
	    }
#endif

#ifdef _MACINTOSH
    volatile TMTask task;

    task.qLink = 0;
    task.qType = 0;
    task.tmAddr = 0;
    task.tmCount = 0;
    task.tmWakeUp = 0;
    task.tmReserved = 0;

    InsXTime((QElemPtr) &task);

    PrimeTime((QElemPtr) &task, -period);

    while (task.qType & 0x8000)
	    {}

    RmvTime((QElemPtr) &task);
#endif

#ifdef __APPLE__

    usleep(period);
/*
    //   IODelay(period);
    int size = 0;
    int args[1];
    args[0] = period;
    kr = io_connect_method_scalarI_scalarO(theconnect, kITC16_DelayMicro,
		args, 1, NULL, &size);
*/
#endif  

#ifdef __linux__
    usleep(period);
#endif

}


// Function ITC18_GetStructureSize
//
// Return the size of the device structure.

ITC_CALL int ITC18_GetStructureSize()
{
	return sizeof(struct ITC18);
}


/* Perkel.  First try at using a new ioctl call that does this transfer
 in a single call.  Hopefully the performance will be better. */
static int OutputWordString_Linux(struct ITC18* itc,int port, int count, short* data)
{
    unsigned char pipeRef;
    int length,status, transferred;  

    length = count * sizeof(short);
    //fprintf(stderr,"OutputWordString_Linux: port = %d, length = %d\n",port,length);
    
    pipeRef = (port == USB18_ROM3_PORT) ? USB18_ROM3_PIPE_LIBUSB : USB18_ROM4_PIPE_LIBUSB;	//ROM3 or ROM4
    if(itc->USBVersion >= 0x00050000 && port == USB18_ROM3_PORT) 
    {
	//Redirect writing to ROM3
	pipeRef = USB18_ROM4_PIPE_LIBUSB;
	//setting up the write
	status = libusb_control_transfer(itc->file,CTRL_OUT,_USB_WRITE_ROM3,0,0,NULL,0,TIMEOUT_ONE_SEC);
	if (status < 0) return ITC18_STATUS_WRITE_ERROR;  
    }

// linux macro to convert data to USB little endian
//    libusb_cpu_to_le16();
// libusb_bulk_transfer should break up the transfer into suitable size chunks, depending upon the OS.
    status = libusb_bulk_transfer(itc->file,pipeRef,(UBYTE *)data,length,&transferred,TIMEOUT_ONE_SEC); 
    if (status < 0) {
	libusb_clear_halt(itc->file,pipeRef);
	fprintf(stderr,"OutputWordString_Linux: libusb_bulk_transfer\n");
	return ITC18_STATUS_WRITE_ERROR;
    }
    if (transferred != length)  {
	fprintf(stderr,"OutputWordString_Linux: failed to transfer %d bytes out of %d \n",length-transferred,length);
	return ITC18_STATUS_WRITE_ERROR;
    }

    if(itc->USBVersion >= 0x00050000 && port == USB18_ROM3_PORT) 
    {
	status = libusb_control_transfer(itc->file,CTRL_OUT,_USB_WRITE_ROM3,1,0,NULL,0,TIMEOUT_ONE_SEC);
	if (status < 0) return ITC18_STATUS_WRITE_ERROR;
    }

    return ITC18_STATUS_SUCCESS;
}


static int InputWordString_Linux(struct ITC18* itc, int port, int count, short *data)
{
    int length;
    int i, j, k;
    int status;
    int transferred;   
    int temp, temp_left;
    unsigned char *tempdata = (unsigned char *)data;
    short* shorttempdata = data;
    unsigned char pipeRef;
    unsigned int transfersize;
    unsigned char databuffer[512];

    length = count * sizeof(short);

    pipeRef = USB18_ROM4_PIPE_READ_LIBUSB;	//Read only from ROM4. Pipe 0.
#ifdef DEBUG
    fprintf(stderr,"InputWordString_Linux: port = %d, length = %d\n",port,length);
#endif
    if(itc->USBVersion >= 0x00060000) {
	if(length <= 64) {   //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	    #ifdef DEBUG
	    fprintf(stderr, "InputWordString_Linux: length %d\n",length);
	    #endif
	    status = libusb_control_transfer(itc->file,CTRL_IN,_USB_READ_FIFO_S,length,itc->ByteOrderFlag,(unsigned char*)data,length,TIMEOUT_ONE_SEC);
	    if (status < 0) {
		fprintf(stderr,"InputWordString_Linux: 1 libusb_control_transfer %d\n",status);
		return ITC18_STATUS_READ_ERROR;  
	    }
	}
	else {
	    transfersize = 64*1024;		//64K limitation
	    temp = length / transfersize;	//Number of Bytes
	    k = 0;
	    #ifdef DEBUG
	    fprintf(stderr, "InputWordString_Linux: temp %d, length %d, transfersize %d\n",temp, length, transfersize);
	    #endif
	    for(i = 0; i < temp; i++) {
		status = libusb_control_transfer(itc->file,CTRL_OUT,_USB_READ_ROM4_N_TIMES,transfersize << 15,transfersize >> 1,NULL,0,TIMEOUT_ONE_SEC);
		if (status < 0) return ITC18_STATUS_READ_ERROR; 
		status =  libusb_bulk_transfer(itc->file,pipeRef,tempdata,transfersize,&transferred,TIMEOUT_ONE_SEC);
		if (status != 0) {
		    fprintf(stderr,"InputWordString_Linux: 2 libusb_bulk_transfer %d\n",status);
		    libusb_clear_halt(itc->file,pipeRef);
		    return ITC18_STATUS_READ_ERROR;
		}
		if(transfersize != 64*1024)
		    return ITC18_STATUS_READ_ERROR;
    
		for(j = 0; j < transfersize; j+=2, k++);
		    data[k] = libusb_cpu_to_le16(*shorttempdata++);		
		tempdata += transfersize;
	    }
	    temp = length % transfersize; //Number of bytes (always even)	
	    if(temp != 0) {
		if(temp <= 64) {  //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
 		    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_READ_FIFO_S,(UWORD) temp | (itc->ByteOrderFlag << 16),itc->latch0,tempdata,temp,TIMEOUT_ONE_SEC);
		    if (status < 0) {
			fprintf(stderr,"InputWordString_Linux: 3 libusb_control_transfer %d\n",status);
			return ITC18_STATUS_READ_ERROR;  
		    }
		} else {  //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
		    status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_READ_ROM4_N_TIMES,temp << 15,temp >> 1,NULL,0,TIMEOUT_ONE_SEC);
		    if (status < 0) {
			fprintf(stderr,"InputWordString_Linux: 4 libusb_control_transfer %d\n",status);
			return ITC18_STATUS_READ_ERROR;  
		    }
		    status =  libusb_bulk_transfer(itc->file,pipeRef,tempdata,temp,&transferred,TIMEOUT_ONE_SEC);
		    if (status != 0) {
			fprintf(stderr,"InputWordString_Linux: libusb_bulk_transfer %d, transferred %d out of %d\n",status,transferred,temp);
			libusb_clear_halt(itc->file,pipeRef);
			return ITC18_STATUS_READ_ERROR;
		    }
		    for(j = 0; j < temp; j+=2, k++)
			data[k] = libusb_cpu_to_le16(*shorttempdata++);		
		}
	    }
	}
	return ITC18_STATUS_SUCCESS;
    }

    transfersize = itc->max_transfer_size;
    temp = length / transfersize;
    temp_left = length % transfersize;

    for(i = 0; i < temp; i++) {
	//1. The USB read FIFO is empty. Send command to fill it from the ITC18
	//We should optimize the whole driver to preload the USB FIFO with data
	if(itc->USBVersion < 0x00050002) { //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	    status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_READ_ROM4_N_TIMES,(UWORD) transfersize,0,NULL,0,TIMEOUT_ONE_SEC);
	    if (status < 0) {
		fprintf(stderr,"InputWordString_Linux: 6 libusb_control_transfer %d\n",status);
		return ITC18_STATUS_READ_ERROR; 
	    }
	}
	status =  libusb_bulk_transfer(itc->file,pipeRef,tempdata,transfersize,&transferred,TIMEOUT_ONE_SEC);
	if (status != 0) {
	    libusb_clear_halt(itc->file,pipeRef);
	    return ITC18_STATUS_READ_ERROR;
	}	
	
	tempdata += transfersize;
    }

    if(temp_left != 0) {
	if(itc->USBVersion >= 0x00050003 && temp_left <= 64) {
	    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_READ_FIFO_S,(UWORD) temp_left,itc->ByteOrderFlag,tempdata,temp_left,TIMEOUT_ONE_SEC);
	    if (status < 0) return ITC18_STATUS_READ_ERROR;
	} else {
Repeat:
	    if(itc->USBVersion >= 0x00050002)
		status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_READ_FIFO_S,(UWORD) temp_left >> 1,itc->ByteOrderFlag,tempdata,temp_left,TIMEOUT_ONE_SEC);
	    else
		status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_READ_FIFO_S,(UWORD) temp_left,itc->ByteOrderFlag,tempdata,temp_left,TIMEOUT_ONE_SEC);
	    if (status < 0) return ITC18_STATUS_READ_ERROR;
	    
	    if(itc->USBVersion >= 0x00050002) {
		temp = itc->max_transfer_size;	
		status =  libusb_bulk_transfer(itc->file,pipeRef,databuffer,temp,&transferred,TIMEOUT_ONE_SEC);
	    }
	    else status =  libusb_bulk_transfer(itc->file,pipeRef,tempdata,temp_left,&transferred,TIMEOUT_ONE_SEC);

	    if (status != 0 ) {
		libusb_clear_halt(itc->file,pipeRef);
		i++;
		if (i < 2) goto Repeat;
		else return ITC18_STATUS_READ_ERROR;
	    }
	    if(itc->USBVersion >= 0x00050002)
		for(i = 0; i < temp_left; i++)
		    *tempdata++ = databuffer[i];
	}
    }
	
    for( i = 0; i < count; i++)
	data[i] = libusb_cpu_to_le16(data[i]);

    return ITC18_STATUS_SUCCESS;
}

// Function OutputWord

static int OutputWord(struct ITC18* itc, int port, int value)
{
//	short data = (short) value;
	int status;

	status = ITC18_SingleWriteROM34(itc, port, value);
//	status = itc->output_word_string(itc, port, 1, &data);

	return status;
}


// Function InputWord

static int InputWord(struct ITC18* itc, int port, int* value)
{
   short data;
   int result;

   result = itc->input_word_string(itc, port, 1, &data);

   if (result)
     return result;

   *value = ((int) data) & USHRT_MAX;

   return ITC18_STATUS_SUCCESS;
}


// Function WaitTXHEM
//
// Wait until TXHEM goes high. It this takes longer than the timeout
// period, signal a timeout.

// This function is a bottle neck for the USB. Need global optimization.
// First step. Move this function to 8051	
static int WaitTXHEM(struct ITC18* itc)
{
    int status;
    unsigned char buffer[1];

    if(itc->DeviceType == USB18_DEVICE_TYPE) {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_WAIT_TXHEM,0,0,buffer,1,TIMEOUT_ONE_SEC);
	if (status < 0) {
	    fprintf(stderr,"WaitTXHEM: libusb_control_transfer %d\n",status);
	    return ITC18_STATUS_USB_ERROR;
	}
	if (buffer[0] == 1)
	    return ITC18_STATUS_SUCCESS;
	else
	    return ITC18_STATUS_TXHEM_TIMEOUT;
    }

   return ITC18_STATUS_USB_ERROR;
}

// Function ReadROM
//
// Read a byte from the ROM
// The address must be in the range 0 to 2 * ITC18_ROM_SIZE.
// The control LCA is reset.

static int ReadROM(struct ITC18* itc, int address, int* data)
{
    int status;
    unsigned char buffer[1];

    if(itc->DeviceType == USB18_DEVICE_TYPE) {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_READ_EEPROM, (UWORD)address,0,buffer,1,TIMEOUT_ONE_SEC);
	if (status < 0) return ITC18_STATUS_USB_ERROR;
	*data = (int)buffer[0] & 0x00FF;
	return ITC18_STATUS_SUCCESS;
    }
    else return ITC18_STATUS_USB_ERROR;
}

// Function SerializeToBits
//
// Write a serial bit stream to the isolated LCA.  'data' points to an
// array, which is serialized bit-by-bit (one char becomes CHAR_BIT values)
// and then sent to the port_data. data_bit is a mask indicating which bit
// in the output word represents the LCA program data bit.  timing is
// a value that is written to the LCA in between the data bytes.
//
// Note that this routine differs from BitExplode() in that timing values are
// interleaved with the data, and the output buffer is twice as large to
// accomodate them.

//#define BLOCK_SIZE 256
#define BLOCK_SIZE 32
//define BLOCK_SIZE 512
#define _USE_ITC_SHORT_TRANSFERS_

static int SerializeToBits(struct ITC18* itc, int data_bit, int timing, int length, unsigned char* data)
{
	
    int remaining = length;
    int status;

#ifdef _USE_ITC_SHORT_TRANSFERS_

    short target[BLOCK_SIZE*2*CHAR_BIT];

    // Break the data array into multiple buffers.
    while(remaining > 0) {
	int entries;
	int entry;
																	
	entries = remaining;

	if(entries > BLOCK_SIZE)
	    entries = BLOCK_SIZE;

	remaining -= entries;

	entries *= 2*CHAR_BIT;

	// Fill the outgoing buffer
	entry = 0;

	while(entry < entries)
	    {
	    int bit;
	    int source = *data++;

	    for(bit = 0; bit < CHAR_BIT; ++bit) {
		int program_byte;
		program_byte = 0;

		if(source & 0x01)
			program_byte |= data_bit;

		target[entry] = (short) program_byte;
		++entry;
		target[entry] = (short) program_byte | timing;
		++entry;

		source >>= 1;
	    }
	}

	status = itc->output_word_string(itc, itc->port_data, entries, target);
	if(status != 0)
	    return status;
    }
#else

    //Allocate a big buffer
    short *databuf, *tempbuf;
    int i;
    short data0, data1;

    remaining *= 2 * CHAR_BIT;
    databuf = malloc(remaining * sizeof(short));
    if(databuf == NULL)
	return ITC18_STATUS_NO_MEMORY;

    tempbuf = databuf;
    for(i = 0; i < length; i++)	{
	int bit;
	int source = *data++;

	for(bit = 0; bit < CHAR_BIT; ++bit) {
	    int program_byte;

	    program_byte = 0;

	    if(source & 0x01)
		    program_byte |= data_bit;
		    
	    data0 = (short) program_byte;
	    data1 = (short) program_byte | timing;

	    *tempbuf++ = data0;
	    *tempbuf++ = data1;

	    source >>= 1;
	}
    }

    status = itc->output_word_string(itc, itc->port_data, remaining, databuf);
    if(status != 0)
	return status;

    free(databuf);

#endif

    return ITC18_STATUS_SUCCESS;
}


// Function BitExplode
//
// Write a serial bit stream out to the interface LCA. 'data' points to an
// array, which is serialized into a string bit-by bit (one char becomes
// CHAR_BIT values), then sent to port. 'data_bit' indicates which bit in the
// output word represents the LCA program data bit. 'control_mask' selects the
// port and bits appropriate for programming the LCA.

static int BitExplode(	struct ITC18* itc, int control_mask, int data_bit, int length, unsigned char* data)
{
    int remaining = length;
    int status;

#ifdef _USE_ITC_SHORT_TRANSFERS_

    short target[BLOCK_SIZE*CHAR_BIT];
    
    // Break the data array into multiple buffers.
    while (remaining > 0) {
	int entries;
	int entry;

	entries = remaining;

	if(entries > BLOCK_SIZE)
	    entries = BLOCK_SIZE;

	remaining -= entries;

	entries *= CHAR_BIT;

	// Fill the outgoing buffer
	entry = 0;

	while(entry < entries) {
	    int bit;
	    int source = *data++;
	    int program_byte;

	    for(bit=0; bit < CHAR_BIT; ++bit) {
		program_byte = control_mask;

		if (source & 0x01)
		    program_byte |= data_bit;

		target[entry] = (short) program_byte;

		++entry;

		source >>= 1;
	    }
	}

	status = itc->output_word_string(itc, itc->port_latch, entries, target);
	if(status != 0)
		return status;
    }

#else
    
    //Allocate big buffer
    short *databuf, *tempbuf;
    int i;
    short data0;

    remaining *= CHAR_BIT;
    databuf = malloc(remaining * sizeof(short));
    if(databuf == NULL)
	return ITC18_STATUS_NO_MEMORY;

    tempbuf = databuf;
    for(i = 0; i < length; i++) {
	int bit;
	int source = *data++;
	int program_byte;

	for(bit=0; bit < CHAR_BIT; ++bit) {
	    program_byte = control_mask;

	    if (source & 0x01)
		program_byte |= data_bit;
		    
	    data0 = (short) program_byte;

	    *tempbuf++ = data0;
	    source >>= 1;
	}
    }

    status = itc->output_word_string(itc, itc->port_latch, remaining, databuf);
    if(status != 0)
	return status;

    free(databuf);

#endif
    return ITC18_STATUS_SUCCESS;
}

// Function LoadInterfaceLCA
//
// Program the interface LCA.  If any errors are encountered opening the
// LCA file, checking it's size, or allocating a buffer to read it into,
// exit immediately and return an error code.  BitExplode() does the
// serialization and writing of the serial bit stream.

#define CCLKS_BEFORE_PROG 2
#define CCLKS_AFTER_PROG 4
#define CCLKS_DELAY_PERIOD 5000 // microseconds

static int LoadInterfaceLCA(struct ITC18* itc, unsigned char* data)
{

    int i;
    int status;

//Mike: USB. Add special command to do reset LCA

    // Reset the LCA
    status = OutputWord(itc, itc->port_latch, LCA_CONTROL);
    if(status != 0) {
	fprintf(stderr,"LoadInterfaceLCA: OutputWord %d\n",status);
	return status;
    }

    // Toggle the PROG bit to prepare the Xilinx for programming.
    for(i = 0; i < CCLKS_BEFORE_PROG; ++i) {
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_CS);
	if(status != 0) {
	    fprintf(stderr,"LoadInterfaceLCA: First OutputWord %d\n",status);
	    return status;
	}

	DelayMicroseconds(CCLKS_DELAY_PERIOD);
	
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_CS | LC_PROG);
	if(status != 0) {
	    fprintf(stderr,"LoadInterfaceLCA: Second OutputWord %d\n",status);
	    return status;
	}

	DelayMicroseconds(CCLKS_DELAY_PERIOD);
    }

    // Send the data to the LCA
    status = BitExplode(itc, LCA_CONTROL | LC_PROG, LC_DATA, INTERFACE_LCA_SIZE, data);
    if(status != 0) {
	    fprintf(stderr,"LoadInterfaceLCA: BitExplode %d\n",status);
	    return status;
    }
    // Pulse the clock with the data line high to finish programming the
    // interface Xilinx.

//Mike: USB. Add special command to finish programming.

    for(i = 0; i < CCLKS_AFTER_PROG; ++i) {
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA | LC_CS);
	if(status != 0) {
	    fprintf(stderr,"LoadInterfaceLCA: Third OutputWord %d\n",status);
	    return status;
	}
	DelayMicroseconds(CCLKS_DELAY_PERIOD);
    }

    // Reset the data line to zero
    
    status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_CS | LC_PROG);
    if(status != 0) {
	    fprintf(stderr,"LoadInterfaceLCA: Fourth OutputWord %d\n",status);
	    return status;
    }

    return ITC18_STATUS_SUCCESS;
    
}

// Function GetSignature
//
// Obtain the signature of the LCA just loaded.

static int GetSignature(struct ITC18* itc, int* signature)
{
    int status;
    int data = 0;
    char buffer[2];
    
    buffer[0] = 0;
    buffer[1] = 0;

    // Read the signature from the status bits.
    if(itc->DeviceType == USB18_DEVICE_TYPE) {
	if(itc->USBVersion >= 0x00050000) {
	    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	    status = libusb_control_transfer(itc->file,CTRL_IN,(BYTE)_USB_GET_SIGNATURE, 0,0,(UBYTE *)buffer,2,TIMEOUT_ONE_SEC);
	    if (status < 0) {
		fprintf(stderr,"GetSignature: libusb_control_transfer %d\n",status);
		return ITC18_STATUS_USB_ERROR;
	    }
	    data = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
	}
	*signature = (data >> 4) & 0x007f;

	return ITC18_STATUS_SUCCESS;
    }

    return ITC18_STATUS_USB_ERROR;
}

// Function LoadIsolatedLCA
//
// Program the isolated LCA.  If any errors are encountered opening the
// LCA file, checking its size, or allocating a buffer to read it into,
// exit immediately and return an error code.  SerializeToBits() does the
// serialization and writing of the serial bit stream.
//
// Note that the isolated LCA requires timing bytes to be interleaved with
// the data bytes.  Also see SerializeToBits().

#define ISOLATED_CLOCK_LOW	0x02
#define ISOLATED_CLOCK_HIGH	0x06
#define ISOLATED_PROG_LOW	0x00
#define ISOLATED_PROG_HIGH	0x01
#define ISOLATED_DATA_BIT	0x0002

static int LoadIsolatedLCA(struct ITC18* itc, unsigned char* data)
{
    int i;
    int status;

//Mike: USB. Add special command to reset the LCA

    // Toggle the PROG bit twice to prepare the Xilinx for programming.

    for (i=0; i<2; ++i)
    {
	status = OutputWord(itc, itc->port_data, ISOLATED_PROG_HIGH);

	if (status != 0)
	    return status;

	DelayMicroseconds(10000);

	status = OutputWord(itc, itc->port_data, ISOLATED_PROG_LOW);

	if (status != 0)
	    return status;

	DelayMicroseconds(1000);
    }

    // Send the data to the LCA

    status = SerializeToBits(itc, ISOLATED_DATA_BIT, 0x0004, ISOLATED_LCA_SIZE, data);

    if (status != 0)
	return status;

    // Finish the programming
    status = OutputWord(itc, itc->port_data, ISOLATED_CLOCK_LOW);

    if (status != 0)
	return status;

    for (i=0; i < CCLKS_AFTER_PROG; ++i)
    {
	status = OutputWord(itc, itc->port_data, ISOLATED_CLOCK_HIGH);

	if (status != 0)
	    return status;

	status = OutputWord(itc, itc->port_data, ISOLATED_CLOCK_LOW);

	if (status != 0)
		    return status;
    }

    return ITC18_STATUS_SUCCESS;
}

static int LocateBoard(struct ITC18* itc)
  {
    int status;

    itc->output_word_string = OutputWordString_Linux;
    itc->input_word_string = InputWordString_Linux;
    itc->port_latch = PORT_LATCH;
    itc->port_data = PORT_DATA;

    status = libusb_init(0);
    if (status < 0) {
	perror("LocateBoard: failed to open the initialize lsbusb...");
	return ITC18_STATUS_BOARD_NOT_FOUND;
    }

    itc->file = libusb_open_device_with_vid_pid(NULL,ITC18_VENDOR_ID, ITC18_PRODUCT_ID);
    if (itc->file == NULL) {
	fprintf(stderr,"LocateBoard: failed to open the USB18: %d\n", status );
	return ITC18_STATUS_BOARD_NOT_FOUND;
    }

    status = libusb_claim_interface(itc->file, 0);
    if (status == 0) {	
	return ITC18_STATUS_SUCCESS;
    }

#ifdef DEBUG
    fprintf(stderr,"libusb_set_debug ON\n");
    libusb_set_debug(NULL,3);
#endif
    return ITC18_STATUS_SUCCESS;
}

// Function GetFIFOSize
//
// Read the FIFO size from the ROM.

static int GetFIFOSize(struct ITC18* itc, int* size)
  {
    int size_flag = 0;
    int status = 0;

    // Obtain the FIFO size from the configuration ROM   
    status = ReadROM(itc, ROM_FIFO_SIZE, &size_flag);

    if (status != 0) {
	// Use the default value.
	fprintf(stderr,"GetFIFOSize: ReadROM %d\n",status);
	*size = ITC18_256K_FIFO;
	return ITC18_STATUS_SUCCESS;
    }

    if ((size_flag & ROM_FIFO_SIZE_MASK) != 0){
	// Device has a 1M FIFO
	*size = ITC18_1M_FIFO;
    } else {
	// Device has a 256K FIFO
	*size = ITC18_256K_FIFO;
    }

    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_Initialize
//
// Initialize the device hardware
ITC_CALL int ITC18_Initialize(void* device, int LCA_configuration)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status = 0, signature, i;
    int speed, version;
    int range[ITC18_AD_CHANNELS];
    char key_data[MAX_PATH + 16];
    local_u2f_header needlheader[1];
    char* u2fdatapointer;
    u2fdatapointer = NULL;
    short data[4];	//For optimization

    // If USB Device -> Check if we need reload to the newest version
    if(itc->DeviceType == USB18_DEVICE_TYPE)
    {
	local_strcpy(key_data,"/usr/local/Instrutech/itc18.u2z",sizeof("/usr/local/Instrutech/itc18.u2z"));
	status = open(key_data, O_RDONLY, 0);
	if(status > 0) {
	    close(status);
	    goto PROCESS_U2F;
	}
goto DONT_PROCESS_U2F;
PROCESS_U2F:

	needlheader[0].Function = U2F_ITC18_USB_STANDARD;
	needlheader[0].FunctionVersion = (DWORD)-1;
	needlheader[0].Location = U2F_ITC18_LOCATION_USB;
	needlheader[0].Type		= (DWORD)-1;
	needlheader[0].Speed	= (DWORD)-1;
	needlheader[0].Memory	= (DWORD)-1;
	needlheader[0].Algorithm = (DWORD)-1;
	needlheader[0].ByteSize = (DWORD)-1;

	//Get Size
	status = DecodeU2F( key_data, 
			    ITC18_PRODUCT,
			    1,	//Number LCAs/DSPs to extract
			    needlheader,
			    NULL, //U2F gVersion
			    NULL, //U2F lVersion
			    NULL  //Pointers to Data
			    );

	if(status != U2F_SUCCESS)
		goto DONT_PROCESS_U2F;

	//Check version
	if(needlheader[0].FunctionVersion == 0xFFFFFFFF)
		goto DONT_PROCESS_U2F;
	if(needlheader[0].FunctionVersion <= (unsigned long)itc->USBVersion)
		goto DONT_PROCESS_U2F;

	//Allocate memory
	u2fdatapointer = malloc(needlheader[0].ByteSize);
	if(u2fdatapointer == NULL)
		goto DONT_PROCESS_U2F;

	//Get Data
	status = DecodeU2F(	key_data, 
			    ITC18_PRODUCT,
			    1,	//Number LCAs/DSPs to extract
			    needlheader,
			    NULL, //U2F gVersion
			    NULL, //U2F lVersion
			    (void*)&u2fdatapointer  //Pointers to Data
			    );

	//5.12.2006. Get Serial Number
	status = ITC18_GetUSBInfo(itc, NULL, NULL, NULL, &speed);
	if(status != ITC18_STATUS_SUCCESS)
		return status;

	//Replace the serial number
	u2fdatapointer[10] = (char)((speed & 0xF) + 0x30);
	u2fdatapointer[9] = (char)(((speed >> 4) & 0xF) + 0x30);
	u2fdatapointer[12] = (char)(((speed >> 8) & 0xF) + 0x30);
	u2fdatapointer[11] = (char)(((speed >> 12) & 0xF) + 0x30);
	u2fdatapointer[14] = (char)(((speed >> 16) & 0xF) + 0x30);
	u2fdatapointer[13] = (char)(((speed >> 20) & 0xF) + 0x30);
	u2fdatapointer[16] = (char)(((speed >> 24) & 0xF) + 0x30);
	u2fdatapointer[15] = (char)(((speed >> 28) & 0xF) + 0x30);

	status = ITC18_LoadUSB(	itc, 
				needlheader[0].ByteSize,
				u2fdatapointer);

	//Looks like USB-16 require a delay. Let's just sleep. How long?
	//Why put it for 18? Just in case
	DelayMicroseconds(10000);

	if(status)
		return ITC18_STATUS_USB_ERROR;

DONT_PROCESS_U2F: 
	if(u2fdatapointer != 0)
	    free(u2fdatapointer);
    //5.11.2006. Refresh version info
	status = ITC18_GetUSBInfo(itc, NULL, &speed, &version, NULL);
	if(status != ITC18_STATUS_SUCCESS)
	    return status;

	if(speed <= 0)
	    speed = 1;
	itc->max_transfer_size	= speed << 6;
	#ifdef DEBUG
	fprintf(stderr,"ITC18_Initialize: itc->max_transfer_size %ld\n",itc->max_transfer_size);
	#endif
	itc->USBVersion = version;
    }

    // initialize device information variables, added TG 7/27/01

    itc->fifo_size = 0;
    itc->data_read = 0;
    itc->data_written = 0;

    // The ITC18 hardware comes in 2 flavors: 256kB and 1MB
    // Get the FIFO size so we know how big our buffers are
    status = GetFIFOSize(itc, &itc->fifo_size); 
    if (status != 0) {
	fprintf(stderr,"ITC18_Initialize: GetFIFOSize %d\n",status);
	return status;
    }
    // Clear all the latches and reset the LCAs.
    status = WaitTXHEM(itc);
    if (status != 0) {
	fprintf(stderr,"ITC18_Initialize: WaitTXHEM %d\n",status);
	return status;
    }

    data[0] = (short)ACQ_CONTROL;
    data[1] = (short)FIFO_CONTROL;
    data[2] = (short)DATA_SELECT;
    data[3] = (short)LCA_CONTROL;

    status = itc->output_word_string(itc, itc->port_latch, 4, data);
    if (status != 0) {
	fprintf(stderr,"ITC18_Initialize: output_word_string %d\n",status);
	return status;
    }
    // Program the LCAs and turn the ready light on if successful.
    // TG load the loader LCA 6/28/2000
    
    status = LoadInterfaceLCA(itc, nonisolated_LCA_loader);
    if (status != 0) {
	fprintf(stderr,"ITC18_Initialize: LoadInterfaceLCA %d\n",status);
	return status;
    }

    status = GetSignature(itc, &signature); 
    if (status != 0) {
	fprintf(stderr,"ITC18_Initialize: GetSignature %d\n",status);
	return status;
    }

    if (signature != LOADER_SIGNATURE)	{
	fprintf(stderr,"ITC18_Initialize: Signature %d doesn't match %d\n",signature,LOADER_SIGNATURE);
	return ITC18_STATUS_SIGNATURE_LOADER;
    }
    // TG Load the appropriate isolated side LCA  TG 6/28/2000

    if (LCA_configuration == ITC18_PHASESHIFTER)
	status = LoadIsolatedLCA(itc, isolated_LCA_PhaseShifter);
    else
    {
	if (LCA_configuration == ITC18_DYNAMICCLAMP)
		status = LoadIsolatedLCA(itc, isolated_LCA_DynamicClamp);
	else
		status = LoadIsolatedLCA(itc, isolated_LCA_Standard);
    }

    if (status != 0)
	return status;

    status = GetSignature(itc, &signature);
    if (status != 0) {
	fprintf(stderr,"ITC18_Initialize: GetSignature %d\n",status);
	return status;
    }

    if (signature != ISOLATED_SIGNATURE)
	return ITC18_STATUS_SIGNATURE_ISOLATED;

    // TG 6/28/2000
    if (itc->fifo_size == ITC18_256K_FIFO)
	status = LoadInterfaceLCA(itc, nonisolated_LCA_256k_FIFO);
    else
	status = LoadInterfaceLCA(itc, nonisolated_LCA_1M_FIFO);

    if (status != 0)
	return status;

    status = GetSignature(itc, &signature);
    if (status != 0)
	return status;

    if (signature != INTERFACE_SIGNATURE)
	return ITC18_STATUS_SIGNATURE_INTERFACE;

    // Turn the ready light on
    status = WaitTXHEM(itc);
    if (status != 0)
	return status;

    //Initialize - GREEN is ON
    itc->green_light = 1;
    status = OutputWord(itc, itc->port_latch, ACQ_CONTROL | AC_READY_LIGHT_ON);

    if (status != 0)
	return status;

    // Initialize the gain of each AD channel.
    for (i=0; i < ITC18_AD_CHANNELS; ++i) 
	range[i] = ITC18_AD_RANGE_10V;

    status = ITC18_SetRange(itc, range);
    if (status != 0)
	return status;

    itc->initialized = 0;
    status = ITC18_StopAndInitialize(itc, 1, 1);
    if (status != 0)
	return status;

    itc->USBFIFOFlag = 0;
    itc->SequenceLength = 0;
    itc->external_clock = -1;
    itc->interval = 0;

    if(itc->USBVersion >= 0x00050000)
    {
	status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_WRITE_FIFO_DATA);
	if (status != 0)
	    return status;
    }

    //Let's set dummy sequence and run to clear EP1
    i = ITC18_OUTPUT_SKIP;

    status = ITC18_SmallRun(	itc,
				1, &i,	//int length, int* instructions,
				4, 0,	//int timer_ticks, int external_clock,
				2, data,//int OutputDataSize, short* OutputData,
				2, data,//int InputDataSize, short* InputData,
				0, 0);	//int external_trigger, int output_enable)


    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_InitializeCustom
//
// Initialize the device hardware
// If control_data or isolated_data are 0,
// the default LCA is used.

ITC_CALL int ITC18_InitializeCustom(
	void* device,
	void* control_data,
	void* isolated_data
)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int signature;
    int i;
    int range[ITC18_AD_CHANNELS];
    short data[4];	//For optimization

    // initialize variables  added TG 3/24/98

//	itc->external_clock = 0;
//	itc->interval = 10;
    itc->invert_digital_inputs = 0;
    itc->latch_digital_inputs = 0;

    // Obtain the FIFO size.

    status = GetFIFOSize(itc, &itc->fifo_size);
    if (status != 0)
	return status;

    // Clear all the latches and reset the LCAs.

    status = WaitTXHEM(itc);

    if (status != 0)
	return status;

    data[0] = (short)ACQ_CONTROL;
    data[1] = (short)FIFO_CONTROL;
    data[2] = (short)DATA_SELECT;
    data[3] = (short)LCA_CONTROL;

    status = itc->output_word_string(itc, itc->port_latch, 4, data);
    if (status != 0)
	    return status;

    // Program the LCAs and turn the ready light on if successful.

    status = LoadInterfaceLCA(itc, nonisolated_LCA_loader);
    if (status != 0)
	    return status;

    status = GetSignature(itc, &signature);
    if (status != 0)
	    return status;

    if (signature != LOADER_SIGNATURE)
	    return ITC18_STATUS_SIGNATURE_LOADER;

    if (isolated_data)
	    status = LoadIsolatedLCA(itc, (unsigned char *) isolated_data);
    else
	    status = LoadIsolatedLCA(itc, isolated_LCA_Standard);

    if (status != 0)
	    return status;

    status = GetSignature(itc, &signature);
    if (status != 0)
	    return status;

    if (signature != ISOLATED_SIGNATURE)
	    return ITC18_STATUS_SIGNATURE_ISOLATED;

    if (control_data)
	status = LoadInterfaceLCA(itc, (unsigned char *) control_data);
    else { 
	if (itc->fifo_size == ITC18_256K_FIFO)
	    status = LoadInterfaceLCA(itc, nonisolated_LCA_256k_FIFO);
	else
	    status=LoadInterfaceLCA(itc,nonisolated_LCA_1M_FIFO);
    }
    if (status != 0)
	    return status;

    status = GetSignature(itc, &signature);
    if (status != 0)
	return status;

    if (signature != INTERFACE_SIGNATURE)
	return ITC18_STATUS_SIGNATURE_INTERFACE;

    // Turn the ready light on
    status = WaitTXHEM(itc);
    if (status != 0)
	    return status;

    //Initialize - GREEN is ON
    itc->green_light = 1;
    status = OutputWord(itc, itc->port_latch, ACQ_CONTROL | AC_READY_LIGHT_ON);

    if (status != 0)
	    return status;

    // Initialize the gain of each AD channel.
    for (i=0; i < ITC18_AD_CHANNELS; ++i)
	    range[i] = ITC18_AD_RANGE_10V;

    status = ITC18_SetRange(itc, range);
    if (status != 0)
	    return status;

    itc->initialized = 0;
    status = ITC18_StopAndInitialize(itc, 1, 1);
    if (status != 0)
	    return status;

//	itc->initialized = 1;//status = ITC18_InitializeAcquisition(itc);
    itc->USBFIFOFlag = 0;
    itc->SequenceLength = 0;
    itc->external_clock = -1;
    itc->interval = 0;
			    
    if(itc->USBVersion >= 0x00050000) {
	status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_WRITE_FIFO_DATA);
	if (status != 0)
	    return status;
    }

    //Let's set dummy sequence and run to clear EP1
    i = ITC18_OUTPUT_SKIP;
    status = ITC18_SmallRun(itc,
			    1, &i,	//int length, int* instructions,
			    4, 0,	//int timer_ticks, int external_clock,
			    2, data,//int OutputDataSize, short* OutputData,
			    2, data,//int InputDataSize, short* InputData,
			    0, 0);	//int external_trigger, int output_enable)


    return ITC18_STATUS_SUCCESS;
}

//Mike: New Function -> Get Version
//Function ITC18_GetVersion

ITC_CALL int ITC18_GetVersion(void* device, void* UserVersion, void* KernelVersion)
{
    version_struct* LocalVersion;
    //struct ITC18* itc = (struct ITC18*) device;

    if(UserVersion != NULL) {
	LocalVersion = UserVersion;
	LocalVersion->major_version = MAJOR_VERSION; 
	LocalVersion->minor_version = MINOR_VERSION; 
	local_strcpy(LocalVersion->description, DESCRIPTION, 80);
	local_strcpy(LocalVersion->date, DATE, 80);
    }

    if (KernelVersion != NULL) {	
	LocalVersion = KernelVersion;
	LocalVersion->major_version = 0; 
	LocalVersion->minor_version = 0; 
	local_strcpy(LocalVersion->description, DESCRIPTION, 80);
	local_strcpy(LocalVersion->date, DATE, 80);

	/* need to add this for Linux  -kdb */
	//IOByteCount	structSize = sizeof(version_struct); 
	//kern_return_t 	kernResult;
	//if(itc->DeviceType == USB18_DEVICE_TYPE)
	//    kernResult = IOConnectMethodScalarIStructureO(  itc->ITC18dataPort,
	//							kUSB18GetVersion,	// an index to the function in the Kernel.
	//							0,			// the number of scalar input values.
	//							&structSize,		// the size of the struct output paramter.
	//							KernelVersion		// a pointer to a struct output parameter.
	//							);
	
	//if (kernResult != KERN_SUCCESS)
	//	return ITC18_STATUS_GET_VERSION;
    }

    return ITC18_STATUS_SUCCESS;
}

ITC_CALL unsigned long ITC18_GetDriverHandle(void* device, void** hDevice)
{
    struct ITC18* itc = (struct ITC18 *) device;
    unsigned long Error;

    *hDevice = itc->file;
	
    if (hDevice != NULL) Error = ITC18_STATUS_SUCCESS;
    else Error = ITC18_STATUS_NO_MEMORY;

    return Error;	
}

// Function ITC18_Open
ITC_CALL int ITC18_Open(void* device, int device_number)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status,transferred;
    int speed, version;
    char key_data[MAX_PATH + 16];
    unsigned char dummydata[512];

    //Mike
    //CurrentITC18 = device_number;
     int i;
    char* myitc;
    myitc = (char*)itc;
    for(i = 0; i < sizeof(struct ITC18); i++){
	*myitc++ = 0;
    }
    itc->DeviceType = (device_number >> 16) & 0x7FFF;
    itc->DeviceNumber = device_number & 0xFFFF;

    if(itc->DeviceType == PCI18_DEVICE_TYPE) 
    {	
#ifdef _WINDOWS
	//Check out if we have "secret file" to force USB-18
	if(GetCurrentDirectory(MAX_PATH, key_data) == 0)
		goto try1;
	strcat(key_data,"\\");
	strcat(key_data,"ForceUSB-18.on");
	if( _access(key_data, 4) != 0) {
	try1:
	    //Check out if we have "secret entry in the registry"
	    key_size = sizeof(key_data);
	    key_type = REG_SZ;
	    status = RegOpenKeyEx(HKEY_LOCAL_MACHINE, 
				    "SOFTWARE\\Instrutech\\ITC18 Driver", 
				    0, 
				    KEY_QUERY_VALUE, 
				    &key);
	    if(status != ERROR_SUCCESS)
		   return ITC18_STATUS_USB_BOARD_NOT_FOUND;

	    status = RegQueryValueEx(key,
				    "ForceUSB-18",
				    NULL,
				    &key_type,
				    (UCHAR*)key_data,
				    &key_size);
	    RegCloseKey(key);
	    if(status != ERROR_SUCCESS) 
		return ITC18_STATUS_USB_BOARD_NOT_FOUND;
	    
	    if(stricmp(key_data, "yes") != 0)
		return ITC18_STATUS_USB_BOARD_NOT_FOUND;
	}
#endif
#ifdef macintosh
	theErr = FindFolder(kOnSystemDisk, kExtensionFolderType,
//		theErr = FindFolder(kOnAppropriateDisk, kDesktopFolderType,
					0, &theVRef, &theDirID);
	if(theErr != 0) {
	   fprintf(stderr,"This driver is only for the USB18\n");;
	
	}	
	theErr = HGetFInfo (theVRef,
			    theDirID,
			    "\pForceUSB-18.on",
			    &fndrInfo);
	if(theErr != 0)
	    return ITC18_STATUS_USB_BOARD_NOT_FOUND;
#endif
#ifdef __APPLE__
	strcpy(key_data,"/System/Library/Extensions/ITC_Driver.kext/Contents/Resources/ForceUSB-18.on");
	//Check if file exist
	status = open(key_data, O_RDONLY, 0);
	if(status <= 0)
		return ITC18_STATUS_USB_BOARD_NOT_FOUND;
	close(status);
#endif
#ifdef __linux__
	strcpy(key_data,"/usr/local/Instrutech/.ForceUSB-18.on");
	//Check if file exist
	status = open(key_data, O_RDONLY, 0);
	if(status <= 0)	    
	    return ITC18_STATUS_USB_BOARD_NOT_FOUND;
	close(status);
#endif
    }

    //Here -> setup USB-18 instead of ITC-18
    itc->DeviceType = USB18_DEVICE_TYPE;
#ifdef DEBUG
    fprintf(stderr,"ITC18_Open: LocateBoard()\n");
#endif    
    status = LocateBoard(itc);
    if (status != 0)
	    return status;
#ifdef DEBUG
    fprintf(stderr,"ITC18_Open: ITC18_AllocateMemoryB()\n");
#endif    
    //Let's allocate temporaly memory for swapping output data
    itc->ITC18_AllocateMemoryB = malloc(_USB_OUTPUT_TRANSFER_SIZE_18_);
    if(itc->ITC18_AllocateMemoryB == NULL)
	return ITC18_STATUS_NO_MEMORY;
    
    itc->ByteOrderFlag = 0;	//1 - PPC, 0 - Intel
#ifdef DEBUG
    fprintf(stderr,"ITC18_Open: ITC18_GetUSBInfo()\n");
#endif    
    status = ITC18_GetUSBInfo(itc, NULL, &speed, &version, NULL);
    if(status != ITC18_STATUS_SUCCESS)
	return status;

    if(speed <= 0)
	speed = 1;
    itc->max_transfer_size = speed << 6;

    itc->USBVersion = version;	
#ifdef DEBUG
    fprintf(stderr,"ITC18_Open: itc->USBVersion %lx\n",itc->USBVersion);
#endif
    if(itc->USBVersion >= 0x00050000) {
	 //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	if(itc->USBVersion < 0x00060000) {
	    #ifdef DEBUG
	    fprintf(stderr,"ITC18_Open: libusb_control_transfer %lx\n", itc->USBVersion);
	    #endif
	    version = itc->max_transfer_size;
	    status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_READ_ROM4_N_TIMES, 1,itc->USBFIFOFlag,NULL,0,TIMEOUT_ONE_SEC);
	    if (status < 0) {
		fprintf(stderr,"ITC18_Open: libusb_control_transfer %d\n", status);
	    }
	}
	else {
	    #ifdef DEBUG
	    fprintf(stderr,"ITC18_Open: libusb_control_transfer %lx\n", itc->USBVersion);
	    #endif
	    version = 2;
	    status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_READ_ROM4_N_TIMES, 0,1,NULL,0,TIMEOUT_ONE_SEC);
	    if (status < 0 ) {
		fprintf(stderr,"ITC18_Open: libusb_control_transfer %d\n", status);
	    }
	}
	#ifdef DEBUG
	fprintf(stderr,"ITC18_Open: libusb_bulk_transfer\n");
	#endif
	status = libusb_bulk_transfer(itc->file,USB18_ROM4_PIPE_READ_LIBUSB,dummydata,version,&transferred,TIMEOUT_ONE_SEC);
	if (status != 0) {
	    fprintf(stderr,"ITC18_Open: Clearing stall %d\n", status);
	    libusb_clear_halt(itc->file,USB18_ROM4_PIPE_READ_LIBUSB);
	}
    }
 
    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_Close
//
// This closes IO resources used by an ITC18.

ITC_CALL int ITC18_Close(void* device)
{
    struct ITC18* itc = (struct ITC18*) device;
    int reference_count = 1;
    short data[4];	//for USB optimization
    int status;

    //Check for the device was initialized
    if(itc->output_word_string != NULL) {
	ITC18_StopAndInitialize(itc, 1, 1);	
	data[0] = (short)ACQ_CONTROL;
	data[1] = (short)FIFO_CONTROL;
	data[2] = (short)DATA_SELECT;
	data[3] = (short)LCA_CONTROL;
	status = itc->output_word_string(itc, itc->port_latch, 4, data);
    }
  
    if(itc->ITC18_AllocateMemoryB != NULL) 
	free(itc->ITC18_AllocateMemoryB);

    /* Close the device file */
    if (itc->file != NULL) {
	status = libusb_release_interface(itc->file,0);
	if (status != 0) fprintf(stderr, "error releasing interface ITC18\n");

	libusb_close(itc->file);
	
	libusb_exit(0);
	itc->file = NULL;
    }

    return reference_count;

}


// Function ITC18_GetFIFOOverflow
//
// Return a non-zero value in 'overflow' if FIFO overflow has occurred.

ITC_CALL int ITC18_GetFIFOOverflow(void* device, int* overflow)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    unsigned char buffer[1];

    *overflow = 0;

    if(itc->DeviceType == USB18_DEVICE_TYPE) {

	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_GETFIFOOVERFLOW, 0,0,buffer,1,TIMEOUT_ONE_SEC);
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
	if(buffer[0] & 0x80)
	    *overflow = !0;
    }

    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_InitializeAcquisition
//
// Reset the FIFO, and reset all data acquisition fields.

ITC_CALL int ITC18_InitializeAcquisition(void* device)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;

    if(itc->USBVersion >= 0x00020002) {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_INITIALIZE_ACQ, 0,0,NULL,0,TIMEOUT_ONE_SEC);
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;

    }

    itc->data_read = 0;
    itc->data_written = 0;
    itc->initialized = 1;

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetRange
//
// The (ITC18_AD_CHANNELS) range values should each be one of the
// ITC18_AD_RANGE constant values.

ITC_CALL int ITC18_SetRange(void* device, int* range)
{
    int mask;
    int channel;
    int status;

    struct ITC18* itc = (struct ITC18*) device;

    // The AD range settings are written to the board in pairs, so advance
    // i through the for loop by two.

    for (channel=0; channel < ITC18_AD_CHANNELS; channel+=2)
    {
	// channel_mask runs 0x00c0 through 0x00f0 and selects the channel.

	mask = (channel << 3) + 0x00c0;

	// OR in the ranges of the two channels selected by the current
	// value of channel_mask.  The higher numbered channel's range ends up
	// in bits 2 and 3, the lower numbered channel's range in bits 0 and 1.

	mask |= range[channel] | (range[channel+1] << 2);

	status = WaitTXHEM(itc);

	if (status != 0)
	    return status;

	status = OutputWord(itc, itc->port_latch, ACQ_CONTROL | mask);

	if (status != 0)
	    return status;
    }

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetExternalTriggerMode
//
// Non zero 'transition' triggers on a transition only,
// 'invert' triggers low.

ITC_CALL int ITC18_SetExternalTriggerMode(void* device, int transition, int invert)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;

// TG 6/21/02 MM corrected bug which set trigger mode back to original mode.	
    int mask = ACQ_CONTROL | 0x0020;

    if (transition)
	mask |= AC_EXTERNAL_TRIGGER_TRANSITION;

    if (invert)
	mask |= AC_EXTERNAL_TRIGGER_INVERT;

    status = WaitTXHEM(itc);
    if (status != 0)
	return status;

    status = OutputWord(itc, itc->port_latch, mask);
    if (status != 0)
	return status;

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_WriteFIFO
//
// Write the contents of the buffer to the FIFO.

ITC_CALL int ITC18_WriteFIFO(void* device, int length, short * buffer)
{
    int status;
    struct ITC18* itc = (struct ITC18*) device;

    if (length <= 0)
	    return ITC18_STATUS_WRITE_INVALID;

    itc->initialized = 0;

    if(itc->USBVersion < 0x00050000) {
	status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_WRITE_FIFO_DATA);
	if (status != 0)
	    return status;
    }

    status = itc->output_word_string(itc, itc->port_data, length, buffer);
    if (status != 0)
	return status;

    itc->data_written += length;

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_ReadFIFO
//
// Read the contents of the FIFO into the buffer.

ITC_CALL int ITC18_ReadFIFO(void* device, int length, short* target)
{
    int status;
    struct ITC18* itc = (struct ITC18*) device;

    if (length <= 0)
	return ITC18_STATUS_READ_INVALID;

    itc->initialized = 0;

    if(itc->USBVersion < 0x00050000) {
	status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_FIFO_DATA);
	if (status != 0) {
	    fprintf(stderr,"ITC18_ReadFIFO: OutputWord %d\n",status);
	    return status;
	}  
    }

    status = itc->input_word_string(itc, itc->port_data, length, target);
    if (status != 0) {
	fprintf(stderr,"ITC18_ReadFIFO: input_word_string %d\n",status);
	return status;
    }

    itc->data_read += length;

    return ITC18_STATUS_SUCCESS;
}



// Function GetFIFOPointer
//
// Return the decoded FIFO pointer.
//
//	size: 0 = 256K FIFO, 1 = 1M FIFO
//
// The low 16 bits of the FIFO pointer are accessed by reading the
// data port after writing DATA_SELECT | DS_READ_FIFO_PTR to the command
// port.  The upper two or four bits are available in bits 0 through
// 3 of the data port after writing DATA_SELECT | DS_READ_STATUS to the
// command port.

static int GetFIFOPointer(struct ITC18* itc, int* pointer)
{
    int low_pointer;
    int high_pointer;
    int status;
    int counter;


    unsigned char buffer[4];

    if(itc->DeviceType != USB18_DEVICE_TYPE) return ITC18_STATUS_USB_ERROR;

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_GETFIFOPOINTER, 0,0,buffer,4,TIMEOUT_ONE_SEC);
    if (status < 0)
	return ITC18_STATUS_USB_ERROR;

    low_pointer = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
    high_pointer = (((int)buffer[3] & 0xFF) << 8) | ((int)buffer[2] & 0xFF);
    
    itc->overflow = high_pointer & 0x8000;
	

    if (itc->fifo_size == ITC18_256K_FIFO) // Form an 18 bit counter.
    {
	// Decode the most significant nine bits.

	high_pointer &= 0x0003;

	high_pointer = (high_pointer << 7) | (low_pointer >> 9);

	high_pointer = FIFO_256K_DECODE_TABLE[high_pointer];

	// Decode the least significant nine bits.

	low_pointer &= 0x1ff;

	low_pointer = FIFO_256K_DECODE_TABLE[low_pointer];

	counter = low_pointer | (high_pointer << 9);
    }
    else // Form a 20 bit counter.
    {
	// Decode the most significant ten bits.

	high_pointer &= 0x000f;

	high_pointer = (high_pointer << 6) | (low_pointer >> 10);

	high_pointer = FIFO_1M_DECODE_TABLE[high_pointer];

	// Decode the least significant ten bits.

	low_pointer &= 0x3ff;

	low_pointer = FIFO_1M_DECODE_TABLE[low_pointer];

	counter = low_pointer | (high_pointer << 10);
    }

    *pointer = counter;

    return ITC18_STATUS_SUCCESS;
}

// Function SetSamplingInterval
//
// Output a 16 bit timer value to the device.
// Non zero 'external_clock' causes the ITC-18 to synchronous with
// an external clock.

ITC_CALL int ITC18_SetSamplingInterval(void* device, int timer_ticks, int external_clock)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int command = 0;

    unsigned char buffer[1];

    if(itc->DeviceType != USB18_DEVICE_TYPE) return ITC18_STATUS_USB_ERROR;

    itc->external_clock = external_clock;

    if((itc->external_clock == external_clock) && (itc->interval == timer_ticks))
	return ITC18_STATUS_SUCCESS;

    itc->interval = timer_ticks;

    if(itc->external_clock != external_clock) {
	itc->external_clock = external_clock;

	command = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

	if(itc->green_light == 0)
	    command |= AC_READY_LIGHT_OFF;
	else
	    command |= AC_READY_LIGHT_ON;

	if (itc->latch_digital_inputs)
	    command |= AC_LATCH_ENABLE;

	if (itc->external_clock)
	    command |= AC_EXTERNAL_CLOCK;
    }

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_SETSAMPLING,timer_ticks,command,buffer,1,TIMEOUT_ONE_SEC);
    if (status < 0)
	return ITC18_STATUS_USB_ERROR;
    if(buffer[0] == 1)
	return ITC18_STATUS_SUCCESS;
    else
	return ITC18_STATUS_TXHEM_TIMEOUT;


    return ITC18_STATUS_SUCCESS;
}

// Function SetSequenceInstruction
//
// Write a 16 bit instruction to the sequence RAM.

static int SetSequenceInstruction(struct ITC18* itc, int instruction)
{
    int i;
    int mask;
    int status;

    // Send the 16 bit instruction, 4 bits at a time, the low 4 bits first.

    for (i=0; i<4; ++i) {
	// The i portion of the mask selects the 4 bits being set.
	mask = ACQ_CONTROL | AC_SEND_TIMER_N0 | (i << 4) | (instruction & 0x000f);

	status = WaitTXHEM(itc);
	if (status != 0)
	    return status;

	status = OutputWord(itc, itc->port_latch, mask);
	if (status != 0)
	    return status;

	instruction >>= 4;
    }

    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_Start
//
// Start data acquisition immediately or on external trigger.

ITC_CALL int ITC18_Start(void* device, int external_trigger, int output_enable, int stoponoverflow, int reserved)
{
    struct ITC18* itc = (struct ITC18*) device;
    int command;
    int mask;
    int status;
    unsigned char buffer[1];

    itc->initialized = 0;

    // Set up the output enable
    mask = FIFO_CONTROL | FC_FIFO_ENABLE;

    if(stoponoverflow != 0)
	mask |= FC_STOP_OVR;

    if (!output_enable)
	    mask |= FC_DA_INHIBIT;

    command = ACQ_CONTROL;

    // Set digital invertion bits.
    if (itc->invert_digital_inputs)
	command |= AC_INVERT_DIGITAL_INPUTS;

    if (external_trigger & 1)
	command |= AC_ACQ_ON_TRIGGER;
    else
	command |= AC_START_ACQ;
    if(external_trigger & 2) {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_EXTERNAL_TRIGGER,mask,command,buffer,1,TIMEOUT_ONE_SEC); 
    } else {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_START,mask,command,buffer,1,TIMEOUT_ONE_SEC);  
    }

    if (status < 0)
	return ITC18_STATUS_USB_ERROR;

    if(buffer[0] == 1)
	return ITC18_STATUS_SUCCESS;
    else
	return ITC18_STATUS_TXHEM_TIMEOUT;

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_Stop
//
// Stop any sampling that is in progress.

ITC_CALL int ITC18_Stop(void* device)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int command;
    unsigned char buffer[1];

    // added command to keep invert bit stable

    command = ACQ_CONTROL | AC_STOP_ACQ;

    // Set digital inversion bits.
    if (itc->invert_digital_inputs)
	    command |= AC_INVERT_DIGITAL_INPUTS;

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_STOP,command,0,buffer,1,TIMEOUT_ONE_SEC); 

    if (status < 0)
	return ITC18_STATUS_USB_ERROR;

    if(buffer[0] == 1)
	return ITC18_STATUS_SUCCESS;
    else
	return ITC18_STATUS_TXHEM_TIMEOUT;

    return status;
}

//	Function SetSequenceLength
//
//	Write the number of entries in the sequence RAM to the device.

static int SetSequenceLength(struct ITC18* itc, int length)
{
    int i;
    int mask;
    int status;

    // Write the 12 bit sequence length to the device, 4 bits at a time,
    // low 4 bits first.

    for (i=0; i<3; ++i) {
	mask = ACQ_CONTROL | AC_SEND_SEQL_N0 | i << 4 | (length & 0x000f);

	status = WaitTXHEM(itc);

	if (status != 0)
	    return status;
	status = OutputWord(itc, itc->port_latch, mask);

	if (status != 0)
	    return status;

	length >>= 4;
    }

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_ReadROM
//
// Read a ROM sector.
// The address must be in the range 0 to ITC18_ROM_SIZE
// and be a multiple of ITC18_ROM_SECTOR_SIZE.
// "data" is assumed to be an array of length ITC18_ROM_SECTOR_SIZE.
ITC_CALL int ITC18_ReadROM(void* device, int address, int size, void* data)
{
    struct ITC18* itc = (struct ITC18*) device;
    unsigned char* byte_data = (unsigned char *) data;
    int value;
    int i;
    int result;

    // Updated 6/26/02 TG
    // The low section of the ROM is reserved for Instrutech.
    // Swap High and Low Part
    //Version 4.0 -> DO NOT SWAP. ONLY 4K RESERVED for INSTRUTECH
/*
    if (address < 0 || address >= 2 * ITC18_ROM_SIZE || address % ITC18_ROM_SECTOR_SIZE)
	    return ITC18_STATUS_ROM_INVALID_ADDRESS;

    if(address < ITC18_ROM_SIZE)
	    address += ITC18_ROM_SIZE;
    else
	    address -= ITC18_ROM_SIZE;
*/
    address += 4096;

    if (address < 0 || address >= ITC18_ROM_SIZE || address % ITC18_ROM_SECTOR_SIZE)
	return ITC18_STATUS_ROM_INVALID_ADDRESS;

//Mike: USB. Need optimization. Move to 8051
    if(size > ITC18_ROM_SECTOR_SIZE)
	size = ITC18_ROM_SECTOR_SIZE;

    for (i = 0; i < size; i++) {
	result = ReadROM(itc, address++, &value);
	if (result)
	    return result;

	*byte_data++ = value;
    }

    return ITC18_STATUS_SUCCESS;
}

// Function ValidateROM
//
// Validate values written to the ROM.

static int ValidateROM(struct ITC18* itc, int address, int size, unsigned char* data)
{
    int i;
    int value;
    int result;

    // updated 6/26/02 TG
    // Read from high section.
    // Version 4.0 does not use HIGH Section
    // address += ITC18_ROM_SIZE;

    if(size > ITC18_ROM_SECTOR_SIZE)
	size = ITC18_ROM_SECTOR_SIZE;

    for (i = 0; i < size; i++) {
    result = ReadROM(itc, address++, &value);

	if (result)
	    return result;

	if (value != *data++)
	    return ITC18_STATUS_ROM_WRITE;
    }

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_WriteROM
//
// Write to a ROM sector.
// The address must be in the range 0 to ITC18_ROM_SIZE
// and be a multiple of ITC18_ROM_SECTOR_SIZE.
// All ITC18_ROM_SECTOR_SIZE bytes of the sector must be written at the same time.
// "data" is assumed to be an array of length ITC18_ROM_SECTOR_SIZE.
#define ROM_MODE_ENABLE		0
#define ROM_MODE_ID_ENTRY	1
#define ROM_MODE_ID_EXIT	2
#define ROM_MODE_SECTOR_ERASE	3

int DelayXYZ(void* device, int microseconds)
{
//Hardware Based delay
//each read transaction over PCI bus of PCI-18 takes at least 16 cycles
//each cycle 30 ns, total 480 ns

    struct ITC18* itc = (struct ITC18*) device;
    int i, status;
    int dummy, readnumber;

    readnumber = (int)((double)microseconds/0.48 + 0.5);
    for(i = 0; i < readnumber; i++) {
	status = InputWord(itc, itc->port_data, &dummy);
	if (status != 0)
	    return status;
    }

    return ITC18_STATUS_SUCCESS;
}

int WaitROM(void* device, int address)
{

    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int read0, read1;

    long start_usec;
    long current_usec;
    struct timeval tv;
    struct timezone tz;

    gettimeofday(&tv, &tz);

    start_usec = tv.tv_usec;

    for(;;) {
	// Read the value0
	status = OutputWord(itc, itc->port_data, address);
	if (status != 0)
	    return status;

	status = InputWord(itc, itc->port_data, &read0);
	if (status != 0)
	    return status;

	// Read the value1
	status = OutputWord(itc, itc->port_data, address);
	if (status != 0)
	    return status;

	status = InputWord(itc, itc->port_data, &read1);
	if (status != 0)
	    return status;

	read0 &= 0x40;
	read1 &= 0x40;
	if(read0 == read1)
	    return ITC18_STATUS_SUCCESS;

	gettimeofday(&tv, &tz);

	current_usec = tv.tv_usec;

	if((current_usec - start_usec) > 100000)
	    return ITC18_STATUS_ROM_TIMEOUT;
    }
}


int SetROMMode(void* device, int mode)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;

    status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00AA);
    if (status != 0)
	return status;

    status = OutputWord(itc, itc->port_data, 0x5555);
    if (status != 0)
	return status;

    status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
    if (status != 0)
	return status;

    status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0055);
    if (status != 0)
	return status;

    status = OutputWord(itc, itc->port_data, 0x2AAA);
    if (status != 0)
	return status;

    status = OutputWord(itc, itc->port_data, 0x8000 | 0x2AAA);
    if (status != 0)
	return status;

    switch(mode)
    {
	case ROM_MODE_ENABLE:
	    status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00A0);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x5555);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
	    break;

	case ROM_MODE_ID_ENTRY:
	    status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0090);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x5555);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
	    DelayMicroseconds(10);
	    break;

	case ROM_MODE_ID_EXIT:
	    status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00F0);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x5555);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);

	    DelayMicroseconds(10);
	    break;

	case ROM_MODE_SECTOR_ERASE:
	    status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0080);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x5555);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
	    break;

	default:
	    status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00A0);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x5555);
	    if (status != 0)
		    return status;

	    status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
	    break;
	}

    return status;
}

int GetROMSoftID(void* device, unsigned* SoftID)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int vendorid;
    int deviceid;

    // Load the ITC18LZ LCA.
    status = LoadInterfaceLCA(itc, nonisolated_LCA_write_rom_low);
    if (status != 0)
	return status;

    // Enable EEPROM.
    status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA);
    if (status != 0)
	return status;

    //Note: Call this function after EEPROM is enable.
    status = SetROMMode(itc, ROM_MODE_ID_ENTRY);
    if (status != 0)
	return status;

    // Disable EEPROM.
    status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
    if (status != 0)
	return status;

    // Set the address to read.
    status = OutputWord(itc, itc->port_data, 0);
    if (status != 0)
	return status;

    // Read the value.
    status = InputWord(itc, itc->port_data, &vendorid);
    if (status != 0)
	return status;

    // Set the address to read.
    status = OutputWord(itc, itc->port_data, 1);
    if (status != 0)
	return status;

    // Read the value.
    status = InputWord(itc, itc->port_data, &deviceid);
    if (status != 0)
	return status;

    *SoftID = ((vendorid & 0xFF) << 8) | (deviceid & 0xFF);

    // Load the ITC18LZ LCA.
    status = LoadInterfaceLCA(itc, nonisolated_LCA_write_rom_low);
    if (status != 0)
	return status;

    // Enable EEPROM.
    status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA);
    if (status != 0)
	return status;

    status = SetROMMode(itc, ROM_MODE_ID_EXIT);
    if (status != 0)
	return status;

    // Disable EEPROM.
    status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
	return status;
}

ITC_CALL int ITC18_WriteROM(void* device, int address, void* data)
{
	struct ITC18* itc = (struct ITC18*) device;
	unsigned char* byte_data = (unsigned char *) data;
//	int attempt;
	int status;
	int i, j;
	unsigned int SoftID;
	int save_address;

	address += 4096;
	save_address = address;

	if (address < 0 || address >= ITC18_ROM_SIZE || address % ITC18_ROM_SECTOR_SIZE)
		return ITC18_STATUS_ROM_INVALID_ADDRESS;

//Mike:	for (attempt = 0; attempt < ROM_WRITE_RETRY; attempt++)

	status = GetROMSoftID(itc, &SoftID);
	if (status != 0)
		return status;

	//STUB: Set to old ID
	if(SoftID != 0xBFB5)
		SoftID = 0xBF07;

	if(SoftID != 0xBF07 && SoftID != 0xBFB5)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;

	// Load the ITC18LZ LCA.
	status = LoadInterfaceLCA(itc, nonisolated_LCA_write_rom_low);
	if (status != 0)
		return status;

	// Enable EEPROM.
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA);
	if (status != 0)
		return status;

	if(SoftID == 0xBF07)	//29EE010 Page ROM
		{
		// Write the data.
		for(i = 0; i < ITC18_ROM_SECTOR_SIZE / ITC18_OLD_ROM_SECTOR_SIZE; i++)
			{

			//Enable software protection.
			status = SetROMMode(itc, ROM_MODE_ENABLE);
			if (status != 0)
				return status;

			for(j = 0; j < ITC18_OLD_ROM_SECTOR_SIZE; j++)
				{
				status = OutputWord(itc, itc->port_latch, 0x9000 | *byte_data++);
				if (status != 0)
					return status;
				status = OutputWord(itc, itc->port_data, 0x7FFF & address);
				if (status != 0)
					return status;
				status = OutputWord(itc, itc->port_data, 0x8000 | address);
				if (status != 0)
					return status;
				address++;
				}

			DelayXYZ(itc, 10000);
			}
		}

	if(SoftID == 0xBFB5)	//39SF010
		{
		//try to erase sector
		status = SetROMMode(itc, ROM_MODE_SECTOR_ERASE);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00AA);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x5555);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0055);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x2AAA);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x8000 | 0x2AAA);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0030);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, address);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x8000 | address);
		if (status != 0)
			return status;

		DelayXYZ(itc, 10000);

		// Write the data.
		for(i = 0; i < ITC18_ROM_SECTOR_SIZE; i++)
			{
			// Enable software protection.
			status = SetROMMode(itc, ROM_MODE_ENABLE);
			if (status != 0)
				return status;

			status = OutputWord(itc, itc->port_latch, 0x9000 | *byte_data++);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x7FFF & address);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x8000 | address);
			if (status != 0)
				return status;		

			//Data polling with timeout or just wait 20 mks
//			status = WaitROM(itc, address);
//			if (status != 0)
//				return status;
			DelayXYZ(itc, 20);

			address++;
			}
		}

	// Disable EEPROM.
 	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
	if (status != 0)
		return status;

	// A delay of 200 microseconds starts the internal write cycle.
	// The internal write cycle takes 10 ms to complete.

//	DelayMicroseconds(10300);
	DelayMicroseconds(10);

	// Check the data.
	address = save_address;
	status = ValidateROM(itc, address, ITC18_ROM_SECTOR_SIZE,(unsigned char *) data);

	if (status == ITC18_STATUS_SUCCESS)
		return ITC18_STATUS_SUCCESS;

	if (status != ITC18_STATUS_ROM_WRITE)
		return status;

	return ITC18_STATUS_ROM_WRITE;
}


// Function ITC18_WriteAuxiliaryDigitalOutput
//
// Write the auxiliary digital outputs asynchronously.

ITC_CALL int ITC18_WriteAuxiliaryDigitalOutput(void* device, int data)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;

    if(itc->USBVersion >= 0x00060001) {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	fprintf(stderr,"ITC18_WriteAuxiliaryDigitalOutput: %d\n",data);
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_WRITE_AUX_OUT,data,0,NULL,0,TIMEOUT_ONE_SEC); 
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
    }

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetDigitalInputMode
//
// Set the latch and inversion mode for the digital inputs.
// The default settings are non-latched and non-inverted.
// Updated 6/26/02 TG

ITC_CALL int ITC18_SetDigitalInputMode(void* device, int latch, int invert)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int mask;

    itc->invert_digital_inputs = invert;
    itc->latch_digital_inputs = latch;

    // We assume the device has been successfully initialized,
    // se we keep the ready light on bit.

    mask = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

    if(itc->green_light == 0)
	    mask |= AC_READY_LIGHT_OFF;
    else
	    mask |= AC_READY_LIGHT_ON;

    if (latch)
	    mask |= AC_LATCH_ENABLE;

    // Check the external clock setting.

    if (itc->external_clock)
	    mask |= AC_EXTERNAL_CLOCK;

    status = WaitTXHEM(itc);
    if (status != 0)
	return status;

    status = OutputWord(itc, itc->port_latch, mask);
    if (status != 0)
	return status;

    mask = ACQ_CONTROL; // | AC_READY_LIGHT_ON;
    if(invert)
	mask |= AC_INVERT_DIGITAL_INPUTS;

    status = WaitTXHEM(itc);

    if (status != 0)
	    return status;

    status = OutputWord(itc, itc->port_latch, mask);

    if (status != 0)
	    return status;

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetReadyLight
//
// Turn ON / OFF Ready Light

ITC_CALL int ITC18_SetReadyLight(void* device, int on)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int mask;

    itc->green_light = on & 0x1;

    mask = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

    if(itc->green_light == 0)
	    mask |= AC_READY_LIGHT_OFF;
    else
	    mask |= AC_READY_LIGHT_ON;

    if (itc->latch_digital_inputs)
	    mask |= AC_LATCH_ENABLE;

    if (itc->external_clock)
	    mask |= AC_EXTERNAL_CLOCK;

    status = WaitTXHEM(itc);

    if (status != 0)
	    return status;

    status = OutputWord(itc, itc->port_latch, mask);

    if (status != 0)
	    return status;

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetSequence
//
// Write (length) instructions into the sequence memory of the device.

ITC_CALL int ITC18_SetSequence(void* device, int length, int* instructions)
{
    struct ITC18* itc = (struct ITC18*) device;
    int entry;
    int mask;
    int status;
    unsigned char buffer[64];
    int i, command;
    int buffersize;


    if(length > ITC18_SEQUENCE_RAM_SIZE)
	return ITC18_STATUS_WRITE_INVALID;

    i = length << 2;
    if(itc->SequenceLength == length) {
	//Check for Sequence itself
	if(memcmp(itc->Sequence, instructions, i) == 0)
	    return ITC18_STATUS_SUCCESS;
    }
    
    //Set new Sequence
    itc->SequenceLength = length;
    memcpy(itc->Sequence, instructions, i);
    //Reset sampling to reload it.
    itc->interval = 0;
    // Reset the sequence RAM pointer.
    
    buffersize = length * sizeof(short);

    if(itc->DeviceType == USB18_DEVICE_TYPE && buffersize < 64)	//Pipe size
    {
	//Reshape buffer from 32 bit to 16 bit
	for(entry = 0, i = 0; entry < length; entry++) {
	    buffer[i++] = instructions[entry];
	    buffer[i++] = instructions[entry] >> 8;
	}

	// added command to keep invert bit stable
	command = ACQ_CONTROL | AC_STOP_ACQ;
	// Set digital invertion bits.
	if(itc->invert_digital_inputs)
	    command |= AC_INVERT_DIGITAL_INPUTS;

	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_SETSSEQUENCE,length,command,buffer,buffersize,TIMEOUT_ONE_SEC); 

	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
    } else {
	// Reset the sequence RAM pointer.
	status = ITC18_Stop(itc);
	if (status != 0)
	    return status;

//Mike: Extra Stuff
//		status = WaitTXHEM(itc);
//		if (status != 0)
//			return status;

	// Set the length of the sequence
	status = SetSequenceLength(itc, length);
	if (status != 0)
	    return status;

	// Stop the device to reset the sequence counter
	status = ITC18_Stop(itc);
	if (status != 0)
	    return status;

//Mike: Extra Stuff
//		status = WaitTXHEM(itc);
//		if (status != 0)
//			return status;

	// Send the sequence to the device
	for(entry = 0; entry < length; ++entry) {
	    status = SetSequenceInstruction(itc, instructions[entry]);
	    if (status != 0)
		return status;

	    status = WaitTXHEM(itc);
	    if (status != 0)
		return status;

	    mask = ACQ_CONTROL | AC_SEQ_WRITE;

	    status = OutputWord(itc, itc->port_latch, mask);

	    if (status != 0)
		return status;
	}
    }

    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_IsClipping
//
// Return the state of the clipping line.  Reading the clipping line
// clears the bit.

ITC_CALL int ITC18_IsClipping(void* device, int* state)
{
    int status;

    struct ITC18* itc = (struct ITC18*) device;

   if (itc->USBVersion >= 0x00020002) {
	*state = 0;
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_IS_CLIPPING,0,0,(unsigned char *)state,1,TIMEOUT_ONE_SEC); 
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
    }

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_GetFIFOReadAvailableOverflow
//
// 07.19.04 -> combine 2 function in one

ITC_CALL int ITC18_GetFIFOReadAvailableOverflow(void* device, int* available, int* overflow)
{
    int status;
    struct ITC18* itc = (struct ITC18*) device;

    //Call mother function
    status = ITC18_GetFIFOReadAvailable(device, available);
    *overflow = 0;
    if(itc->overflow != 0)
	    *overflow = !0;

    return status;
}


// Function ITC18_GetFIFOReadAvailable
//
// Return the number of acquired samples not yet read out of the FIFO.
// Note that the current FIFO pointer wraps around, and data_read may
// grow without limit.

ITC_CALL int ITC18_GetFIFOReadAvailable(void* device, int* available)
{
    int read_available;
    int pointer;
    int status;

    struct ITC18* itc = (struct ITC18*) device;

    status = GetFIFOPointer(itc, &pointer);
    
    if (status != 0)
	    return status;

    read_available = pointer - itc->data_read;
    
    read_available %= itc->fifo_size;

    if (read_available < 0)
	    read_available += itc->fifo_size;

    *available = read_available;

    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_GetFIFOWriteAvailable
//
// Return the number of FIFO entries available for writing.

ITC_CALL int ITC18_GetFIFOWriteAvailable(void* device, int* available)
{
    int output_data;
    int write_available;

    struct ITC18* itc = (struct ITC18*) device;

    // If the amount of data read exceeds the amount written,
    // the device FIFO has underflowed.

    output_data = itc->data_written - itc->data_read;
    if (output_data < 0)
	    return ITC18_STATUS_FIFO_UNDERFLOW;

    // Compute the amount available as the size of the FIFO,
    // less the amount of data waiting to be output in the FIFO.

    write_available = itc->fifo_size - 1 - output_data;

    *available = write_available;

    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_GetFIFOSize

ITC_CALL int ITC18_GetFIFOSize(void* device)
{
	struct ITC18* itc = (struct ITC18*) device;

	return itc->fifo_size;
}


// Function ITC18_GetStatusOverflow

ITC_CALL int ITC18_GetStatusOverflow(void* device)
{
	return ITC18_STATUS_FIFO_OVERFLOW;
}


// Selects the register bank for the special DAC shift LCA
// This is only to be used for the EPC-10

ITC_CALL int ITC18_SetBank(void* device, unsigned bank)
{
    int status;
    int mask;
	    
    struct ITC18* itc = (struct ITC18*) device;

    mask = ACQ_CONTROL | AC_BANK_SELECT | (bank & 0x1);
	    
    status = WaitTXHEM(itc);
    if (status != 0)
	    return status;

    status = OutputWord(itc, itc->port_latch, mask);
    if (status != 0)
	    return status;

    return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetDACShift
// Sets the shift value for DAC's 2 and 3
// Valid shift values, 	0 = No shift
//						1 = 1.25 microseconds
//						2 = 2.50 microseconds
//						3 = 3.75 microseconds

ITC_CALL int ITC18_SetDACShift(void* device, unsigned shift)
{
    int status;
    int mask;
	    
    struct ITC18* itc = (struct ITC18*) device;

    status = ITC18_SetBank(itc,1);

    if (status != 0)
	return status;

    status = WaitTXHEM(itc);

    if (status != 0)
	return status;

//	mask = ACQ_CONTROL |  AC_DAC_SHIFT | (shift & 0x3);
	    
    mask = ACQ_CONTROL | (shift & 0x3);  //TG 9/22/2000
    
    status = OutputWord(itc, itc->port_latch, mask);

    if (status != 0)
	return status;

    status = ITC18_SetBank(itc,0);

    if (status != 0)
	return status;

    return ITC18_STATUS_SUCCESS;
}


// Function ITC18_Release
//
// Release the driver.

ITC_CALL int ITC18_Release(void* device)
{

    return ITC18_STATUS_RESERVE;
}

// Function ITC18_Reserve
//
// Reserve the driver.

ITC_CALL int ITC18_Reserve(void* device, int* busy)
{
 //   int status;
//     struct ITC18* itc = (struct ITC18*) device;

    *busy = 0;

    return ITC18_STATUS_SUCCESS;
}


//Mike: Allocate Memory
//Function ITC18_AllocateMemory

ITC_CALL int ITC18_AllocateMemory(void* device, int MemorySizeInBytes, void** LinearAddress)
{

	// struct ITC18* itc = (struct ITC18*) device;
	return ITC18_STATUS_NOT_IMPLEMENTED;
}


//Mike: Free Memory
//Function ITC18_FreeMemory

ITC_CALL int ITC18_FreeMemory(void* device)
{

    // struct ITC18* itc = (struct ITC18*) device;
    return ITC18_STATUS_NOT_IMPLEMENTED;
}
ITC_CALL int ITC18_ReadPCIROMSector(void* device, int Address, unsigned char* PCIData)
{
    return ITC18_STATUS_NOT_IMPLEMENTED;
}

int ITC18_WaitPCIROM(void* device, int address)
{
    return ITC18_STATUS_NOT_IMPLEMENTED;
}

int ITC18_SetPCIROMMode(void* device, int mode)
{
    return ITC18_STATUS_NOT_IMPLEMENTED;
}

int ITC18_GetPCIROMSoftID(void* device, unsigned* SoftID)
{
    return ITC18_STATUS_NOT_IMPLEMENTED;
}

ITC_CALL int ITC18_WritePCIROMSector(void* device, int Address, unsigned char* PCIData)
{
    return ITC18_STATUS_NOT_IMPLEMENTED;
}

ITC_CALL int ITC18_GetPCISerialNumber(void* device, int* SerialNumber)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int address;

    address = 0;
    *SerialNumber = 0;

    if(itc->DeviceType == USB18_DEVICE_TYPE) {
	status = ITC18_GetUSBInfo(itc, NULL, NULL, NULL,SerialNumber);
	if(status != ITC18_STATUS_SUCCESS)
		    return status;
    }

    return ITC18_STATUS_NOT_IMPLEMENTED;
}

ITC_CALL int ITC18_GetDeviceInfo(void* device, int* DeviceType, int* DeviceNumber)
{
    struct ITC18* itc = (struct ITC18*) device;

    if(DeviceType != NULL)
	*DeviceType = itc->DeviceType;

    if(DeviceNumber != NULL)
	*DeviceNumber = itc->DeviceNumber;

    return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_GetUSBInfo(void* device, int* REVCTL, int* Speed, int* Version, int* SerialNumber)
{
    int status;
    unsigned char buffer[8];

    struct ITC18* itc = (struct ITC18*) device;

    if(itc->DeviceType != USB18_DEVICE_TYPE)
	    return ITC18_STATUS_NOT_IMPLEMENTED;

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_GETBOX_INFO,(MAJOR_VERSION << 8) | MINOR_VERSION,itc->ByteOrderFlag,buffer,8,TIMEOUT_ONE_SEC); 
    if (status < 0)
    {	
	fprintf(stderr,"ITC18_GetUSBInfo: libusb_control_transfer %d\n",status);
	return ITC18_STATUS_USB_ERROR;
    }

    if(REVCTL != NULL)
	*REVCTL = (long)buffer[0] & 0xFF;
            
    if(Speed != NULL)
	*Speed = (long)buffer[1] & 0xFF;

    if(Version != NULL)
	*Version = ((long)buffer[3] & 0xFF) << 16 | ((long)buffer[2] & 0xFF);

    if(SerialNumber != NULL)
	*SerialNumber = ((long)buffer[7] & 0xFF) << 24 | ((long)buffer[6] & 0xFF) << 16 | ((long)buffer[5] & 0xFF) << 8 | ((long)buffer[4] & 0xFF);

#ifdef DEBUG
    if(REVCTL != NULL) fprintf(stderr,"ITC18_GetUSBInfo: REVCTL %d\n",*REVCTL);
    if(Speed != NULL) fprintf(stderr,"ITC18_GetUSBInfo: Speed %d\n",*Speed);
    if(Version != NULL) fprintf(stderr,"ITC18_GetUSBInfo: Version %x\n",*Version);
    if(SerialNumber != NULL) fprintf(stderr,"ITC18_GetUSBInfo: SerialNumber %d\n",*SerialNumber);
#endif

    return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_SetUSBDigitalOutput(void* device, int DigitalOutput)
{
    int status;

    struct ITC18* itc = (struct ITC18*) device;

    if(itc->DeviceType != USB18_DEVICE_TYPE)
	    return ITC18_STATUS_NOT_IMPLEMENTED;
	    
    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_WRITE_SCSI_PORTC,DigitalOutput,0,NULL,0,TIMEOUT_ONE_SEC); 
    if (status < 0)
	return ITC18_STATUS_USB_ERROR;

    return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_GetUSBDigitalInput(void* device, int* DigitalInput)
{
    int status;
    unsigned char buffer[2];

    struct ITC18* itc = (struct ITC18*) device;

    if(itc->DeviceType != USB18_DEVICE_TYPE)
	    return ITC18_STATUS_NOT_IMPLEMENTED;

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_READ_SCSI_PORTC,0,0,buffer,2,TIMEOUT_ONE_SEC); 
    if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
	    
    if(DigitalInput != NULL)
	*DigitalInput = (int)(buffer[0] & 0xFF) | (((int)(buffer[1]) & 0xFF) << 8);

    return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_SetUSBUserBit(void* device, int Value)
{
    int status, transferred;
    unsigned char buffer[2];

    struct ITC18* itc = (struct ITC18*) device;

    if(itc->DeviceType != USB18_DEVICE_TYPE)
	return ITC18_STATUS_NOT_IMPLEMENTED;

    if(itc->USBVersion >= 0x00020006 && itc->USBVersion <= 0x00030000) {
	buffer[0] = (BYTE) _USB_SET_RESET_USER_LINE;	//Set User Output 0xDC
	buffer[1] = Value;	
	//Write to PIPE 1
	status = libusb_bulk_transfer(itc->file,USB18_PIPE1_OUT_LIBUSB,buffer,2,&transferred,TIMEOUT_ONE_SEC); 
	if (status != 0) {
	    libusb_clear_halt(itc->file,USB18_PIPE1_OUT_LIBUSB);
	    return ITC18_STATUS_WRITE_ERROR;
	}
    } else {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_SET_RESET_USER_LINE,Value,0,NULL,0,TIMEOUT_ONE_SEC); 
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
    }

    return ITC18_STATUS_SUCCESS;
}

//Life Timer
ITC_CALL int ITC18_GetTimer(void* device, LONGLONG* Timer)
{
    int status;
    unsigned char buffer[8];

    struct ITC18* itc = (struct ITC18*) device;

    if(itc->DeviceType != USB18_DEVICE_TYPE)
	    return ITC18_STATUS_NOT_IMPLEMENTED;

    if(itc->USBVersion < 0x00020000)
	    return ITC18_STATUS_USB_OLD_VERSION;

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_READ_LIFETIMER,0,0,buffer,8,TIMEOUT_ONE_SEC); 
    if (status < 0)
	    return ITC18_STATUS_USB_ERROR;

    if(Timer != NULL)
	*Timer =  (LONGLONG)(buffer[0] & 0xFF) | (((LONGLONG)(buffer[1]) & 0xFF) << 8) | 
		(((LONGLONG)(buffer[2]) & 0xFF) << 16) | (((LONGLONG)(buffer[3]) & 0xFF) << 24) |
		(((LONGLONG)(buffer[4]) & 0xFF) << 32) | (((LONGLONG)(buffer[5]) & 0xFF) << 40) |
		(((LONGLONG)(buffer[6]) & 0xFF) << 48) | (((LONGLONG)(buffer[7]) & 0xFF) << 56);
	
    return ITC18_STATUS_SUCCESS;
}

//Start/Stop Timer
ITC_CALL int ITC18_GetAcqTimer(void* device, LONGLONG* StartTimer, LONGLONG* StopTimer)
{
    int status;
    unsigned char buffer[16];
	

    struct ITC18* itc = (struct ITC18*) device;

    if(itc->DeviceType != USB18_DEVICE_TYPE)
	    return ITC18_STATUS_NOT_IMPLEMENTED;

    if(itc->USBVersion < 0x00020000)
	    return ITC18_STATUS_USB_OLD_VERSION;

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_READ_S_TIMER,0,0,buffer,16,TIMEOUT_ONE_SEC); 
    if (status < 0)
	    return ITC18_STATUS_USB_ERROR;

    if(StartTimer != NULL)
	*StartTimer = (LONGLONG)(buffer[0] & 0xFF) | (((LONGLONG)(buffer[1]) & 0xFF) << 8) | 
		    (((LONGLONG)(buffer[2]) & 0xFF) << 16) | (((LONGLONG)(buffer[3]) & 0xFF) << 24) |
		    (((LONGLONG)(buffer[4]) & 0xFF) << 32) | (((LONGLONG)(buffer[5]) & 0xFF) << 40) |
		    (((LONGLONG)(buffer[6]) & 0xFF) << 48) | (((LONGLONG)(buffer[7]) & 0xFF) << 56);

    if(StopTimer != NULL)
	*StopTimer = (LONGLONG)(buffer[8] & 0xFF) | (((LONGLONG)(buffer[9]) & 0xFF) << 8) | 
		    (((LONGLONG)(buffer[10]) & 0xFF) << 16) | (((LONGLONG)(buffer[11]) & 0xFF) << 24) |
		    (((LONGLONG)(buffer[12]) & 0xFF) << 32) | (((LONGLONG)(buffer[13]) & 0xFF) << 40) |
		    (((LONGLONG)(buffer[14]) & 0xFF) << 48) | (((LONGLONG)(buffer[15]) & 0xFF) << 56);
	
    return ITC18_STATUS_SUCCESS;
}

//Control Timer 1/2 - Event Counter
ITC_CALL int ITC18_ControlTimers(void* device, long Control1, long* Counter1, long Control2, long* Counter2)
{
//Control Format
//Bit 0 - Start(1) / Stop(0 - default)
//Bit 1 - Reset
//Bit 7 - Set Mode:
//Bit 2 - CLK/4(1) / CLK/12(0 - default)
//Bit 3 - Timer(0) / Counter(1 - default)
//For Timer 1 Only:
//Bit 4 - Use GATE (INT1 Should be high). Require hardware modification
//Bit 6:5
//	00 - 13 bit counter
//	01 - 16 bit counter (default)
//	10 - 8 bit counter with autoreload
//	11 - Timer stopped

    int status;
    unsigned char buffer[4];

    struct ITC18* itc = (struct ITC18*) device;

    if(itc->DeviceType != USB18_DEVICE_TYPE)
	    return ITC18_STATUS_NOT_IMPLEMENTED;

    if(itc->USBVersion < 0x00020000)
	    return ITC18_STATUS_USB_OLD_VERSION;

    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
    status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_CONTROL_TIMERS,(UWORD)Control1,(UWORD)Control2,buffer,4,TIMEOUT_ONE_SEC); 
    if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
   
    if(Counter1 != NULL)
	    *Counter1 = (LONG)(buffer[0] & 0xFF) | (((LONG)(buffer[1]) & 0xFF) << 8);           
	
    if(Counter2 != NULL)
	    *Counter2 = (LONG)(buffer[2] & 0xFF) | (((LONG)(buffer[3]) & 0xFF) << 8);           
		
    return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_StartByTimer(void* device, 
				int external_trigger, 
				int output_enable, 
				int stoponoverflow, 
				int reserved,
				LONGLONG Timer)
{
    struct ITC18* itc = (struct ITC18*) device;
    int command;
    int mask;
    int status;
    int i;
    char ctemp;
    unsigned char buffer[8];

    if(itc->USBVersion < 0x00020000)
	return ITC18_STATUS_USB_OLD_VERSION;

    itc->initialized = 0;

    // Set up the output enable
    mask = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
	    
    if(stoponoverflow != 0)
	mask |= FC_STOP_OVR;

    if (!output_enable)
	mask |= FC_DA_INHIBIT;

    command = ACQ_CONTROL;

    // Set digital invertion bits.
    if (itc->invert_digital_inputs)
	command |= AC_INVERT_DIGITAL_INPUTS;

    if (external_trigger & 1)
	command |= AC_ACQ_ON_TRIGGER;
    else
	command |= AC_START_ACQ;

    for(i = 0; i < 8; i++) {
	ctemp = (char)(Timer & 0xFF);
	buffer[i] = ctemp;
	Timer = Timer >> 8;
    }

    if(itc->DeviceType == USB18_DEVICE_TYPE) {
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_START_BY_TIMER,(UWORD)mask,(UWORD)command,buffer,8,TIMEOUT_ONE_SEC); 
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
	return ITC18_STATUS_SUCCESS;
    }
 
    return ITC18_STATUS_NOT_IMPLEMENTED;
}

typedef struct 
{
    int16_t Offset;
} ITC18_ANCHOR_DOWNLOAD_CONTROL;

struct MemSeg
{
    int32_t TAddr; //Target Address
    int32_t HAddr; //Host Address
    int32_t Size;  //block size
    int32_t Stat;  //status
    char* pData; //data bytes
};

#define TGT_IMG_SIZE 0x10000 //64KB (65,536 Byte) target image
#define TGT_SEG_SIZE 16		//16 byte segments
#define MAXSTR 256 // Maximum length of Intel Hex file string
#define MAX_EP0_XFER_SIZE (1024*4) // 4K Control EP0 transfer limit imposed by OS 

typedef struct
{
    int32_t TAddr; //Target Address
    int32_t HAddr; //Host Address
    int32_t Size;  //block size
    int32_t Stat;  //status
    char* pData; //data bytes
}MemSeg;

typedef struct 
{
    UBYTE data[TGT_IMG_SIZE]; //target image store
}TMemImg;

typedef struct
{
	TMemImg* pImg;	//pointer to image
	int nSeg;		//segment count
	MemSeg pSeg[TGT_IMG_SIZE/TGT_SEG_SIZE]; //info about segments
}TMemCache;

ITC_CALL int ITC18_LoadUSB(	void* device, 
				int Length,
				char* Data)
{
    struct ITC18* itc = (struct ITC18*) device;
    unsigned long status;

    ITC18_ANCHOR_DOWNLOAD_CONTROL downloadControl;
    char* DataBlock;
    int tLength;

    unsigned char buffer[1];

    TMemCache m_MemCache;	//target mem cache info
    TMemImg m_MemImg;		//target memory image

    int i, exitflag = 0;
    char str[MAXSTR];
    unsigned byte;
    int curSeg = 0;			// current seg record 
    int recType;
    unsigned addr = 0;
    int cnt;
    unsigned int totalRead = 0;
    // offsets of fields within record -- may change later due to "spaces" setting
    int CNTFIELD  = 1;
    int ADDRFIELD = 3;
    int RECFIELD  = 7;
    int DATAFIELD = 9;
    char* ptr;

    //0. Decode Data 
    
    m_MemCache.pImg = &m_MemImg;
    m_MemCache.nSeg = 0;

    tLength = 0;
    for(;;)
	    {
	    //Read one string
	    i = 0;
	    while(Data[tLength] != 0x0D)
		    {
		    str[i++] = Data[tLength++];
		    if(i > MAXSTR)	//Check for string length
			    return ITC18_STATUS_READ_ERROR;
		    if(tLength > Length)	//Check for data length
			    return ITC18_STATUS_READ_ERROR;
		    }
	    tLength++;	//Skip "next line"
	    if(Data[tLength++] != 0x0A)
		    return ITC18_STATUS_READ_ERROR;
	    if(str[0] != ':')
		    return ITC18_STATUS_READ_ERROR;
	    if(str[1] == ' ')
		    {
		    CNTFIELD    = 1 + 1;
		    ADDRFIELD   = 3 + 2;
		    RECFIELD    = 7 + 3;
		    DATAFIELD   = 9 + 4;
		    }

	    sscanf(str+RECFIELD,"%2x",&recType);
	    ptr = (char*)m_MemCache.pImg;

	    switch(recType)
		    {
		    case 2: 
			    sscanf(str+DATAFIELD,"%4x",&curSeg);
			    curSeg *= 0x10;
			    break;
		    case 0: 
			    sscanf(str+CNTFIELD,"%2x",&cnt);
			    sscanf(str+ADDRFIELD,"%4x",&addr);
			    if(addr >= TGT_IMG_SIZE)	//Check for valid address
				    return ITC18_STATUS_READ_ERROR;

			    ptr += addr; // get pointer to location in image
		    
			    if(m_MemCache.nSeg && 
				    (m_MemCache.pSeg[m_MemCache.nSeg - 1].TAddr == 
					    addr - m_MemCache.pSeg[m_MemCache.nSeg - 1].Size) &&
				    (m_MemCache.pSeg[m_MemCache.nSeg - 1].Size + cnt <= MAX_EP0_XFER_SIZE) )
				    { // if the segment is contiguous to the last segment, and it's not too big yet
				    m_MemCache.pSeg[m_MemCache.nSeg - 1].Size += cnt; // append to previous segment
				    }
			    else
				    { // start a new segment
				    m_MemCache.pSeg[m_MemCache.nSeg].TAddr = addr;
				    m_MemCache.pSeg[m_MemCache.nSeg].Size = cnt;
				    m_MemCache.pSeg[m_MemCache.nSeg].pData = ptr;
				    m_MemCache.nSeg++;
				    }
					    
			    for(i = 0; i < cnt; i++)
				    {
				    sscanf(str+DATAFIELD+i*2,"%2x",&byte);
				    *(ptr + i) = byte;
				    totalRead++;
				    }
			    break;

		    case 1: 
			    exitflag = 1;
			    break;
		    
		    default:
			    break;
		    }
	    if(exitflag == 1)
		    break;
	    }

    //Now let's download it.
    //load all high mem first

    for(i = 0; i < m_MemCache.nSeg; i++) {
	if(m_MemCache.pSeg[i].TAddr >= 0x2000) {
	    //Mike: We should not load above 16K (0x2000 - 8K for older chip)
	    return ITC18_STATUS_READ_ERROR;

	    // isn't used? kdb
	    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);
	    status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)0xA3,(UWORD)m_MemCache.pSeg[i].TAddr,(UWORD)0,(UBYTE *)m_MemCache.pSeg[i].pData,m_MemCache.pSeg[i].Size,TIMEOUT_ONE_SEC); 
	    if (status < 0)
		return ITC18_STATUS_USB_ERROR;
	}
    }

    //1. Stop USB

    buffer[0] = 1;
    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
    status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)0xA0,(UWORD)0xE600,(UWORD)0,buffer,1,TIMEOUT_ONE_SEC); 
    if (status < 0)
	return ITC18_STATUS_USB_ERROR;
   
				    
    //2. DOWNLOAD CODE
    for(i = 0; i < m_MemCache.nSeg; i++) { //load all low mem last
//		if(theApp.m_MemCache.pSeg[j].TAddr < 0x2000) mike Change to 16K for LP2
	if(m_MemCache.pSeg[i].TAddr < 0x4000) {
	    DataBlock = m_MemCache.pSeg[i].pData;
	    tLength = m_MemCache.pSeg[i].Size;
	    downloadControl.Offset = (unsigned short)m_MemCache.pSeg[i].TAddr;

	    for(cnt = 0; cnt < tLength / 64; cnt++) {
		//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
		status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)0xA0,(UWORD)downloadControl.Offset,(UWORD)0,(UBYTE *)DataBlock,64,TIMEOUT_ONE_SEC); 
		if (status < 0)
		    return ITC18_STATUS_USB_ERROR;
		DataBlock += 64;
		downloadControl.Offset += 64;
	    }
		    
	    tLength = tLength % 64;
	    if(tLength != 0) {
		//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
		status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)0xA0,(UWORD)downloadControl.Offset,(UWORD)0,(UBYTE *)DataBlock,tLength,TIMEOUT_ONE_SEC); 
		if (status < 0)
		    return ITC18_STATUS_USB_ERROR;		
	    }									
	}
    }

    /////////////////////////////////////////////////

    //3. Run 8051

    buffer[0] = 0;
    //libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
    status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)0xA0,(UWORD)0xE600,(UWORD)0,buffer,1,TIMEOUT_ONE_SEC); 
    if (status < 0)
	return ITC18_STATUS_USB_ERROR;	

    return ITC18_STATUS_SUCCESS;
}

//10.17.2005 Optimization functions

ITC_CALL int ITC18_StopAndInitialize(void* device, int stop, int initialize)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status = ITC18_STATUS_SUCCESS;
    int command;
    unsigned char buffer[1];
	

    if(stop && initialize && (itc->USBVersion >= 0x00020004)) {
	// added command to keep invert bit stable
	command = ACQ_CONTROL | AC_STOP_ACQ;
	// Set digital invertion bits.
	if(itc->invert_digital_inputs)
		command |= AC_INVERT_DIGITAL_INPUTS;

	itc->data_read = 0;
	itc->data_written = 0;
	itc->initialized = 1;
	
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_STOP_INITIALIZE,(UWORD)command,(UWORD)0,buffer,1,TIMEOUT_ONE_SEC); 
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
	if(buffer[0] == 1)
		return ITC18_STATUS_SUCCESS;
	else
		return ITC18_STATUS_TXHEM_TIMEOUT;
    } else {
	if(stop) {
	    status = ITC18_Stop(device);
	    if(status != ITC18_STATUS_SUCCESS)
		    return status;
	}
	if(initialize)	
	    status = ITC18_InitializeAcquisition(device);
    }
    return status;
}


ITC_CALL int ITC18_SetupAcquisition(void* device, 
					int stop,
					int initialize, 
					int length, int* instructions,
					int timer_ticks, int external_clock,
					int start,
					int external_trigger, 
					int output_enable,
					int stoponoverflow,
					int reserved)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;
    int command, sequenceflag;

    int entry;
    int i;
    int buffersize;
    unsigned char buffer[64];


    buffersize = length * sizeof(short) + 4 + 4;

    if((buffersize < 64) && (itc->USBVersion >= 0x00020004)) {
	i = 0;
	//First:  buffer Timer
	buffer[i++] = timer_ticks;				// [0]
	buffer[i++] = timer_ticks >> 8;			// [1]
	//Second: Timer Command
	command = 0;
	if(itc->external_clock != external_clock) {
	    itc->external_clock = external_clock;

	    command = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

	    if(itc->green_light == 0)
		command |= AC_READY_LIGHT_OFF;
	    else
		command |= AC_READY_LIGHT_ON;

	    if (itc->latch_digital_inputs)
		command |= AC_LATCH_ENABLE;

	    if (itc->external_clock)
		command |= AC_EXTERNAL_CLOCK;
	}

	buffer[i++] = command;					// [2]
	buffer[i++] = command >> 8;				// [3]

	//Third: Start Data
	command = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
	
	if(stoponoverflow != 0)
	    command |= FC_STOP_OVR;

	if (!output_enable)
	    command |= FC_DA_INHIBIT;

	buffer[i++] = command;					// [4]
	buffer[i++] = command >> 8;				// [5]

	//Fourth: Start Data
	command = ACQ_CONTROL;

	// Set digital invertion bits.
	if (itc->invert_digital_inputs)
	    command |= AC_INVERT_DIGITAL_INPUTS;

	if (external_trigger & 1)
	    command |= AC_ACQ_ON_TRIGGER;
	else
	    command |= AC_START_ACQ;

	buffer[i++] = command;					// [6]
	buffer[i++] = command >> 8;				// [7]

	if(length > 0) {
	    sequenceflag = 0;
	    if(itc->SequenceLength == length) {
		//Check for Sequence itself
		if(memcmp(itc->Sequence, instructions, length << 2) == 0)
			sequenceflag = 1;
	    }
	    if(sequenceflag == 1)
		length = 0;
	    else {
		//Set new Sequence
		itc->SequenceLength = length;
		memcpy(itc->Sequence, instructions, length << 2);
	    }

	    //Reshape sequence buffer from 32 bit to 16 bit
	    for(entry = 0; entry < length; entry++) {
		buffer[i++] = instructions[entry];
		buffer[i++] = instructions[entry] >> 8;
	    }
	}

	//Bit oriented command
	i = 0;
	if(stop)
	    i |= 0x01;
	if(initialize) {
	    if(itc->initialized == 0) {
		i |= 0x02;
		itc->initialized = 1;
		itc->data_read = 0;
		itc->data_written = 0;
	    }
	}

//		itc->interval = timer_ticks;
	if(timer_ticks > 0) {
	    if(itc->interval != timer_ticks || length != 0) {
		i |= 0x04;
		itc->interval = timer_ticks;
	    }
	}
	if(start) {
	    i |= 0x08;
	    itc->initialized = 0;
	}

	//This is STOP Command, used in stop and setsequence
	command = ACQ_CONTROL | AC_STOP_ACQ;
	// Set digital invertion bits.
	if(itc->invert_digital_inputs)
	    command |= AC_INVERT_DIGITAL_INPUTS;

	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_SETUP_ACQUISITON,(UWORD)((i << 8) | length),(UWORD)command,buffer,buffersize,TIMEOUT_ONE_SEC); 
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;

	return ITC18_STATUS_SUCCESS;

    } else return ITC18_STATUS_NOT_IMPLEMENTED;
    return status;
}


ITC_CALL int ITC18_SmallRun(void* device,
			    int length, int* instructions,
			    int timer_ticks, int external_clock,
			    int OutputDataSize, short* OutputData,
			    int InputDataSize, short* InputData,
			    int external_trigger, int output_enable)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status, transferred,limit0=0, limit1=0;
    int available;
    unsigned int limit;
    int command, sequenceflag;
    unsigned long starttime, currenttime;
    int entry;
    int i, j;
    unsigned long buffersize;
    unsigned char buffer[64];

    limit = max(InputDataSize, OutputDataSize) + 3;

    buffersize = (length + OutputDataSize) * sizeof(short) + 4 + 4 + 2 + 4;

    if((buffersize < 64) && (InputDataSize < 32) &&
		    (itc->USBVersion >= 0x00020005)) {
	i = 0;
	//First:  buffer Timer
	buffer[i++] = timer_ticks;				// [0]
	buffer[i++] = timer_ticks >> 8;			// [1]
	//Second: Timer Command
	command = 0;
	if(itc->external_clock != external_clock) {
		itc->external_clock = external_clock;

	    command = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

	    if(itc->green_light == 0)
		command |= AC_READY_LIGHT_OFF;
	    else
		command |= AC_READY_LIGHT_ON;

	    if (itc->latch_digital_inputs)
		command |= AC_LATCH_ENABLE;

	    if (itc->external_clock)
		command |= AC_EXTERNAL_CLOCK;
	}

	buffer[i++] = command;					// [2]
	buffer[i++] = command >> 8;				// [3]

	//Third: Start Data
	command = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
	
//		if(stoponoverflow != 0)
	command |= FC_STOP_OVR;

	if (!output_enable)
	    command |= FC_DA_INHIBIT;

	buffer[i++] = command;					//[4]
	buffer[i++] = command >> 8;				//[5]

	//Fourth: Start Data
	command = ACQ_CONTROL;

	// Set digital invertion bits.
	if (itc->invert_digital_inputs)
	    command |= AC_INVERT_DIGITAL_INPUTS;

	if (external_trigger & 1)
	    command |= AC_ACQ_ON_TRIGGER;
	else
	    command |= AC_START_ACQ;

	buffer[i++] = command;					// [6]
	buffer[i++] = command >> 8;				// [7]

	//Fifth: Data Sizes
	buffer[i++] = OutputDataSize;			// [8]
	buffer[i++] = InputDataSize;			// [9]

	//Now we need a maximum counter for compare

	//Convert limit and "limit + 1" to state
	if (itc->fifo_size == ITC18_256K_FIFO) { // Form an 18 bit counter.
	    //Actually limit is a small number in this case.
	    //limit_low = limit & 0x1FF;

	    //Actually limit_high in our case is always 0
	    //limit_high = (limit >> 9) & 0x1FF;
	    
	    //Search the table, untill Arthur gives me the better way
	    //Hard code value "0"
	    fprintf(stderr,"ITC18_SmallRun: ITC18_256K_FIFO\n");
	    for(j = 0; j < 512; j++) {
		if(limit == FIFO_256K_DECODE_TABLE[j]) {
		    limit0 = j;
		    break;
		}
	    }
	    limit++;
	    for(j = 0; j < 512; j++) {
		if(limit == FIFO_256K_DECODE_TABLE[j]) {
		    limit1 = j;
		    break;
		}
	    }
	}
	else { // Form a 20 bit counter.
	    fprintf(stderr,"ITC18_SmallRun: ITC18_1M_FIFO\n");
	    for(j = 0; j < 1024; j++) {
		if(limit == FIFO_1M_DECODE_TABLE[j]) {
		    limit0 = j;
		    break;
		}
	    }
	    limit++;
	    for(j = 0; j < 1024; j++) {
		if(limit == FIFO_1M_DECODE_TABLE[j]) {
		    limit1 = j;
		    break;
		}
	    }
	}

	buffer[i++] = limit0;			// [10]
	buffer[i++] = limit0 >> 8;		// [11]
	buffer[i++] = limit1;			// [12]
	buffer[i++] = limit1 >> 8;		// [13]

	if(length > 0) {
	    sequenceflag = 0;
	    if(itc->SequenceLength == length) {
		//Check for Sequence itself
		if(memcmp(itc->Sequence, instructions, length << 2) == 0)
		    sequenceflag = 1;
	    }
	    if(sequenceflag == 1)
		length = 0;
	    else {
		//Set new Sequence
		itc->SequenceLength = length;
		memcpy(itc->Sequence, instructions, length << 2);
	    }

	    //Reshape sequence buffer from 32 bit to 16 bit
	    for(entry = 0; entry < length; entry++) {
		buffer[i++] = instructions[entry];
		buffer[i++] = instructions[entry] >> 8;
	    }
	}

	//Add Data Buffer
	for(entry = 0; entry < OutputDataSize; entry++) {
	    buffer[i++] = (char)(OutputData[entry]);
	    buffer[i++] = (char)(OutputData[entry] >> 8);
	}

	i = 0;
	if(itc->initialized == 0)
	    i |= 0x02;
	if(timer_ticks > 0) {
	    i |= 0x04;
	    itc->interval = timer_ticks;
	}

	if(itc->ByteOrderFlag)	{
	    #ifdef DEBUG
	    fprintf(stderr,"ITC18_SmallRun: Are we on a big endian system?\n");
	    #endif
	    i |= 0x08;	//SWAP Data during FIFORead
	}

	itc->initialized = 1;
	itc->data_read = 0;
	itc->data_written = 0;

	//This is STOP Command, used in stop and setsequence
	command = ACQ_CONTROL | AC_STOP_ACQ;
	// Set digital invertion bits.
	if(itc->invert_digital_inputs)
	    command |= AC_INVERT_DIGITAL_INPUTS;

	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_SMALL_RUN,(UWORD)((i << 8) | length),(UWORD)command,buffer,buffersize,TIMEOUT_ONE_SEC); 
	if (status < 0)	{
	    fprintf(stderr,"ITC18_SmallRun: libusb_control_transfer %d\n",status);
	    return ITC18_STATUS_USB_ERROR;	
	}

	if(InputDataSize > 0) {  
	    buffersize = InputDataSize << 1;
	    status = libusb_bulk_transfer(itc->file,USB18_PIPE1_IN_LIBUSB,(UBYTE *)InputData,buffersize,&transferred,TIMEOUT_ONE_SEC); 
	    if (status != 0) {
		fprintf(stderr,"ITC18_SmallRun: libusb_bulk_transfer %d\n",status);
		libusb_clear_halt(itc->file,USB18_PIPE1_IN_LIBUSB);
		return ITC18_STATUS_WRITE_ERROR;
	    }
	    
	}
	return ITC18_STATUS_SUCCESS;

    } else {
	status = ITC18_InitializeAcquisition(device);
	if(status != ITC18_STATUS_SUCCESS) {
	    fprintf(stderr,"ITC18_SmallRun:ITC18_InitializeAcquisition %d\n",status);
	    return status;
	}
	if(OutputDataSize > 0) {
	    status = ITC18_WriteFIFO(device, OutputDataSize, OutputData);
	    if(status != ITC18_STATUS_SUCCESS) {
		fprintf(stderr,"ITC18_SmallRun:ITC18_WriteFIFO %d\n",status);
		return status;
	    }
	}
	status = ITC18_SetupAcquisition(device, 
					0,	//int stop,
					0,	//int initialize, 
					length, instructions, 
					timer_ticks, external_clock,
					1,	//int start,
					external_trigger,	//int external_trigger, 
					output_enable,	//int output_enable,
					1,	//int stoponoverflow,
					0);	//int reserved)
	if(status != ITC18_STATUS_SUCCESS) {
		fprintf(stderr,"ITC18_SmallRun:ITC18_SetupAcquisition %d\n",status);
		return status;
	}
#ifdef _WINDOWS
	starttime = GetTickCount();
#else
	Delay(0, (unsigned long*)&starttime);
#endif

	i = 0;

	do {
	    status = ITC18_GetFIFOReadAvailableOverflow(device, &available, &command);
	    if(command != 0 || status != ITC18_STATUS_SUCCESS) {
		//Overflow
		fprintf(stderr,"ITC18_SmallRun:ITC18_GetFIFOReadAvailableOverflow %d\n",status);
		ITC18_StopAndInitialize(device, 1, 1);	
		return ITC18_STATUS_FIFO_OVERFLOW;
	    }

#ifdef _WINDOWS
	    currenttime = GetTickCount();			//return milliseconds
#else
	    Delay(0, (unsigned long*)&currenttime);
#endif
	    //Timeout in case counter does not increment for one tick (10ms)
	    if((currenttime - starttime) > (timer_ticks * 1.25) + 55) {
//			ITC16_Stop(Info->LocalInfo);	
		ITC18_StopAndInitialize(device, 1, 1);	
		fprintf(stderr,"ITC18_SmallRun:ITC18_STATUS_ROM_TIMEOUT\n");
		return ITC18_STATUS_ROM_TIMEOUT;
	    }
	    //Reset timer, if counter increments
	    if(i != available) {
		i = available;
#ifdef _WINDOWS
		starttime = GetTickCount();
#else
		Delay(0, (unsigned long*)&starttime);
#endif
	    }
	}
	while(available < (int)limit);

	if(InputDataSize > 0) {
	    status = ITC18_ReadFIFO(device, 3, (short*)buffer);
	    status = ITC18_ReadFIFO(device, InputDataSize, InputData);
	}
	ITC18_StopAndInitialize(device, 1, 1);
    }
	
    return status;
}

ITC_CALL int ITC18_SingleWriteROM34(void* device, int Port, int Value)
{
    struct ITC18* itc = (struct ITC18*) device;
    int status;

    if(itc->USBVersion >= 0x00050000) {
	//Redirect writing to ROM3
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
	status = libusb_control_transfer(itc->file,CTRL_OUT,(UBYTE)_USB_A_WRITE_ROM3,(UWORD)Value,(UBYTE)Port,NULL,0,TIMEOUT_ONE_SEC); 
	if (status < 0) return ITC18_STATUS_USB_ERROR;
	else return ITC18_STATUS_SUCCESS;
    }

    return ITC18_STATUS_USB_ERROR;
}

ITC_CALL int ITC18_SingleReadROM4(void* device, short* Value)
{
    struct ITC18* itc = (struct ITC18*) device;
    unsigned char buffer[2];
    int status;

    if(itc->USBVersion >= 0x00050001) {
	//Redirect writing to ROM3
	//libusb_control_transfer(dev_handle,bmRequestType,bRequest,wValue,wIndex,data,wLength,timeout);    
	status = libusb_control_transfer(itc->file,CTRL_IN,(UBYTE)_USB_A_READ_ROM4,(UWORD)0,(UWORD)0,buffer,2,TIMEOUT_ONE_SEC); 
	if (status < 0)
	    return ITC18_STATUS_USB_ERROR;
	*Value = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
    } 
    
    return ITC18_STATUS_SUCCESS;
}

///////////////////////////////////////////////////////////////////////
/////////////// USB DC ////////////////////////////////////////////////
ITC_CALL int ITC18_StartUSBDC(	void* device, 
				int external_trigger, 
				int output_enable,
				int stoponoverflow,
				int stoponunderrun)
{
    int command;
    int mask;
    struct ITC18* itc = (struct ITC18*) device;

    if(itc->USBVersion < 0x00070000)
	return ITC18_STATUS_USB_ONLY;

    itc->initialized = 0;

    // Set up the output enable
    mask = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
	    
    if(stoponoverflow != 0)
	mask |= FC_STOP_OVR;

    if (!output_enable)
	mask |= FC_DA_INHIBIT;

    command = ACQ_CONTROL;

    // Set digital invertion bits.
    if (itc->invert_digital_inputs)
	command |= AC_INVERT_DIGITAL_INPUTS;

    if (external_trigger & 1)
	command |= AC_ACQ_ON_TRIGGER;
    else
	command |= AC_START_ACQ;

    return ITC18_STATUS_SUCCESS;
}
#ifdef __linux__

void Delay(unsigned long dummy, unsigned long *currenttime) {

    struct timeval  time;
    
    gettimeofday(&time, NULL);
    *currenttime = (time.tv_sec * 1000) + (time.tv_usec / 1000);

    #ifdef DEBUG
    fprintf(stderr,"Delay %ld\n",*currenttime);
    #endif

    return;
}
#endif
