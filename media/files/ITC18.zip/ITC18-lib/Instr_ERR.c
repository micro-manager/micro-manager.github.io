#include "windows.h"
#include "winioctl.h"
#include "Instr_ERR.h"

INSTR_ERR LONG GetErrorType(LONG ErrorCode,
							LONG MaxSize,
							char* info)
{
LONG CurSize = MaxSize;
LONG lTemp;
char lbuffer[2];

	//Check if no errors found
	if((ErrorCode & 0x80000000) == 0)
		{
		strncpy(info,SUCCESS,MaxSize);
		if(MaxSize >= sizeof(SUCCESS))
			return 0;
		else
			return -1;
		}

	///////////////////////////////////////////////
	//Device Type
	///////////////////////////////////////////////
	strncpy(info,DEVICE,CurSize);
	CurSize -= sizeof(DEVICE);
	if(CurSize <= 0)
		return -1;
	switch((ErrorCode & 0x0000F000) >> 12)
		{
		case 0:
			strncat(info,DVP32,CurSize);
			CurSize -= sizeof(DVP32);
			break;
		case 1:
			strncat(info,ITC1XXX,CurSize);
			CurSize -= sizeof(ITC1XXX);
			break;
		default:
			strncat(info,UNKNOWN,CurSize);
			CurSize -= sizeof(UNKNOWN);
		}
	if(CurSize <= 0)
		return -1;

	///////////////////////////////////////////////
	//Error Type
	///////////////////////////////////////////////
	strncat(info,ERRTYPE,CurSize);
	CurSize -= sizeof(ERRTYPE);
	if(CurSize <= 0)
		return -1;
	switch((ErrorCode & 0x00F00000) >> 20)
		{
		case 0:
			strncat(info,VERSION,CurSize);
			CurSize -= sizeof(VERSION);
			break;
		case 1:
			strncat(info,OPEN,CurSize);
			CurSize -= sizeof(OPEN);
			break;
		case 2:
			strncat(info,CLOSE,CurSize);
			CurSize -= sizeof(CLOSE);
			break;
		case 3:
			strncat(info,POWER,CurSize);
			CurSize -= sizeof(POWER);
			break;
		case 4:
			strncat(info,ALLOCATION,CurSize);
			CurSize -= sizeof(ALLOCATION);
			break;
		case 5:
			strncat(info,READY,CurSize);
			CurSize -= sizeof(READY);
			break;
		case 6:
			strncat(info,COMMAND,CurSize);
			CurSize -= sizeof(COMMAND);
			break;
		case 7:
			strncat(info,PARAMETER,CurSize);
			CurSize -= sizeof(PARAMETER);
			break;
		case 8:
			strncat(info,MEMORY,CurSize);
			CurSize -= sizeof(MEMORY);
			break;
		case 9:
			strncat(info,ADDRESS,CurSize);
			CurSize -= sizeof(ADDRESS);
			break;
		case 10:
			strncat(info,SIZE,CurSize);
			CurSize -= sizeof(SIZE);
			break;
		case 11:
			strncat(info,READ,CurSize);
			CurSize -= sizeof(READ);
			break;
		case 12:
			strncat(info,WRITE,CurSize);
			CurSize -= sizeof(WRITE);
			break;
		case 13:
			strncat(info,STATE,CurSize);
			CurSize -= sizeof(WRITE);
			break;
		case 14:
			strncat(info,SPECIFIC,CurSize);
			CurSize -= sizeof(WRITE);
			break;
		default:
			strncat(info,UNKNOWN,CurSize);
			CurSize -= sizeof(UNKNOWN);
		}
	if(CurSize <= 0)
		return -1;

	///////////////////////////////////////////////
	//Error Number
	///////////////////////////////////////////////
	strncat(info,ERRGNUMBER,CurSize);
	CurSize -= sizeof(ERRGNUMBER);
	if(CurSize <= 0)
		return -1;
	
	lbuffer[1] = 0;
	lTemp = (ErrorCode & 0x000F0000) >> 16;
	if(lTemp < 10)
		lbuffer[0] = '0' + (char)lTemp;
	else
		lbuffer[0] = 'A' + (char)lTemp - 10;
	strncat(info,lbuffer,CurSize);
	CurSize -= sizeof(lbuffer);

	strncat(info,ERRLNUMBER,CurSize);
	CurSize -= sizeof(ERRLNUMBER);
	if(CurSize <= 0)
		return -1;
	
	lTemp = (ErrorCode & 0x0000000F);
	if(lTemp < 10)
		lbuffer[0] = '0' + (char)lTemp;
	else
		lbuffer[0] = 'A' + (char)lTemp - 10;
	strncat(info,lbuffer,CurSize);
	CurSize -= sizeof(lbuffer);

	///////////////////////////////////////////////
	//Error Place
	///////////////////////////////////////////////
	strncat(info,PLACE,CurSize);
	CurSize -= sizeof(PLACE);
	if(CurSize <= 0)
		return -1;
	switch((ErrorCode & 0x70000000) >> 28)
		{
		case 0:
			strncat(info,USER,CurSize);
			CurSize -= sizeof(USER);
			break;
		case 1:
			strncat(info,KERNEL,CurSize);
			CurSize -= sizeof(KERNEL);
			break;
		case 2:
			strncat(info,DSP,CurSize);
			CurSize -= sizeof(DSP);
			break;
		case 3:
			strncat(info,VDFS,CurSize);
			CurSize -= sizeof(VDFS);
			break;
		case 4:
			strncat(info,TESTS,CurSize);
			CurSize -= sizeof(TESTS);
			break;
		case 5:
			strncat(info,SPECIFIC,CurSize);
			CurSize -= sizeof(SPECIFIC);
			break;
		default:
			strncat(info,UNKNOWN,CurSize);
			CurSize -= sizeof(UNKNOWN);
		}
	if(CurSize <= 0)
		return -1;

	///////////////////////////////////////////////
	//Connection
	///////////////////////////////////////////////
	strncat(info,CONN,CurSize);
	CurSize -= sizeof(CONN);
	if(CurSize <= 0)
		return -1;
	switch((ErrorCode & 0x0F000000) >> 24)
		{
		case 0:
			strncat(info,USER,CurSize);
			CurSize -= sizeof(USER);
			break;
		case 1:
			strncat(info,KERNEL,CurSize);
			CurSize -= sizeof(KERNEL);
			break;
		case 2:
			strncat(info,DSP,CurSize);
			CurSize -= sizeof(DSP);
			break;
		case 3:
			strncat(info,VDFS,CurSize);
			CurSize -= sizeof(VDFS);
			break;
		case 4:
			strncat(info,DMA,CurSize);
			CurSize -= sizeof(DMA);
			break;
		case 5:
			strncat(info,TABLES,CurSize);
			CurSize -= sizeof(TABLES);
			break;
		case 6:
			strncat(info,OVERLAYS,CurSize);
			CurSize -= sizeof(OVERLAYS);
			break;
		case 7:
			strncat(info,DPR,CurSize);
			CurSize -= sizeof(DPR);
			break;
		case 8:
			strncat(info,INTERFACE_ITC,CurSize);
			CurSize -= sizeof(INTERFACE_ITC);
			break;
		case 9:
			strncat(info,U2FT,CurSize);
			CurSize -= sizeof(U2FT);
			break;
		case 10:
			strncat(info,LCA,CurSize);
			CurSize -= sizeof(LCA);
			break;
		case 11:
			strncat(info,FRAME,CurSize);
			CurSize -= sizeof(FRAME);
			break;
		case 12:
			strncat(info,TIMER,CurSize);
			CurSize -= sizeof(TIMER);
			break;
		case 13:
			strncat(info,REGISTRY,CurSize);
			CurSize -= sizeof(REGISTRY);
			break;
		default:
			strncat(info,UNKNOWN,CurSize);
			CurSize -= sizeof(UNKNOWN);
		}


	if(CurSize < 0)
		return -1;

return 0;
}




