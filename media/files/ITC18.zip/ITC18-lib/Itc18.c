//  Interface procedures for the Instrutech ITC18.
//
// Copyright (c) 1991, 2000 Instrutech Corporation, Port Washington, NY, USA
//
// Created by SKALAR Instruments, Seattle, WA, USA
// with help from Instrutech Corporation.
//
//	Modified by Michael Mazlin, Instrutech Corporation, 1/7/2000
//	Added multiple device support for windows 95/98 and NT
//
//  Modified by Telly Galiatsatos, Instrutech Corporation, 6/14/2000
//	Added multiple device support for MacOS
//	Changed GetVersion to support MAC and remove stncpy commands TG 6/27/2000
//
//	Fixed bug with ITC18DACShift TG 9/22/2000
//  Add a new function "Allocate Memory" Version: 3.2 -> 3.3 Mike 9/25/2000
//	Fixed bug with same global variables in both ITC16 and ITC18 libraries TG 9/25/2000
//  Fixed "Open Device" For ISA Card Version: 3.3 -> 3.4 Mike 11/29/2000
//  Fixed "SetTriggerMode" 3.4 -> 3.5 Mike 12/25/2000
//  Add "Green Light" 3.5 -> 3.6 Mike 1/29/2001
//	Fix Read Rom bug, Add Read/Write PCI Config Space 3.6->3.7
//	Add Function ITC18_ReadPCIROMSector, ITC18_WritePCIROMSector 3.7 -> 3.8
//  In ReadROM: 7/26/2001 Add resetting LC_DATA bit 3.8 -> 3.9
//	In ReadRom: 7/27/2001 Added additional LCA reset before read still 3.9
//	In WriteRom: 9/25/2001 Modify to support different EEPROM (SST29EE010 + SST39SF010) 3.9 -> 4.0
//	ITC18_Close return reference number before actual driver close 11/21/2001 4.0 -> 4.1
//	Add macintosh timer commands for EEPROM fonctions. 4.1 -> 4.2
//	VA 11.01.02 -> Add MAC OSX Support 4.2 -> 4.3
//	Mike 11.19.02 -> Copy from ITC16 4.3 -> 4.4
//	Mike 12.12.02 Replace CurrentDevice18 with itc->DeviceNumber
//		fix mactinosh, add swapping to readPCIserial number 4.4->4.5
//	Mike 4.4.04 -> Change optional memory allocation to nonpaged pool, 
//					Synchronize OSes, Add Release/Reserve for MacOSX 4.5->4.6
//	Mike 7.30.03 -> MacOSX add driver features 4.6->4.7
//	Mike 1.26.04 -> Add option to stop on overflow to ITC18_Start() 4.7 -> 4.8
//	Mike 2.10.04 -> Hubert ask to remove ZeroMemory for classic static lib 4.8->4.9
//	Mike 6.23.04 -> Add USB Support 4.9 -> 5.0
//					DeviceNumber has USB Select Bit now
//	Mike 7.19.04 -> Add function ITC18_GetFIFOReadAvailableAndOverflow
//					combine 2 function in one 5.0 -> 5.1
//	Mike 1.19.05 -> Add functions to talk to the USB box specific hardware 5.1 -> 5.2
//	Mike 1.25.05 -> Check if "force" USB file is exist 5.2 -> 5.3
//	Mike 1.27.05 -> Add USB Function to read EPROM. Same version
//	Mike 2.03.05 -> Fix USB Emedded read rom function. Same version
//	Mike 2.28.05 -> Add Reading USB Serial Number for Windows. Same version
//	Mike 3.04.05 -> Modify "C5" USB Command to read Serial Number. 5.3 -> 5.4
//	Mike 5.05.05 -> Make ITC16 and ITC18 strucutre the same 5.4 -> 5.5
//	Mike 5.18.05 -> Add Timer functions	5.5 -> 5.6
//	Mike 6.07.05 -> Add loading USB core via U2F
//	Mike 6.12.05 -> Fix ForceUSB stuff
//	Mike 6.15.05 -> Add apples registry functions 5.6 -> 5.7
//	Mike 8.01.05 -> Add return driver handle device function 5.7 -> 5.8
//	Mike 10.17.05 -> Add new functions to support USB slow cycles 5.8 -> 5.9
//	Mike 11.15.05 -> Cleaning 5.9 -> 5.10
//	Mike 11.18.05 -> Add Reload check for Sequence and Sampling 5.10 -> 6.0
//	Mike 03.02.06 -> Add optimization for USB. Keep FIFO in data write mode 6.1 -> 6.2
//	Mike 03.22.06 -> Add optimization for USB. Read/Write data 6.2 -> 6.3
//	Mike 03.27.06 -> USB Require swapping. Add temporaly storage, so we don't destroy the original data 6.3 -> 6.4
//Comment: probably should not allocate each time we eneter function
//	Mike 04.25.06 -> Somehow some program gives me the error on the second run
//probably something not clears of stuck. During open try to clear it by dummy FIFO read.
//Add a special function to read small amount of data from FIFO in one shot via EP0 6.4 -> 6.5
//	Mike 05.12.06 -> Read USB Version again after reloading USB box 6.5 -> 6.6
//Add serial number restore and delay after loading ISB
//Transfer size * 4 only for ROM4
// Mike 05.31.06 -> Add dummy small run to clear EP1
// Mike 07.19.06 -> Write-Read to USB with one command (MacOSX). Add synchronizing USB firmware. 6.6 -> 6.7
// Mike 07.24.06 -> Modify Control USB Timers command. 6.7 -> 6.8
// Mike 07.24.06 -> Add external trigger to start by timer
// Mike 10.12.06 -> Fix close device, if not present 6.8 -> 6.9
// Mike 10.12.06 -> Add swapping byte control flag 6.9 -> 6.10
// Mike 03.15.07 -> Divide initialization string to small chunks 6.10 -> 6.11
// Mike 05.10.07 -> Fix 64K Input from USB bug 6.11 -> 6.12

//#define __MIKE_TEST_TIME__18__

#ifdef __MIKE_TEST_TIME__18__

#ifdef _WINDOWS
__int64 New, Start;
#else
UnsignedWide New, Start;
#endif
long tCounterRead;
long tCounterWrite;
long tTimeRead18[16];
long tTimeWrite18[16];

#endif

#define MAX_ITC18_NUMBER 16

#define _USB_OUTPUT_TRANSFER_SIZE_18_	64 * 1024 * 2

#define __USE_USB_COMMANDS__
#define _USE_CONTROL_REQUEST_
//#define _USE_INTERRUPT_TRANSFERS_18_
///RRR
//#define _USE_ASYNC_TRANSFERS_18_W
//#define _USE_ASYNC_TRANSFERS_18_R

#define	PCI18_DEVICE_TYPE			0
#define	USB18_DEVICE_TYPE			1

#define USB18_ROM3_PORT				0

#define USB18_PIPE1_IN				5
#define USB18_PIPE1_OUT				4
#define USB18_ROM3_PIPE				2
#define USB18_ROM4_PIPE				1
#define USB18_ROM4_PIPE_READ		0

#define USB18_PIPE1_IN_MACOSX		6
#define USB18_PIPE1_OUT_MACOSX		5
#define USB18_ROM3_PIPE_MACOSX		3
#define USB18_ROM4_PIPE_MACOSX		2
#define USB18_ROM4_PIPE_READ_MACOSX	1

// Platforms: _WINDOWS, __APPLE__ (MacOSX), _MACINTOSH (machintosh) = __powerpc & __nubus
//STUB: Mike: what is NUBUS definition???

#ifdef macintosh
	#define _MACINTOSH
	#include <stdlib.h>
	#include "Compatibility.h"
#endif

#ifdef __APPLE__
	#undef _MACINTOSH
	#undef __powerc
	#include <ApplicationServices/ApplicationServices.h>
	#include <unistd.h>

	#include <stdio.h>
	#include <ppc/limits.h>
	#include <mach/mach.h>
	#include <CoreFoundation/CoreFoundation.h>
	#include <IOKit/IOKitLib.h>
	#include <time.h>
	#include <fcntl.h>	//For O_RDONLY in XCode 2.1
	//USB
	#include <IOKit/IOCFPlugIn.h>
	#include <IOKit/usb/IOUSBLib.h>

	#include "Compatibility.h"
	
//	#include <OSAtomic.h>	//eieio

	enum {kITC18_Regs};
        enum
        {
        kITC18ConfigRead,
        kITC18ConfigWrite,
        kITC18IORead,
        kITC18IOWrite,
        kITC18GetVersion,
        kITC18AllocateMemory,
        kITC18FreeMemory,
		kITC18SetRegistry,
		kITC18GetRegistry,
        kITC18NumberOfMethods
        };
        enum
        {
        kUSB18GetVersion,
        kUSB18AllocateMemory,
        kUSB18FreeMemory,
		kUSB18SetRegistry,
		kUSB18GetRegistry,
        kUSB18NumberOfMethods
        };
#endif // __APPLE__

#ifdef _WINDOWS
	#include <windows.h>
	#include <winioctl.h>
	#include <io.h>					//For _access
	#include <stdio.h>				//For Loading USB
	#include "ITC18_IOCtl.h"
#endif

#ifdef _MACINTOSH
	#include <errors.h>
	#include <files.h>
	#include <folders.h>
	#include <gestalt.h>
	#include <timer.h>

	#ifdef __powerc
		#include <Devices.h>
		#include <Interrupts.h>
		#include <DriverServices.h>
	#endif

	#include <slots.h>
	#ifdef __powerc
		#include <PCI.h>
		#include "NameRegistry.h"
		#include "CodeFragments.h"
	#endif
#endif

#include <limits.h>

#include "ITC18.h"
#include "fifodcod.h"
#include "ITC18_LCA.h"

#include "itcusb.h"
#include "Instr_U2F.h"

// ITC18_STATUS values
//
// Functions that return a value generally return an ITC18_STATUS value.
// If a function succeeds, it returns ITC18_STATUS_SUCCESS. Note that
// ITC18_STATUS_SUCCESS is guaranteed to be zero. All other values
// represent errors.

enum
{
	ITC18_STATUS_SUCCESS = 0,

	// Status values are in alphabetical order. Please keep them that way.
	ITC18_STATUS_BOARD_NOT_FOUND,
	ITC18_STATUS_CREATE_RESERVE_FILE,
	ITC18_STATUS_DRIVER_OPEN,
	ITC18_STATUS_FIFO_OVERFLOW,
	ITC18_STATUS_FIFO_UNDERFLOW,
	ITC18_STATUS_GET_VERSION,
	ITC18_STATUS_OPEN_REGISTRY_KEY,
	ITC18_STATUS_OPEN_RESERVE_FILE,
	ITC18_STATUS_PCI_NOACCESS,
	ITC18_STATUS_PCI_NOLINK,
	ITC18_STATUS_PCI_NOMAP,
	ITC18_STATUS_PREFERENCES_FOLDER,
	ITC18_STATUS_READ_ERROR,
	ITC18_STATUS_READ_INVALID,
	ITC18_STATUS_READ_LENGTH,
	ITC18_STATUS_RELEASE,
	ITC18_STATUS_RESERVE,
	ITC18_STATUS_ROM_INVALID_ADDRESS,
	ITC18_STATUS_ROM_WRITE,
	ITC18_STATUS_SET_PORT,
	ITC18_STATUS_SIGNATURE_INTERFACE,
	ITC18_STATUS_SIGNATURE_ISOLATED,
	ITC18_STATUS_SIGNATURE_LOADER,
	ITC18_STATUS_TXHEM_TIMEOUT,
	ITC18_STATUS_UNKNOWN_STATUS,
	ITC18_STATUS_VALUE_MODEL_VARIANT,
	ITC18_STATUS_WRITE_ERROR,
	ITC18_STATUS_WRITE_INVALID,
//Mike
	ITC18_STATUS_PCI_NOMULTIPLE,	//29
	ITC18_STATUS_NO_MEMORY,
	ITC18_STATUS_NOT_IMPLEMENTED,
	ITC18_STATUS_ROM_NOT_SUPPORTED,
	ITC18_STATUS_ROM_TIMEOUT,
	ITC18_STATUS_USB_NOT_SUPPORTED,
	ITC18_STATUS_USB_ERROR,
	ITC18_STATUS_USB_BOARD_NOT_FOUND,
	ITC18_STATUS_USB_OLD_VERSION,
	ITC18_STATUS_USB_ONLY
};

#ifdef _MACINTOSH

	#ifdef __powerc

// Function DynamicLinkLoad
// Function DynamicLinkUnload
//
// Perform all required dynamic linking for PCI handling.

//Mike -> Actually should remove this garbage and just link statically 

struct DynamicLinkStruct
{
	// NameRegistry library
	CFragConnectionID name_registry;

	OSStatus (*registry_entry_ID_copy)(RegEntryID*, RegEntryID*);
	OSStatus (*registry_entry_ID_dispose)(RegEntryID*);
	OSStatus (*registry_entry_ID_init)(RegEntryID*);
	OSStatus (*registry_entry_iterate_create)(RegEntryIter*);
	OSStatus (*registry_entry_iterate_dispose)(RegEntryIter*);
	OSErr (*registry_property_get)(const RegEntryID*, const RegPropertyName*, void*, RegPropertyValueSize *);
	OSErr (*registry_property_get_size)(const RegEntryID*, const RegPropertyName*, RegPropertyValueSize *);

	OSStatus (*registry_entry_search)(	RegEntryIter*,
										RegEntryIterationOp,
										RegEntryID*,
										Boolean*,
										const RegPropertyName*,
										const void*,
										RegPropertyValueSize);

	// DriverServices library
	CFragConnectionID driver_services;

	RegEntryID entry;
	void (*synchronize_io)();
	pascal UInt32 (*endian_swap_32_bit)(UInt32);

	LogicalAddress (*pool_allocate_resident)(ByteCount, Boolean);
	OSStatus (*pool_deallocate)(LogicalAddress);

	// PCI library
	CFragConnectionID pci;
	pascal OSErr (*exp_mgr_config_read_word)(RegEntryIDPtr, LogicalAddress, UInt16*);
	pascal OSErr (*exp_mgr_config_write_word)(RegEntryIDPtr, LogicalAddress, UInt16);
	pascal OSErr (*exp_mgr_config_read_byte)(RegEntryIDPtr, LogicalAddress, UInt8*);
	pascal OSErr (*exp_mgr_config_write_byte)(RegEntryIDPtr, LogicalAddress, UInt8);
	pascal OSErr (*exp_mgr_config_read_long)(RegEntryIDPtr, LogicalAddress, UInt32*);
	pascal OSErr (*exp_mgr_config_write_long)(RegEntryIDPtr, LogicalAddress, UInt32);
};
#endif
#endif

// Structure ITC18
//
// This structure defines an ITC18 to the driver.
//
// Port is the ITC18 I/O port base address.
//
// DataRead is the number of data points read from the FIFO since the start
// of acquisition. It is reset to zero each time acquisition is started.
//
// DataWritten is the number of data points written to the FIFO since the
// start of acquisition. It is reset to zero each time WriteFIFOReset is
// called.

#include "ITC18Structure.h"

//Mike: Version
//Mike: Add Version, modified MM 7/26/2001

#define MAJOR_VERSION	6
#define MINOR_VERSION	12
#ifdef _WINDOWS
	#define DESCRIPTION		"ITC-18 (PCI and USB) driver for Windows OS"
#else
	#ifdef __INTEL__
		#define DESCRIPTION		"ITC-18 (PCI and USB) driver for MacOSX 4.6 or later (PPC and Intel platform)"
	#else
		#define DESCRIPTION		"ITC-18 (PCI and USB) driver for MacOSX (PPC platform only)"
	#endif
#endif
#define DATE			"May 10, 2007"

//Mike
//Add version info
typedef struct
	{
	long major_version;
	long minor_version;
	char description[80];
	char date[80];
	}
version_struct;

// ITC18 Hardware parameters

#define INTERFACE_LCA_SIZE 8064
#define ISOLATED_LCA_SIZE 11904
#define LOADER_SIGNATURE 0x3c
#define ISOLATED_SIGNATURE 0x3c
#define INTERFACE_SIGNATURE 0x3b

#define ITC18_1M_FIFO (1024*1024)
#define ITC18_256K_FIFO (256*1024)

#define ROM_FIFO_SIZE_MASK 0x00000001
#define ROM_FIFO_SIZE 3
#define ROM_WRITE_RETRY 3

// Offsets from the base port address.

#define PORT_LATCH		0x0
#define PORT_DATA		0x4
#define PORT_PCI		0x8
#define PORT_PCI_DATA	0xA

// ITC18 Control and Data Registers
//
// Use these constants to form bitfields where the upper four bits select
// which register is being written to, and the remaining bits are the values
// of the control bits in the register.

// LCA_CONTROL controls the programming of the LCAs.  Note that the LCAs CCLK
// connects to itc->port_data.

#define LCA_CONTROL 0x8000

#define LC_PROG		0x0001 // Set to program the LCA.
// This is the data bit when programming the LCA, and the Read control bit.
#define LC_DATA		0x0002 
#define LC_RESET	0x0004
#define LC_CS		0x0008

// FIFO_CONTROL

#define FIFO_CONTROL 0x4000

#define FC_FIFO_RESET	0x0000
#define FC_FIFO_ENABLE	0x0001 // enables FIFO
#define FC_STOP_OVR		0x0002 // stop acquisition on A/D overflow
#define FC_DA_INHIBIT	0x0004 // stop acquisition on D/A underflow. Now Disable Output

// ACQ_CONTROL

#define ACQ_CONTROL	0x2000

#define AC_STOP_ACQ					0x0000
#define AC_START_ACQ				0x0001
#define AC_ACQ_ON_TRIGGER			0x0002
#define AC_INVERT_DIGITAL_INPUTS	0x000C
#define AC_READY_LIGHT_OFF			0x0010
#define AC_READY_LIGHT_ON			0x0011
#define AC_LATCH_ENABLE				0x0012
#define AC_EXTERNAL_CLOCK			0x0018
#define AC_EXTERNAL_TRIGGER_INVERT	0x0024
#define AC_EXTERNAL_TRIGGER_TRANSITION 0x0028
#define AC_BANK_SELECT				0x0030
#define AC_DAC_SHIFT				0x0080

// 0x002x and 0x003x are reserved, do not use

// OR the selected nibble's timer data into the lower four bits when using
// the AC_SEND_TIMER masks.

#define AC_SEND_TIMER_N0 0x0040
#define AC_SEND_TIMER_N1 0x0050
#define AC_SEND_TIMER_N2 0x0060
#define AC_SEND_TIMER_N3 0x0070

// OR the selected nibble's sequence RAM data into the lower four bits when
// using the AC_SEND_SEQL masks.

#define AC_SEND_SEQL_N0	0x0080
#define AC_SEND_SEQL_N1	0x0090
#define AC_SEND_SEQL_N2	0x00a0

// This writes the previously loaded data into the sequence RAM and advances the
// sequencer pointer.  The sequencer write operation must be preceded by a write
// of 0x2000 to COMMAND_PORT to stop acquisition and perform a sequencer reset.

#define AC_SEQ_WRITE 0x00b0

// DATA_SELECT and its control bits determine where the data written to or read
// from itc->port_data goes to or came from. The EPC-9 clipping bit may also be
// accessed.

#define DATA_SELECT	0x1000

#define DS_READ_FIFO_DATA	0x0000
#define DS_READ_FIFO_PTR	0x0001 // low 16 bits only, upper 4 in status word
#define DS_READ_STATUS		0x0002 // bits 0...3 are bits 15...19 of the FIFO pointer
#define DS_WRITE_FIFO_DATA	0x0003
#define DS_CLIPPING_RESET	0x0006

#define STATUS_RORERR 0x8000
#define STATUS_TURERR 0x4000
#define STATUS_CLIPERR 0x2000
// reserved do not use 	0x1000
#define STATUS_TXHEM 0x0800
// bits 4 through 10 access the LCAs' signatures
// bits 0 through 3 access bits 16 through 19 of the FIFO pointer.

// PCI control fields

#define PCI_SWAP 0x0008

int DelayXYZ(void* device, int microseconds);
int WaitROM(void* device, int address);
int SetROMMode(void* device, int mode);
int GetROMSoftID(void* device, unsigned* SoftID);
int ITC18_WaitPCIROM(void* device, int address);
int ITC18_SetPCIROMMode(void* device, int mode);
int ITC18_GetPCIROMSoftID(void* device, unsigned* SoftID);


// Function local_strcpy( char* target, char* source, int length)
//
// Do not use the standard "C" "strcpy", since this would pull in the 
// C library, which may not be desired.
// TG 6/27/2000

static void local_strcpy(char* target, char* source, int length);

void local_strcpy(char* target, char* source, int length)
{
	while ((--length > 0) && (*source != '\0'))
		{
		*target++ = *source++;
		}

	*target = '\0';
}


// Function ITC18_GetStatusText
//
// Return a status value as a text string in "text". The
// array "text" contains "length" characters.

ITC_CALL int ITC18_GetStatusText(void* device, int status, char* text, int length)
{
#ifndef _WINDOWS
#pragma unused(device)
#endif

	char* message;

	int result = ITC18_STATUS_SUCCESS;

	switch (status)
	{
	case ITC18_STATUS_SUCCESS:
		message = "Success";
		break;
	case ITC18_STATUS_BOARD_NOT_FOUND:
		message = "ITC-18 Interface could not be located.";
		break;

	case ITC18_STATUS_CREATE_RESERVE_FILE:
		message = "Unable to create the reserve file.";
		break;

	case ITC18_STATUS_DRIVER_OPEN:
//Mike: This message may have "Hardware missing" problem
//		message = "Driver not installed. Please install driver.";
		message = "Driver or host interface card not installed.";
		break;

	case ITC18_STATUS_FIFO_OVERFLOW:
		message = "Input FIFO overflow. Data acquisition too fast for program.";
		break;

	case ITC18_STATUS_FIFO_UNDERFLOW:
		message = "Input FIFO underflow. Internal program error.";
		break;

	case ITC18_STATUS_GET_VERSION:
		message = "GetVersionEx system call failed. Operating system conflict.";
		break;

	case ITC18_STATUS_OPEN_REGISTRY_KEY:
		message = "Driver registry entry missing. Please install driver.";
		break;
	
	case ITC18_STATUS_OPEN_RESERVE_FILE:
		message = "Unable to open the reserve file.";
		break;

	case ITC18_STATUS_PCI_NOACCESS:
		message = "Unable to access PCI board using I/O space";
		break;

	case ITC18_STATUS_PCI_NOLINK:
		message = "Unable to link to PCI dynamic libraries";
		break;

	case ITC18_STATUS_PCI_NOMAP:
		message = "Unable to map PCI board I/O into accessable space.";
		break;

	case ITC18_STATUS_PREFERENCES_FOLDER:
		message = "Unable to find the preferences folder.";
		break;

	case ITC18_STATUS_READ_ERROR:
		message = "Read from kernel driver or VxD failed. Internal error.";
		break;

	case ITC18_STATUS_READ_INVALID:
		message = "Read length invalid. Internal error.";
		break;

	case ITC18_STATUS_RELEASE:
		message = "Unable to release the device. The kernel driver may need to be updated.";
		break;

	case ITC18_STATUS_RESERVE:
		message = "Unable to reserve the device. The kernel driver may need to be updated.";
		break;

	case ITC18_STATUS_ROM_INVALID_ADDRESS:
		message = "Invalid ROM address.";
		break;

	case ITC18_STATUS_ROM_WRITE:
		message = "Write to ROM failed.";
		break;
	
	case ITC18_STATUS_SET_PORT:
		message = "Set port to kernel driver or VxD failed. Internal error.";
		break;

	case ITC18_STATUS_SIGNATURE_INTERFACE:
		message = "Incorrect interface LCA signature. Check device.";
		break;

	case ITC18_STATUS_SIGNATURE_ISOLATED:
		message = "Incorrect isolated LCA signature. Check device.";
		break;

	case ITC18_STATUS_SIGNATURE_LOADER:
		message = "Incorrect loader LCA signature. Check device.";
		break;

	case ITC18_STATUS_TXHEM_TIMEOUT:
		message = "Device TXHEM signal timed out. Device error.";
		break;

	case ITC18_STATUS_UNKNOWN_STATUS:
		message = "Unknown driver status value. Internal error.";
		break;

	case ITC18_STATUS_VALUE_MODEL_VARIANT:
		message = "Incorrect model variant. Please install driver.";
		break;

	case ITC18_STATUS_WRITE_ERROR:
		message = "Write to kernel driver or VxD failed. Internal error.";
		break;

	case ITC18_STATUS_WRITE_INVALID:
		message = "Write length invalid. Internal error.";
		break;

//Mike
	case ITC18_STATUS_PCI_NOMULTIPLE:
		message = "This Driver does not support multiple ITC18's.";
		break;

	case ITC18_STATUS_NO_MEMORY:
		message = "Out of memory.";
		break;

	case ITC18_STATUS_NOT_IMPLEMENTED:
		message = "This function is not implemented.";
		break;
		
	case ITC18_STATUS_ROM_NOT_SUPPORTED:
		message = "ROM is not supported.";
		break;

	case ITC18_STATUS_ROM_TIMEOUT:
		message = "ROM communication error.";
		break;

	case ITC18_STATUS_USB_NOT_SUPPORTED:
		message = "USB-18 Device is not supported.";
		break;
		
	case ITC18_STATUS_USB_ERROR:
		message = "USB-18 communication error";
		break;
		
	case ITC18_STATUS_USB_BOARD_NOT_FOUND:
		message = "USB-18 board not found";
		break;

	default:
		message = "Unknown driver status value. Internal error.";
		result = ITC18_STATUS_UNKNOWN_STATUS;
		break;
	}

	local_strcpy(text, message, length);

	return result;
}

// Function DelayMicroseconds
//
// Perform a delay of at least the specified number of microseconds.

static void DelayMicroseconds(int period)
{
#ifdef _WINDOWS
	int milliseconds;
	OSVERSIONINFO OsVersionInfo;

	milliseconds = (period + 999) / 1000;

	OsVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	
	GetVersionEx(&OsVersionInfo);

	if (OsVersionInfo.dwPlatformId == VER_PLATFORM_WIN32s)
		{
		DWORD start = GetTickCount();

		while (((int) (GetTickCount() - start)) < milliseconds)
			{
			Sleep(milliseconds);
			}
		} 
	else 
		{
		Sleep(milliseconds);
		}
#endif

#ifdef _MACINTOSH
	volatile TMTask task;

	task.qLink = 0;
	task.qType = 0;
	task.tmAddr = 0;
	task.tmCount = 0;
	task.tmWakeUp = 0;
	task.tmReserved = 0;

	InsXTime((QElemPtr) &task);

	PrimeTime((QElemPtr) &task, -period);

	while (task.qType & 0x8000)
		{}

	RmvTime((QElemPtr) &task);
#endif

#ifdef __APPLE__

	usleep(period);
/*
     //   IODelay(period);
     int size = 0;
     int args[1];
     args[0] = period;
     kr = io_connect_method_scalarI_scalarO(theconnect, kITC16_DelayMicro,
                    args, 1, NULL, &size);
*/
#endif  
}

// Function ITC18_GetStructureSize
//
// Return the size of the device structure.

ITC_CALL int ITC18_GetStructureSize()
{
	return sizeof(struct ITC18);
}

#ifdef _WINDOWS

// Function ForcePort
//
// Force the port to be set.

static int ForcePort(struct ITC18* itc, int port)
{
	ULONG return_length;
	ULONG IoctlResult;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)	//USB does not need this
		{
		IoctlResult = DeviceIoControl(	itc->file,
										(DWORD) IOCTL_ITC_SET_PORT,
										&port,
										sizeof(port),
										NULL,
										0,
										&return_length,
										NULL);

		if (!IoctlResult)
			return ITC18_STATUS_SET_PORT;
		}

	itc->current_port = port;

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_SetPort
//
// Set relative port number

static int ITC18_SetPort(struct ITC18* itc, int port)
{
	ULONG return_length;
	ULONG status;

	if (port == itc->current_port)
		return ITC18_STATUS_SUCCESS;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)	//USB does not need this
		{
		status = DeviceIoControl(	itc->file,
									(DWORD) IOCTL_ITC_SET_PORT,
									&port,
									sizeof(port),
									NULL,
									0,
									&return_length,
									NULL);

		if(!status)
			return ITC18_STATUS_SET_PORT;
		}

	itc->current_port = port;

	return ITC18_STATUS_SUCCESS;
}

// Functions OutputWordString
//
// Each implementation writes an array of words to a specified
// I/O port.

static int OutputWordString_Win32s(struct ITC18* itc, int port, int count, short *data)
{
	__asm
		{
		push eax
		push ecx
		push edx
		push esi

		mov	 esi,data
		mov	 edx,port
		mov	 ecx,count
		cld
		rep	 outsw

		pop esi
		pop edx
		pop ecx
		pop eax
		}

	return ITC18_STATUS_SUCCESS;
}

static int OutputWordString_Windows95(struct ITC18* itc, int port, int count, short* data)
{
	int return_length;
	int result;

	result = ITC18_SetPort(itc, port);

	if (result != 0)
		return result;

    result = DeviceIoControl(	itc->file,
   								(DWORD) IOCTL_ITC_WRITE,
								(LPVOID) data,
								count*sizeof(*data),
    							NULL,
								0,
								&return_length,
    							NULL);
	if (!result)
		return ITC18_STATUS_WRITE_ERROR;

	return ITC18_STATUS_SUCCESS;
}

static int OutputWordString_WindowsNT(struct ITC18* itc, int port, int count, short* data)
{
	ULONG return_length;
	int result;
	int length;
	int temp, i;
	char* tempdata = (char*)data;
	BULK_TRANSFER_CONTROL USBControl;
//	unsigned char buffer[1];
	int transfersize = itc->max_transfer_size;
 
#ifdef __MIKE_TEST_TIME__18__
#ifdef _WINDOWS
__int64 TicksPerSecond;
if(!QueryPerformanceFrequency( (LARGE_INTEGER *)&TicksPerSecond))
TicksPerSecond = 0;

if(!QueryPerformanceCounter((LARGE_INTEGER*) &Start))
	Start = 0;
#else
Microseconds(&Start);
#endif
#endif

	result = ITC18_SetPort(itc, port);

	if (result != 0)
		return result;

	length = count * sizeof(short);

	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		//USB.
		//1. Use max transfer size (512 or 64) depends on the USB type
		
		USBControl.pipeNum = (port == USB18_ROM3_PORT) ? USB18_ROM3_PIPE : USB18_ROM4_PIPE;	//ROM3 or ROM4

		if(itc->USBVersion >= 0x00050000 && port == USB18_ROM3_PORT)
			{
			//Redirect writing to ROM3
			USBControl.pipeNum = USB18_ROM4_PIPE;

			itc->myRequest.request = (BYTE) _USB_WRITE_ROM3;		// Write ROM3 0xE9
			itc->myRequest.direction = 0;							//OUTPUT
			itc->myRequest.value = 0;

			result = DeviceIoControl(	itc->file,
										IOCTL_VENDOR_OR_CLASS_REQUEST ,
										&itc->myRequest,
										sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
										NULL,
										0,
										&return_length,
										NULL);
			if (!result)
				return ITC18_STATUS_WRITE_ERROR;
			}


//		itc->myRequest.request = (BYTE) _USB_GET_FIFO_STATUS;	//Check if USB FIFO available 0xD1
//		itc->myRequest.direction = 1;			//INPUT
					

		//somehow does not work on all computers is port == rom3
		if(itc->USBVersion >= 0x00050006 &&  port != USB18_ROM3_PORT)
//			transfersize = transfersize << 8;
			transfersize = length;	//Version 6.0 of USB

		temp = length / transfersize;
		for(i = 0; i < temp; i++)
			{
			//Check if FIFO is available. Should it be done on the driver level???
			//Probably yes!
/*			do
				{
				result = DeviceIoControl(	itc->file,
											IOCTL_VENDOR_OR_CLASS_REQUEST ,
											&itc->myRequest,
											sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
											buffer,
											bufferSize,
											&return_length,
											NULL);
				if (!result)
					return ITC18_STATUS_WRITE_ERROR;

				//Add timeout here
				}
			while((buffer[0] & USBControl.pipeNum) != 0);
*/
			//Actual write
			result = DeviceIoControl(	itc->file,
										IOCTL_BULK_WRITE,
										&USBControl,
										sizeof(BULK_TRANSFER_CONTROL),
										tempdata,
										transfersize,
										&return_length, 
										NULL);
			if(!result)
				return ITC18_STATUS_WRITE_ERROR;

			tempdata += transfersize;
			}
		
		temp = length % transfersize;
		if(temp != 0)
			{
			//Check if FIFO is available. Should it be done on the driver level???
			//Probably yes!
/*			do
				{
				result = DeviceIoControl(	itc->file,
											IOCTL_VENDOR_OR_CLASS_REQUEST ,
											&itc->myRequest,
											sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
											buffer,
											bufferSize,
											&return_length,
											NULL);
				if (!result)
					return ITC18_STATUS_WRITE_ERROR;

				//Add timeout here
				}
			while((buffer[0] & USBControl.pipeNum) != 0);
*/
			//Actual write
			result = DeviceIoControl(	itc->file,
										IOCTL_BULK_WRITE,
										&USBControl,
										sizeof(BULK_TRANSFER_CONTROL),
										tempdata,
										temp,
										&return_length, 
										NULL);
			if (!result)
				return ITC18_STATUS_WRITE_ERROR;
			}

		if(itc->USBVersion >= 0x00050000 && port == USB18_ROM3_PORT)
			{
			//Redirect writing back to ROM4
//			itc->myRequest.request = (BYTE) _USB_WRITE_ROM3;		// Write ROM3 0xE9
//			itc->myRequest.direction = 0;			//OUTPUT
			itc->myRequest.value = 1;

			result = DeviceIoControl(	itc->file,
										IOCTL_VENDOR_OR_CLASS_REQUEST ,
										&itc->myRequest,
										sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
										NULL,
										0,
										&return_length,
										NULL);
			if (!result)
				return ITC18_STATUS_WRITE_ERROR;
			}
		}
	else
		{
		result = WriteFile(itc->file, data, length, &return_length, NULL);
		if (!result)
			return ITC18_STATUS_WRITE_ERROR;
		}

#ifdef __MIKE_TEST_TIME__18__
#ifdef _WINDOWS
if(!QueryPerformanceCounter((LARGE_INTEGER*) &New))
	New = 0;
tTimeWrite18[tCounterWrite] = (DWORD)(New - Start);
#else
Microseconds(&New);
tTimeWrite18[tCounterWrite] = New.lo - Start.lo;
#endif
tCounterWrite++;
if(tCounterWrite > 15)
	tCounterWrite = 0;
#endif

	return ITC18_STATUS_SUCCESS;
}

// Functions InputWordString
//
// Each implementation reads an array of words from a specified
// I/O port.

static int InputWordString_Win32s(struct ITC18* itc, int port, int count, short* data)
{
	__asm
		{
		push ecx
		push edx
		push edi

		mov	edi,data
		mov	edx,port
		mov ecx,count
		cld
		rep insw

		pop edi
		pop edx
		pop ecx
		}

	return ITC18_STATUS_SUCCESS;
}

static int InputWordString_Windows95(struct ITC18* itc, int port, int count, short* data)
{
	int result;
	DWORD length;
	DWORD return_length;

	result = ITC18_SetPort(itc, port);

	if (result != 0)
		return result;

	length = count*sizeof(short);

	result = DeviceIoControl(	itc->file,
   								(DWORD) IOCTL_ITC_READ,
   								NULL,
   								0,
   								(LPVOID) data,
   								length,
   								&return_length,
   								NULL);
	if (!result)
		return ITC18_STATUS_READ_ERROR;

	if (return_length != length)
		return ITC18_STATUS_READ_ERROR;

	return ITC18_STATUS_SUCCESS;
}

static int InputWordString_WindowsNT(struct ITC18* itc, int port, int count, short *data)
{
	ULONG return_length = 0;
	int result;
	int length;
	LONG i;
	LONG temp;
	LONG temp_left;
	char* tempdata = (char*)data;
	char databuffer[512];
	BULK_TRANSFER_CONTROL USBControl;
	int transfersize = itc->max_transfer_size;

	result = ITC18_SetPort(itc, port);

	if (result != 0)
		return result;

	length = count * sizeof(short);

	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		//USB
		//Use max transfer size (512 or 64) depends on the USB type
		USBControl.pipeNum = USB18_ROM4_PIPE_READ;	//Read only from ROM4. Pipe 0.

		if(itc->USBVersion >= 0x00060000)
			{
			if(length <= 64)
				{
				//Read via EP0
				itc->myRequest.request = (BYTE) _USB_READ_FIFO_S;	//0xED;
				itc->myRequest.direction = 1;				//INPUT
				itc->myRequest.value = (WORD) length;		//Bytes
				itc->myRequest.index = 0;					//SwapBytes itc->ByteOrderFlag

				result = DeviceIoControl(	itc->file,
											IOCTL_VENDOR_OR_CLASS_REQUEST,
											&itc->myRequest,
											sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
											tempdata,
											length,
											&return_length, 
											NULL);
				if (!result)
					return ITC18_STATUS_READ_ERROR;
				}
			else
				{
				itc->myRequest.request = (BYTE) _USB_READ_ROM4_N_TIMES;	//0xD0;
				itc->myRequest.direction = 0;				//OUTPUT

				transfersize = 64*1024;	//transfersize << 7;	//512 bytes * 128 = 64K

				//Looks like we have limitation
				temp = length / transfersize;
				count = transfersize >> 1;

				itc->myRequest.value = (WORD) count << 16;
				itc->myRequest.index = count;
				
				for(i = 0; i < temp; i++)
					{
					result = DeviceIoControl(	itc->file,
												IOCTL_VENDOR_OR_CLASS_REQUEST,
												&itc->myRequest,
												sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
												NULL,
												0,
												&return_length,
												NULL);
					if (!result)
						return ITC18_STATUS_READ_ERROR;


					result = DeviceIoControl(	itc->file,
												IOCTL_BULK_READ,
												&USBControl,
												sizeof(BULK_TRANSFER_CONTROL),
												tempdata,
												transfersize,
												&return_length, 
												NULL);
					if (!result)
						return ITC18_STATUS_READ_ERROR;

					tempdata += transfersize;
					}

				temp = length % transfersize;

				if(temp != 0)
					{
					if(temp <= 64)
						{
						//Read via EP0
						itc->myRequest.request = (BYTE) _USB_READ_FIFO_S;	//0xED;
						itc->myRequest.direction = 1;			//INPUT
						itc->myRequest.value = (WORD) temp;	//| (itc->ByteOrderFlag << 16);		//Bytes + swap
						itc->myRequest.index = itc->latch0;

						result = DeviceIoControl(	itc->file,
												IOCTL_VENDOR_OR_CLASS_REQUEST,
												&itc->myRequest,
												sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
												tempdata,
												temp,
												&return_length, 
												NULL);
						if (!result)
							return ITC18_STATUS_READ_ERROR;
						}
					else
						{
						count = temp >> 1;
						itc->myRequest.value = (WORD) count << 16;
						itc->myRequest.index = count;
				
						result = DeviceIoControl(	itc->file,
													IOCTL_VENDOR_OR_CLASS_REQUEST,
													&itc->myRequest,
													sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
													NULL,
													0,
													&return_length,
													NULL);
						if (!result)
							return ITC18_STATUS_READ_ERROR;

						result = DeviceIoControl(	itc->file,
													IOCTL_BULK_READ,
													&USBControl,
													sizeof(BULK_TRANSFER_CONTROL),
													tempdata,
													temp,
													&return_length, 
													NULL);
						if (!result)
							return ITC18_STATUS_READ_ERROR;
						}
					}
				}
			
			return ITC18_STATUS_SUCCESS;
			}
		
		temp = length / transfersize;
		temp_left = length % transfersize;
		
		itc->myRequest.request = (BYTE) _USB_READ_ROM4_N_TIMES;	//0xD0;
		if(itc->USBVersion >= 0x00050002)
			itc->myRequest.value = (WORD) itc->max_transfer_size >> 1;
		else
			itc->myRequest.value = (WORD) itc->max_transfer_size;
		itc->myRequest.direction = 0;			//OUTPUT
//		itc->myRequest.index = itc->USBFIFOFlag;
//		itc->myRequest.index = 1;	//Set initial state
					
		for(i = 0; i < temp; i++)
			{
			//1. The USB read FIFO is empty. Send command to fill it from the ITC18
			//We should optimize the whole driver to preload the USB FIFO with data
			if(itc->USBVersion < 0x00050002)
				{
				result = DeviceIoControl(	itc->file,
											IOCTL_VENDOR_OR_CLASS_REQUEST ,
											&itc->myRequest,
											sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
											NULL,
											0,
											&return_length,
											NULL);
				if (!result)
					return ITC18_STATUS_READ_ERROR;
				}

			//2. Actual FIFO read
			//We could optimize here as well. Start this one before finishing prevous,
			//so the data flow to the host without waiting all 256 bytes
			result = DeviceIoControl(	itc->file,
										IOCTL_BULK_READ,
										&USBControl,
										sizeof(BULK_TRANSFER_CONTROL),
										tempdata,
										transfersize,
										&return_length, 
										NULL);
			if (!result)
				return ITC18_STATUS_READ_ERROR;

			tempdata += transfersize;
//			itc->myRequest.index = 0;
			}

		if(temp_left != 0)
			{
			if(itc->USBVersion >= 0x00050003 && temp_left <= 64)
				{
				//Read via EP0
				itc->myRequest.request = (BYTE) _USB_READ_FIFO_S;	//0xED;
				itc->myRequest.direction = 1;				//INPUT
				itc->myRequest.value = (WORD) temp_left;	//Bytes
				itc->myRequest.index = 0;					//Swap Bytes itc->ByteOrderFlag

				result = DeviceIoControl(	itc->file,
											IOCTL_VENDOR_OR_CLASS_REQUEST ,
											&itc->myRequest,
											sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
											tempdata,
											temp_left,
											&return_length,
											NULL);
				if (!result)
					return ITC18_STATUS_READ_ERROR;
				}
			else
				{
				if(itc->USBVersion >= 0x00050002)
					itc->myRequest.value = (WORD) temp_left >> 1;
				else
					itc->myRequest.value = (WORD) temp_left;

	//			itc->myRequest.index |= 2;				//Reset to the initial state

				result = DeviceIoControl(	itc->file,
											IOCTL_VENDOR_OR_CLASS_REQUEST ,
											&itc->myRequest,
											sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
											NULL,
											0,
											&return_length,
											NULL);
				if (!result)
					return ITC18_STATUS_READ_ERROR;

				if(itc->USBVersion >= 0x00050002)
					{
					result = DeviceIoControl(	itc->file,
												IOCTL_BULK_READ,
												&USBControl,
												sizeof(BULK_TRANSFER_CONTROL),
												databuffer,
												transfersize,	//temp_left,
												&return_length, 
												NULL);
					for( i = 0; i < temp_left; i++)
						*tempdata++ = databuffer[i];
					}
				else
					result = DeviceIoControl(	itc->file,
												IOCTL_BULK_READ,
												&USBControl,
												sizeof(BULK_TRANSFER_CONTROL),
												tempdata,
												temp_left,
												&return_length, 
												NULL);
				if (!result)
					return ITC18_STATUS_READ_ERROR;
				}
			}
		}
	else
		{
		result = ReadFile(itc->file, data, length, &return_length, NULL);
		if (!result)
			return ITC18_STATUS_READ_ERROR;
		}	

	return ITC18_STATUS_SUCCESS;
}

#endif	//_WINDOWS

#ifdef _MACINTOSH

	#ifdef __powerc

// Functions OutputWordString
//
// Each implementation writes an array of words to a specified
// I/O port.

static int OutputWordString_PCI(struct ITC18* itc, int port, int count, short *data)
{
	unsigned long* target = (unsigned long*) port;
	
	do
		{
		*target = *data;
		++data;
		}
	while (--count);

	(*itc->links.synchronize_io)();
	  			   	
	return ITC18_STATUS_SUCCESS;
}

	#else

static int OutputWordString_NUBUS(struct ITC18* itc, int port, int count, short *data)
{
#pragma unused(itc)

	unsigned long* target = (unsigned long*) port;

	do
		{
		*target = *data;
		++data;
		}
	while (--count);

/*Mike??? it is under NUBUS!!!
#ifdef __powerc
	// Flush the write queue of the processor to synchronize I/O.
	__eieio();
#endif
end */	  			   	
	return ITC18_STATUS_SUCCESS;
}

	#endif //else

	#ifdef __powerc

static int InputWordString_PCI(struct ITC18* itc, int port, int count, short *data)
{
#pragma unused(itc)

	unsigned long* source = (unsigned long*) port;
	
	do
		{
		*data = *source;
		++data;
		}
	while (--count);
	
	return ITC18_STATUS_SUCCESS;
}

	#else

static int InputWordString_NUBUS(struct ITC18* itc, int port, int count, short *data)
{
#pragma unused(itc)

	unsigned long* source = (unsigned long*) port;

	do
		{
		*data = *source;
		++data;
		}
	while (--count);
	  			   	
	return ITC18_STATUS_SUCCESS;
}

	#endif	//else
#endif	//_MACINTOSH

#ifdef __APPLE__

static int OutputWordString_OSX(struct ITC18* itc, int port, int count, short *data)
{
	volatile unsigned long* target = (unsigned long*) port;
	
	do
		{
		*target = *data;
		++data;
		}
	while (--count);

//Building for intel: no such command:
//	__asm__ ("eieio");
//	OSSynchronizeIO();
#if defined(__ppc__)
        __asm__ ("eieio");
#endif
	  			   	
	return ITC18_STATUS_SUCCESS;
}

static int InputWordString_OSX(struct ITC18* itc, int port, int count, short *data)
{
 	volatile unsigned long* source = (unsigned long*) port;
/* This one is too slow
        kern_return_t kernResult;
        kernResult = IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
                                                        kITC18IORead,	// an index to the function in the Kernel.
                                                        2,	// the number of scalar input values.
                                                        1,	// no output
                                                        port - itc->port_latch,
                                                        count,
                                                        data);
        if(kernResult != KERN_SUCCESS) 
                return ITC18_STATUS_READ_ERROR;                                                       
*/
	do
		{
		*data = *source;
		++data;
		}
	while (--count);
        
//Building for intel: no such command:
//	__asm__ ("eieio");
//	OSSynchronizeIO();
#if defined(__ppc__)
        __asm__ ("eieio");
#endif
	
	return ITC18_STATUS_SUCCESS;
}

void CALLBACK myCallback18(	void *refcon,
							IOReturn result,
							void *arg0)
{
    CFRunLoopStop(CFRunLoopGetCurrent());
}							

static int OutputWordString_OSX_USB(struct ITC18* itc, int port, int count, short *data)
{
	IOReturn result;
	int length;
	int temp, temp_left, i, j, k;
//Move it to ITC18_AllocateMemoryB		short tempdata[1024 * 64];	//we transfer 2048 at one shot - so make it 1024K words. Should we move it out?	
	short* tempdata;
	unsigned char pipeRef;
	int transfersize = itc->max_transfer_size;
        
	length = count * sizeof(short);

	tempdata = (short*)(itc->ITC18_AllocateMemoryB);


/* Move inside
	for(i = 0; i < count; i++)
		data[i] = HostToUSBWord(data[i]);
*/

	//USB.
	//1. Use max transfer size (512 or 64) depends on the USB type
		
//	pipeNum = (port == 0) ? 2 : 1;	//ROM3 or ROM4
  	pipeRef = (port == USB18_ROM3_PORT) ? USB18_ROM3_PIPE_MACOSX : USB18_ROM4_PIPE_MACOSX;	//ROM3 or ROM4
  
	if(itc->USBVersion >= 0x00050000 && port == USB18_ROM3_PORT)
		{
		//Redirect writing to ROM3
		pipeRef = USB18_ROM4_PIPE_MACOSX;

		itc->myUSBRequest.bRequest = (BYTE) _USB_WRITE_ROM3;		// Write ROM3 0xE9
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = 0;
		itc->myUSBRequest.wLength = 0;

#ifdef _USE_CONTROL_REQUEST_
		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, &itc->myUSBRequest);
#else
		result = (*itc->InterfaceInterface)->ControlRequest(	itc->InterfaceInterface,0,&itc->myUSBRequest);
#endif
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_WRITE_ERROR;
		}

	
	transfersize = transfersize << 8;


	temp = length / transfersize;
	temp_left = length % transfersize;
	k = 0;
	for(i = 0; i < temp; i++)
		{
		for(j = 0; j < (transfersize >> 1); j++, k++)
			tempdata[j] = HostToUSBWord(data[k]);
			

		result = (*itc->InterfaceInterface)->WritePipeTO(	itc->InterfaceInterface,
															pipeRef,
															tempdata,
															transfersize,
															1000,
															1000);

		if (result != kIOReturnSuccess)
			{
			(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																pipeRef);
			return ITC18_STATUS_WRITE_ERROR;
			}
			
//		tempdata += transfersize;
		}
            
	for(j = 0; j < (temp_left >> 1); j++, k++)
		tempdata[j] = HostToUSBWord(data[k]);

	if(temp_left != 0)
		{	
//Repeat:
		//Check if FIFO is available. Should it be done on the driver level???
		//Probably yes!
/*
		do
			{
			result = (*itc->DeviceInterface)->DeviceRequest(itc->DeviceInterface, 
															&itc->myUSBRequest);
			if (result != kIOReturnSuccess)
				return ITC18_STATUS_WRITE_ERROR;
			
			//Add timeout here
			}
		while((buffer[0] & pipeRef) != 0);
*/
		//Actual write
#ifndef _USE_INTERRUPT_TRANSFERS_18_		
		result = (*itc->InterfaceInterface)->WritePipeTO(	itc->InterfaceInterface,
															pipeRef,
															tempdata,
															temp_left,
															1000,
															1000);
#else
		result = (*itc->InterfaceInterface)->WritePipe(		itc->InterfaceInterface,
															pipeRef,
															tempdata,
															temp_left);
#endif
		if (result != kIOReturnSuccess)
			{
/*
printf("bRequest: 0x%X wValue: %d wLength: %d bmRequestType: %d\n",	itc->myUSBRequest.bRequest, 
													itc->myUSBRequest.wValue, 
													itc->myUSBRequest.wLength,
													itc->myUSBRequest.bmRequestType);
*/
			(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																pipeRef);
//			i++;
//			if(i < 2)
//				goto Repeat;
//			else	
			return ITC18_STATUS_WRITE_ERROR;               
			}
		}

	if(itc->USBVersion >= 0x00050000 && port == USB18_ROM3_PORT)
		{
		itc->myUSBRequest.wValue = 1;

#ifdef _USE_CONTROL_REQUEST_
		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, &itc->myUSBRequest);
#else
		result = (*itc->InterfaceInterface)->ControlRequest(	itc->InterfaceInterface,0,&itc->myUSBRequest);
#endif
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_WRITE_ERROR;
		}

return ITC18_STATUS_SUCCESS;
}

void CALLBACK myCallback18r(void *refcon,
							IOReturn result,
							void *arg0)
{
	CFRunLoopStop(CFRunLoopGetCurrent());
}							

static int InputWordString_OSX_USB(struct ITC18* itc, int port, int count, short *data)
{
	int result;
	ULONG length;
	LONG i, j, k;
	char* tempdata = (char*)data;
	short* shorttempdata = data;
	unsigned char pipeRef;
	
    
	char databuffer[512];

	length = count * sizeof(short);

	//USB
	//Use max transfer size (512 or 64) depends on the USB type
	pipeRef = USB18_ROM4_PIPE_READ_MACOSX;	//Read only from ROM4. Pipe 0.
	if(itc->USBVersion >= 0x00060000)
		{
		if(length <= 64)
			{
			//Read via EP0
			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
			itc->myUSBRequest.bRequest = (BYTE) _USB_READ_FIFO_S;	//0xED;
			itc->myUSBRequest.wValue = (WORD) length;		//Bytes
			itc->myUSBRequest.wIndex = itc->ByteOrderFlag;	//1 - ppc;	Swap Bytes
			itc->myUSBRequest.wLength = length;
			itc->myUSBRequest.pData = tempdata;

#ifdef _USE_CONTROL_REQUEST_
			result = (*itc->DeviceInterface)->DeviceRequestTO(itc->DeviceInterface, &itc->myUSBRequest);
#else
			result = (*itc->InterfaceInterface)->ControlRequestTO(	itc->InterfaceInterface, 
																	0,
																	&itc->myUSBRequest);
#endif
			if (result != kIOReturnSuccess)
				return ITC18_STATUS_READ_ERROR;		
					
//			for( j = 0; j < (temp_left >> 1); j++, k++)
//				data[k] = USBToHostWord(data[k]);
			}
		else
			{
			//Mike 5.10.2007. What if count > 64K
			transfersize = 64*1024;	//64K limitation
			
			temp = length / transfersize;	//Number of Bytes
//			count = transfersize >> 1;
			
			itc->myUSBRequest.bRequest = (BYTE) _USB_READ_ROM4_N_TIMES;	//0xD0;
			itc->myUSBRequest.wValue =  transfersize << 15;
			itc->myUSBRequest.wIndex =  transfersize >> 1;
			itc->myUSBRequest.wLength = 0;
			itc->myUSBRequest.pData = NULL;
			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
			
			k = 0;
			for(i = 0; i < temp; i++)
				{
#ifdef _USE_CONTROL_REQUEST_
				result = (*itc->DeviceInterface)->DeviceRequestTO(itc->DeviceInterface, &itc->myUSBRequest);
#else
				result = (*itc->InterfaceInterface)->ControlRequestTO(	itc->InterfaceInterface, 0,&itc->myUSBRequest);
#endif
				if (result != kIOReturnSuccess)
					return ITC18_STATUS_READ_ERROR;

				result = (*itc->InterfaceInterface)->ReadPipeTO(	itc->InterfaceInterface,
																	pipeRef,
																	tempdata,
																	&transfersize,
																	1000,
																	1000);
				if (result != kIOReturnSuccess)
					{
					(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																		pipeRef);
					return ITC18_STATUS_READ_ERROR;
					}
					
				//Extra protection
				if(transfersize != 64*1024)
					return ITC18_STATUS_READ_ERROR;

				for(j = 0; j < transfersize; j+=2, k++)
					data[k] = USBToHostWord(*shorttempdata++);
				
				tempdata += transfersize;
				}
				
			temp = length % transfersize; //Number of bytes (always even)

			if(temp != 0)
				{
				if(temp <= 64)
					{
					//Read via EP0
					itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
					itc->myUSBRequest.bRequest = (BYTE) _USB_READ_FIFO_S;	//0xED;
					itc->myUSBRequest.wValue = (WORD) temp | (itc->ByteOrderFlag << 16);	//| 0x0100;	//Bytes + Swap
					itc->myUSBRequest.wIndex = itc->latch0;
					itc->myUSBRequest.wLength = temp;
					itc->myUSBRequest.pData = tempdata;

#ifdef _USE_CONTROL_REQUEST_
					result = (*itc->DeviceInterface)->DeviceRequestTO(itc->DeviceInterface, &itc->myUSBRequest);
#else
					result = (*itc->InterfaceInterface)->ControlRequestTO(	itc->InterfaceInterface, 
																			0,
																			&itc->myUSBRequest);
#endif
					if (result != kIOReturnSuccess)
						return ITC18_STATUS_READ_ERROR;		
					
//					for( j = 0; j < (temp_left >> 1); j++, k++)
//						data[k] = USBToHostWord(data[k]);
					}			
				else
					{
//					count = temp >> 1;
					itc->myUSBRequest.wValue = temp << 15;
					itc->myUSBRequest.wIndex = temp >> 1;
				
#ifdef _USE_CONTROL_REQUEST_
					result = (*itc->DeviceInterface)->DeviceRequestTO(itc->DeviceInterface, &itc->myUSBRequest);
#else
					result = (*itc->InterfaceInterface)->ControlRequestTO(	itc->InterfaceInterface, 
																			0,
																			&itc->myUSBRequest);
#endif
					if (result != kIOReturnSuccess)
						return ITC18_STATUS_READ_ERROR;

					result = (*itc->InterfaceInterface)->ReadPipeTO(	itc->InterfaceInterface,
																		pipeRef,
																		tempdata,
																		&temp,
																		1000,
																		1000);
					if (result != kIOReturnSuccess)
						{
						(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																			pipeRef);
						return ITC18_STATUS_READ_ERROR;
						}
						
					for(j = 0; j < temp; j+=2, k++)
						data[k] = USBToHostWord(*shorttempdata++);					
					}
				}								
			}
			
		return ITC18_STATUS_SUCCESS;
		}
		
	transfersize = itc->max_transfer_size;
	temp = length / transfersize;
	temp_left = length % transfersize;
		
	itc->myUSBRequest.bRequest = (BYTE) _USB_READ_ROM4_N_TIMES;	//0xD0;
	if(itc->USBVersion >= 0x00050002)
		itc->myUSBRequest.wValue = (WORD) transfersize >> 1;
	else
		itc->myUSBRequest.wValue = (WORD) transfersize;
	itc->myUSBRequest.wLength = 0;
	itc->myUSBRequest.pData = NULL;
//	itc->myUSBRequest.wIndex = 1;	//Set initial state
	
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
			
//	k = 0;
	for(i = 0; i < temp; i++)
		{
		//1. The USB read FIFO is empty. Send command to fill it from the ITC18
		//We should optimize the whole driver to preload the USB FIFO with data
		if(itc->USBVersion < 0x00050002)
			{
			result = (*itc->InterfaceInterface)->ControlRequestTO(	itc->InterfaceInterface,0,&itc->myUSBRequest);
//				(IOAsyncCallback1)myCallback18,NULL);
//		CFRunLoopRun();
		
			if (result != kIOReturnSuccess)
				return ITC18_STATUS_READ_ERROR;
			}


		result = (*itc->InterfaceInterface)->ReadPipeTO(	itc->InterfaceInterface,
									pipeRef,
									tempdata,
									&transfersize,
									1000,
									1000);


		if (result != kIOReturnSuccess)
			{
			(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																pipeRef);
			return ITC18_STATUS_READ_ERROR;
			}
			
//		itc->myUSBRequest.wIndex = 0;
//		for( j = 0; j < (transfersize >> 1); j++, k++)
//			data[k] = USBToHostWord(data[k]);
#ifndef _USE_ASYNC_TRANSFERS_18_R		
		tempdata += transfersize;
#endif
		}				 
										                   
	if(temp_left != 0)
		{
		if(itc->USBVersion >= 0x00050003 && temp_left <= 64)
			{
			//Read via EP0
			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
			itc->myUSBRequest.bRequest = (BYTE) _USB_READ_FIFO_S;	//0xED;
			itc->myUSBRequest.wValue = (WORD) temp_left;	//Bytes
			itc->myUSBRequest.wIndex = itc->ByteOrderFlag;	//Swap Bytes 1 - ppc
			itc->myUSBRequest.wLength = temp_left;
			itc->myUSBRequest.pData = tempdata;

#ifdef _USE_CONTROL_REQUEST_
			result = (*itc->DeviceInterface)->DeviceRequestTO(itc->DeviceInterface, &itc->myUSBRequest);
#else
			result = (*itc->InterfaceInterface)->ControlRequestTO(	itc->InterfaceInterface, 
																	0,
																	&itc->myUSBRequest);
#endif
			if (result != kIOReturnSuccess)
				return ITC18_STATUS_READ_ERROR;		
					
//			for( j = 0; j < (temp_left >> 1); j++, k++)
//				data[k] = USBToHostWord(data[k]);
			}
		else
			{
			if(itc->USBVersion >= 0x00050002)
				itc->myUSBRequest.wValue = (WORD) temp_left >> 1;
			else
				itc->myUSBRequest.wValue = (WORD) temp_left;
				
//			if(itc->USBVersion >= 0x00050002)
//				itc->myUSBRequest.wIndex = 3;				//Reset to the initial state
Repeat:

			result = (*itc->InterfaceInterface)->ControlRequestTO(	itc->InterfaceInterface,
																	0,
																	&itc->myUSBRequest);
//															(IOAsyncCallback1)myCallback18,
//															NULL);
//			CFRunLoopRun();

			if (result != kIOReturnSuccess)
				{
				(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																	0);
//			i++;
//			if(i < 2)
//				goto Repeat;
//			else	
					return ITC18_STATUS_READ_ERROR;
				}
			
/*#ifndef _USE_INTERRUPT_TRANSFERS_18_	
		result = (*itc->InterfaceInterface)->ReadPipeAsyncTO(itc->InterfaceInterface,
														pipeRef,
														databuffer,
														512,	//temp_left,
														1000,
														1000,
														(IOAsyncCallback1)myCallback18r,	//callback
														NULL);							//pointer to the callback data
#else
*/
			if(itc->USBVersion >= 0x00050002)
				{
				temp = itc->max_transfer_size;			
				result = (*itc->InterfaceInterface)->ReadPipeTO(itc->InterfaceInterface,
																pipeRef,
																databuffer,	//tempdata,
																&temp,	//&temp_left);
																1000,
																1000);
				}
			else
				result = (*itc->InterfaceInterface)->ReadPipeTO(itc->InterfaceInterface,
																pipeRef,
																tempdata,
																&temp_left,
																1000,
																1000);
//#endif
//		CFRunLoopRun();

			if (result != kIOReturnSuccess)
				{
				(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																	pipeRef);
				i++;
				if(i < 2)
					goto Repeat;
				else	
					return ITC18_STATUS_READ_ERROR;
				}

			if(itc->USBVersion >= 0x00050002)
				for(i = 0; i < temp_left; i++)
//				for(i = 0; i < (temp_left >> 1); i++, k++)
					*tempdata++ = databuffer[i];
//					data[k] = USBToHostWord(databuffer[i]);
			}

//		for( j = 0; j < (temp_left >> 1); j++, k++)
//			data[k] = USBToHostWord(data[k]);
		}

//*Move Up
	for( i = 0; i < count; i++)
		data[i] = USBToHostWord(data[i]);
//*/
return ITC18_STATUS_SUCCESS;
}

#endif	//__APPLE__
// Function OutputWord

static int OutputWord(struct ITC18* itc, int port, int value)
{
//	short data = (short) value;
	int status;

	status = ITC18_SingleWriteROM34(itc, port, value);
//	status = itc->output_word_string(itc, port, 1, &data);

	return status;
}


// Function InputWord

static int InputWord(struct ITC18* itc, int port, int* value)
{
	short data;
	int result;

	result = itc->input_word_string(itc, port, 1, &data);
	if (result)
		return result;
		
	*value = ((int) data) & USHRT_MAX;

	return ITC18_STATUS_SUCCESS;
}

// Function WaitTXHEM
//
// Wait until TXHEM goes high. It this takes longer than the timeout
// period, signal a timeout.

// This function is a bottle neck for the USB. Need global optimization.
// First step. Move this function to 8051	
static int WaitTXHEM(struct ITC18* itc)
{
	int mask;
	int status;

#ifdef _WINDOWS

	int result;
	char buffer[1];
	int return_length;
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myRequest.request = (BYTE) _USB_WAIT_TXHEM;	//WaitTXHEM 0xD2
		itc->myRequest.direction = 1;			//INPUT

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
		}
	else
		{
		#define TIMEOUT_ONE_SEC 1000

		DWORD start_time;

		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_STATUS);

		if(status != 0)
			return status;

		start_time = GetTickCount();

		while (GetTickCount() - start_time < TIMEOUT_ONE_SEC)
			{
			status = InputWord(itc, itc->port_data, &mask);

			if (status != 0)
				return status;

			if (mask & STATUS_TXHEM)
				return ITC18_STATUS_SUCCESS;
			}
		
		return ITC18_STATUS_TXHEM_TIMEOUT;
		}
#endif

#ifdef __APPLE__
	long count;

	int result;
	char buffer[1];
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_WAIT_TXHEM;	//WaitTXHEM 0xD2
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = buffer;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
		}
	else
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_STATUS);

		if(status != 0)
			return status;

		count = 0;
		while(count < 10000)
			{
			status = InputWord(itc, itc->port_data, &mask);
			if(status != 0)
				return status;
			if(mask & STATUS_TXHEM)
				return ITC18_STATUS_SUCCESS;
            DelayMicroseconds(10);
            count++;
			}
		}

	return ITC18_STATUS_TXHEM_TIMEOUT;
#endif

#ifdef _MACINTOSH

#define TIMEOUT_ONE_SEC 60 // timer ticks are 1/60 sec on the Macintaosh

	unsigned long start_time;
	unsigned long now;

	status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_STATUS);

	if (status != 0)
		return status;

	Delay(0, (unsigned long*)&start_time);

	do
		{
		status = InputWord(itc, itc->port_data, &mask);

		if(status != 0)
			return status;

		if(mask & STATUS_TXHEM)
			return ITC18_STATUS_SUCCESS;

		Delay(0, (unsigned long*)&now);
		}
	while(now - start_time < TIMEOUT_ONE_SEC);

	return ITC18_STATUS_TXHEM_TIMEOUT;
#endif
}

// Function ReadROM
//
// Read a byte from the ROM
// The address must be in the range 0 to 2 * ITC18_ROM_SIZE.
// The control LCA is reset.

static int ReadROM(struct ITC18* itc, int address, int* data)
{
	int status;

#ifdef _WINDOWS
	char buffer[1];
	int return_length;

	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myRequest.request = (BYTE) _USB_READ_EEPROM;	//Read EPROM 0xDD
		itc->myRequest.direction = 1;			//INPUT
		itc->myRequest.value = (WORD)address;

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if (!status)
			return ITC18_STATUS_USB_ERROR;

		*data = (int)buffer[0] & 0x00FF;
		status = ITC18_STATUS_SUCCESS;
		}
	else
#endif
#ifdef __APPLE__
#ifdef __USE_USB_COMMANDS__
	char buffer[1];

	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_READ_EEPROM;	//Read EPROM 0xDD
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)address;
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = buffer;

		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;

		*data = (int)buffer[0] & 0x00FF;
		}
	else
#endif
#endif
		{		
		// Set the read LCA bit.
 		status = OutputWord(itc, itc->port_latch, LCA_CONTROL);
		if(status != 0)
			return status;

		// TG 7/27/01 added additional lca reset command
 		status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
		if(status != 0)
			return status;
	
		// Set the address to read.
		status = OutputWord(itc, itc->port_data, address);
		if(status != 0)
			return status;

		// Read the value.
		status = InputWord(itc, itc->port_data, data);
		if(status != 0)
			return status;
			
		*data &= 0x00ff;

		//Mike 7/26/2001 Add resetting LC_DATA bit
//		status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
		status = OutputWord(itc, itc->port_latch, LCA_CONTROL);
		}

	return status;
}

// Function SerializeToBits
//
// Write a serial bit stream to the isolated LCA.  'data' points to an
// array, which is serialized bit-by-bit (one char becomes CHAR_BIT values)
// and then sent to the port_data. data_bit is a mask indicating which bit
// in the output word represents the LCA program data bit.  timing is
// a value that is written to the LCA in between the data bytes.
//
// Note that this routine differs from BitExplode() in that timing values are
// interleaved with the data, and the output buffer is twice as large to
// accomodate them.

//Mike Does not work on Vista #define BLOCK_SIZE 256
#define BLOCK_SIZE 32
//define BLOCK_SIZE 512
#define _USE_ITC_SHORT_TRANSFERS_

static int SerializeToBits(struct ITC18* itc, 
						   int data_bit, 
						   int timing, 
						   int length, 
						   unsigned char* data)
{
	int remaining = length;
	int status;

#ifdef _USE_ITC_SHORT_TRANSFERS_

	short target[BLOCK_SIZE*2*CHAR_BIT];

	// Break the data array into multiple buffers.
	while(remaining > 0)
		{
		int entries;
		int entry;
																   		
		entries = remaining;

		if(entries > BLOCK_SIZE)
			entries = BLOCK_SIZE;

		remaining -= entries;

		entries *= 2*CHAR_BIT;

		// Fill the outgoing buffer
		entry = 0;

		while(entry < entries)
			{
			int bit;
			int source = *data++;

			for(bit = 0; bit < CHAR_BIT; ++bit)
				{
				int program_byte;

				program_byte = 0;

				if(source & 0x01)
					program_byte |= data_bit;

				target[entry] = (short) program_byte;
				++entry;
				target[entry] = (short) program_byte | timing;
				++entry;

				source >>= 1;
				}
			}

		status = itc->output_word_string(itc, itc->port_data, entries, target);
		if(status != 0)
			return status;
		}
#else

	//Allocate a big buffer
	short *databuf, *tempbuf;
	int i;
	short data0, data1;

	remaining *= 2 * CHAR_BIT;
	databuf = malloc(remaining * sizeof(short));
	if(databuf == NULL)
		return ITC18_STATUS_NO_MEMORY;

	tempbuf = databuf;
	for(i = 0; i < length; i++)
		{
		int bit;
		int source = *data++;

		for(bit = 0; bit < CHAR_BIT; ++bit)
			{
			int program_byte;

			program_byte = 0;

			if(source & 0x01)
				program_byte |= data_bit;
                                
			data0 = (short) program_byte;
			data1 = (short) program_byte | timing;

			*tempbuf++ = data0;
			*tempbuf++ = data1;

			source >>= 1;
			}
		}

	status = itc->output_word_string(itc, itc->port_data, remaining, databuf);
	if(status != 0)
		return status;

	free(databuf);

#endif

return ITC18_STATUS_SUCCESS;
}


// Function BitExplode
//
// Write a serial bit stream out to the interface LCA. 'data' points to an
// array, which is serialized into a string bit-by bit (one char becomes
// CHAR_BIT values), then sent to port. 'data_bit' indicates which bit in the
// output word represents the LCA program data bit. 'control_mask' selects the
// port and bits appropriate for programming the LCA.

static int BitExplode(struct ITC18* itc, 
					  int control_mask, 
					  int data_bit, 
					  int length, 
					  unsigned char* data)
{
	int remaining = length;
	int status;

#ifdef _USE_ITC_SHORT_TRANSFERS_

	short target[BLOCK_SIZE*CHAR_BIT];

		// Break the data array into multiple buffers.
		while (remaining > 0)
			{
			int entries;
			int entry;

			entries = remaining;

			if(entries > BLOCK_SIZE)
				entries = BLOCK_SIZE;

			remaining -= entries;

			entries *= CHAR_BIT;

			// Fill the outgoing buffer
			entry = 0;

			while(entry < entries)
				{
				int bit;
				int source = *data++;
				int program_byte;

				for(bit=0; bit < CHAR_BIT; ++bit)
					{
					program_byte = control_mask;

					if (source & 0x01)
						program_byte |= data_bit;

					target[entry] = (short) program_byte;

					++entry;

					source >>= 1;
					}
				}

	 		status = itc->output_word_string(itc, itc->port_latch, entries, target);
			if(status != 0)
				return status;
			}

#else
	
	//Allocate big buffer
	short *databuf, *tempbuf;
	int i;
	short data0;

	remaining *= CHAR_BIT;
	databuf = malloc(remaining * sizeof(short));
	if(databuf == NULL)
		return ITC18_STATUS_NO_MEMORY;

	tempbuf = databuf;
	for(i = 0; i < length; i++)
		{
		int bit;
		int source = *data++;
		int program_byte;

		for(bit=0; bit < CHAR_BIT; ++bit)
			{
			program_byte = control_mask;

			if (source & 0x01)
				program_byte |= data_bit;
                                
			data0 = (short) program_byte;

			*tempbuf++ = data0;
			source >>= 1;
			}
		}

	status = itc->output_word_string(itc, itc->port_latch, remaining, databuf);
	if(status != 0)
		return status;

	free(databuf);

#endif
	
return ITC18_STATUS_SUCCESS;
}

// Function LoadInterfaceLCA
//
  // Program the interface LCA.  If any errors are encountered opening the
// LCA file, checking it's size, or allocating a buffer to read it into,
// exit immediately and return an error code.  BitExplode() does the
// serialization and writing of the serial bit stream.

#define CCLKS_BEFORE_PROG 2
#define CCLKS_AFTER_PROG 4
#define CCLKS_DELAY_PERIOD 5000 // microseconds

static int LoadInterfaceLCA(struct ITC18* itc, unsigned char* data)
{
	int i;
	int status;

//Mike: USB. Add special command to do reset LCA

	// Reset the LCA
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL);
	if(status != 0)
		return status;

	// Toggle the PROG bit to prepare the Xilinx for programming.
	for(i = 0; i < CCLKS_BEFORE_PROG; ++i)
		{
		status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_CS);
		if(status != 0)
			return status;

		DelayMicroseconds(CCLKS_DELAY_PERIOD);
		
		status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_CS | LC_PROG);
		if(status != 0)
			return status;

		DelayMicroseconds(CCLKS_DELAY_PERIOD);
		}

	// Send the data to the LCA
	status = BitExplode(itc, LCA_CONTROL | LC_PROG, LC_DATA, INTERFACE_LCA_SIZE, data);
	if(status != 0)
		return status;
		
	// Pulse the clock with the data line high to finish programming the
	// interface Xilinx.

//Mike: USB. Add special command to finish programming.

	for(i = 0; i < CCLKS_AFTER_PROG; ++i)
		{
		status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA | LC_CS);
		if(status != 0)
			return status;

		DelayMicroseconds(CCLKS_DELAY_PERIOD);
		}

	// Reset the data line to zero
	
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_CS | LC_PROG);
	if (status != 0)
		return status;

	return ITC18_STATUS_SUCCESS;
}

// Function GetSignature
//
// Obtain the signature of the LCA just loaded.

static int GetSignature(struct ITC18* itc, int* signature)
{
	int status;
	int data;

#ifdef __USE_USB_COMMANDS__
	char buffer[2];
#ifdef _WINDOWS
	int return_length;
#endif
	if(itc->USBVersion >= 0x00050000)
		{
#ifdef _WINDOWS
		//Read this status periodically in 8051 and request latest state
		itc->myRequest.request = (BYTE) _USB_GET_SIGNATURE;	// Get ITC18 Signature 0xE5
		itc->myRequest.direction = 1;			//INPUT

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									2,
									&return_length,
									NULL);
		if (!status)
			return ITC18_STATUS_USB_ERROR;

		data = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
#endif
#ifdef __APPLE__
		//Read this status periodically in 8051 and request latest state
		itc->myUSBRequest.bRequest = (BYTE) (BYTE) _USB_GET_SIGNATURE;	// Get ITC18 Signature 0xE5
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = 2;
		itc->myUSBRequest.pData = buffer;

		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;

		data = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
#endif
		}
	else
#endif
		{
		// Read the signature from the status bits.
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_STATUS);
		if(status != 0)
			return status;

		status = InputWord(itc, itc->port_data, &data);
		if (status != 0)
			return status;
		}

	*signature = (data >> 4) & 0x007f;

	return ITC18_STATUS_SUCCESS;
}

// Function LoadIsolatedLCA
//
// Program the isolated LCA.  If any errors are encountered opening the
// LCA file, checking its size, or allocating a buffer to read it into,
// exit immediately and return an error code.  SerializeToBits() does the
// serialization and writing of the serial bit stream.
//
// Note that the isolated LCA requires timing bytes to be interleaved with
// the data bytes.  Also see SerializeToBits().

#define ISOLATED_CLOCK_LOW 0x02
#define ISOLATED_CLOCK_HIGH 0x06
#define ISOLATED_PROG_LOW 0x00
#define ISOLATED_PROG_HIGH 0x01
#define ISOLATED_DATA_BIT 0x0002

static int LoadIsolatedLCA(struct ITC18* itc, unsigned char* data)
{
	int i;
	int status;
	
//Mike: USB. Add special command to reset the LCA

	// Toggle the PROG bit twice to prepare the Xilinx for programming.
	for(i = 0; i < 2; ++i)
		{
		status = OutputWord(itc, itc->port_data, ISOLATED_PROG_HIGH);
		if(status != 0)
			return status;

		DelayMicroseconds(10000);

		status = OutputWord(itc, itc->port_data, ISOLATED_PROG_LOW);
		if(status != 0)
			return status;

		DelayMicroseconds(1000);
		}

	// Send the data to the LCA
	status = SerializeToBits(itc, ISOLATED_DATA_BIT, 0x0004, ISOLATED_LCA_SIZE, data);
	if(status != 0)
		return status;

//Mike: USB. Add special command to finish.

	// Finish the programming
  	status = OutputWord(itc, itc->port_data, ISOLATED_CLOCK_LOW);
	if(status != 0)
		return status;

	for(i = 0; i < CCLKS_AFTER_PROG; ++i)
		{
		status = OutputWord(itc, itc->port_data, ISOLATED_CLOCK_HIGH);
		if(status != 0)
			return status;

		status = OutputWord(itc, itc->port_data, ISOLATED_CLOCK_LOW);
		if(status != 0)
			return status;
		}
   
	return ITC18_STATUS_SUCCESS;
}

#ifdef _WINDOWS

// Function LocateBoard
//
// Find the board and set up the device structure to refer to it.

static int LocateBoard(struct ITC18* itc)
{
//Mike
	char openstring[80];

	OSVERSIONINFO OsVersionInfo;
	int i, port;

//For ezusb
	char key_data[MAX_PATH];
	int TryNumber = 0;

	OsVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	
	if(!GetVersionEx(&OsVersionInfo))
		return ITC18_STATUS_GET_VERSION;

	// If the file handle is invalid, the driver will not attempt
	// to close the handle on close.

	itc->file = INVALID_HANDLE_VALUE;

	// Open the kernel-mode driver in an operating-system dependent
	// manner. Notice that when Win32s support is dropped, it will be
	// possible to make this code almost entirely operating-system
	// independent, since the Windows 95 and Windows NT code is
	// almost identical.

	switch(OsVersionInfo.dwPlatformId)
		{
		case VER_PLATFORM_WIN32s:
//Mike: Check Device Number & DeviceType
			if(itc->DeviceType != PCI18_DEVICE_TYPE)
				return ITC18_STATUS_USB_NOT_SUPPORTED;

			if(itc->DeviceNumber != 0)
				return ITC18_STATUS_PCI_NOMULTIPLE;

			itc->input_word_string = InputWordString_Win32s;
			itc->output_word_string = OutputWordString_Win32s;

			// Get the port base from the [ITC18] section of Win.ini

			port = GetProfileInt("ITC18", "IoPortAddress", 0);

			if(port == 0)
				{
				// If the port address is not found in the Win.ini file,
				// use the factory default value.
				port = 0x3e0;
				}

			itc->port_latch = port + PORT_LATCH;
			itc->port_data = port + PORT_DATA;

			break;

		case VER_PLATFORM_WIN32_WINDOWS:
//Mike: Check DeviceType
			if(itc->DeviceType != PCI18_DEVICE_TYPE)
				return ITC18_STATUS_USB_NOT_SUPPORTED;

//Mike: Add multiple unit support
			local_strcpy(openstring, "\\\\.\\ITC18",80);
			if(itc->DeviceNumber != 0)
				{
				openstring[9] = 'D';
				openstring[10] = (char)(itc->DeviceNumber + 0x30);
				openstring[11] = '\0';
				}

			itc->input_word_string = InputWordString_Windows95;
			itc->output_word_string = OutputWordString_Windows95;

			// Dynamically load and prepare to call the VxD.

			itc->file = CreateFile(
//    			"\\\\.\\ITC18.VXD",
    			openstring,
    			GENERIC_READ|GENERIC_WRITE,
    			0,
    			0,
    			OPEN_EXISTING,
    			FILE_FLAG_DELETE_ON_CLOSE, 
    			0);			
			if (itc->file == INVALID_HANDLE_VALUE)
				{
				//Mike 11.29.2000
				//Error -> Try open ISA VxD
				itc->file = CreateFile(
						   			"\\\\.\\ITC18.VXD",
	    							GENERIC_READ|GENERIC_WRITE,
									0,
    								0,
    								OPEN_EXISTING,
	    							FILE_FLAG_DELETE_ON_CLOSE, 
									0);				
				if (itc->file == INVALID_HANDLE_VALUE)
					return ITC18_STATUS_DRIVER_OPEN;
				}

			itc->port_latch = PORT_LATCH;
			itc->port_data = PORT_DATA;

			// ForcePort has been removed so that the driver does not access the kernel
			// driver during Open in case it has been reserved.
/*
			status = ForcePort(itc, itc->port_latch);

			if (status != 0)
			{
				CloseHandle(itc->file);
				return status;
			}
*/
			break;
	
		case VER_PLATFORM_WIN32_NT:
//Mike: Add multiple unit support
			
			//Add USB Support
			if(itc->DeviceType == USB18_DEVICE_TYPE)
				{
				local_strcpy(openstring, "\\\\.\\ITC18U",80);
				i = 10;
				}
			else
				{
				local_strcpy(openstring, "\\\\.\\ITC18",80);
				i = 9;
				}
DEVELOPMENT_TRY:
			if(itc->DeviceNumber != 0 || itc->DeviceType == USB18_DEVICE_TYPE)
				{
				if(itc->DeviceType == PCI18_DEVICE_TYPE)
					openstring[i++] = 'D';

				openstring[i++] = (char)(itc->DeviceNumber + 0x30);
				openstring[i] = '\0';
				}
			
			itc->input_word_string = InputWordString_WindowsNT;
			itc->output_word_string = OutputWordString_WindowsNT;

			itc->file = CreateFile(	openstring,
									GENERIC_READ | GENERIC_WRITE,
									0,
									NULL,
									OPEN_EXISTING,
									FILE_FLAG_NO_BUFFERING | FILE_FLAG_SEQUENTIAL_SCAN,
									NULL);
//This is Cypress version:
//				itc->file = CreateFile(	openstring,
//										GENERIC_WRITE,
//										FILE_SHARE_WRITE,
//										NULL,
//										OPEN_EXISTING,
//										0,
//										NULL);

			if (itc->file == INVALID_HANDLE_VALUE)
				{
				//Mike: For Development Board:
				//If Secret key is exist ->  try EZUSB-0
				if(itc->DeviceType == USB18_DEVICE_TYPE && TryNumber == 0)
					{
					//Check out if we have "secret file" to force USB-18
					if(GetCurrentDirectory(MAX_PATH, key_data) != 0)
						{
						strcat(key_data,"\\");
						strcat(key_data,"TestUSB-18.on");
						if( _access(key_data, 4) == 0)
							{
							local_strcpy(openstring, "\\\\.\\EZUSB-",80);
							i = 10;
							TryNumber = 1;
							//Set flag 
							itc->developmentflag |= 1;
							goto DEVELOPMENT_TRY;
							}
						}
					}
				return ITC18_STATUS_DRIVER_OPEN;
				}

			itc->port_latch = PORT_LATCH;
			itc->port_data = PORT_DATA;

			// ForcePort has been removed so that the driver does not access the kernel
			// driver during Open in case it has been reserved.

/*
			status = ForcePort(itc, itc->port_latch);

			if (status != 0)
				{
				CloseHandle(itc->file);
				return status;
				}
*/
			break;
		}

	return ITC18_STATUS_SUCCESS;
}

#endif	//WINDOWS

#ifdef _MACINTOSH

	#ifdef __powerc

// Function DynamicLinkLoad
// Function DynamicLinkUnload
//
// Perform all required dynamic linking for PCI handling.

//Mike -> Actually should remove this garbage and just link statically 

static int DynamicLinkLoad(struct DynamicLinkStruct* links)
{
	OSErr result;
	Ptr library_address;
	CFragSymbolClass symbol_class;
	Str255 error_name;

	// Attempt to connect to the NameRegistry functions
	result = GetSharedLibrary(	(ConstStr63Param) "\pNameRegistryLib",
								kPowerPCCFragArch,
								kLoadCFrag,
								&links->name_registry,
								&library_address,
								error_name);
	if(result != noErr)
		return ITC18_STATUS_PCI_NOLINK;

	// Found the NameRegistry library. Now find the functions.
	// Find "RegistryEntryIDDispose"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryEntryIDDispose",
						(Ptr*) &links->registry_entry_ID_dispose,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Found the NameRegistry library. Now find the functions.
	// Find "RegistryEntryIDCopy"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryEntryIDCopy",
						(Ptr*) &links->registry_entry_ID_copy,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "RegistryEntryIDInit"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryEntryIDInit",
						(Ptr*) &links->registry_entry_ID_init,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "RegistryEntryIterateCreate"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryEntryIterateCreate",
						(Ptr*) &links->registry_entry_iterate_create,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "RegistryEntryIterateDispose"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryEntryIterateDispose",
						(Ptr*) &links->registry_entry_iterate_dispose,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "RegistryEntrySearch"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryEntrySearch",
						(Ptr*) &links->registry_entry_search,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "RegistryPropertyGet"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryPropertyGet",
						(Ptr*) &links->registry_property_get,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "RegistryPropertyGetSize"
	result = FindSymbol(links->name_registry,
						(ConstStr255Param) "\pRegistryPropertyGetSize",
						(Ptr*) &links->registry_property_get_size,
						&symbol_class);
	if (result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Attempt to connect to the DriverServices functions
	result = GetSharedLibrary(	(ConstStr63Param) "\pDriverServicesLib",
								kPowerPCCFragArch,
								kLoadCFrag,
								&links->driver_services,
								&library_address,
								error_name);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "SynchronizeIO"
	result = FindSymbol(links->driver_services,
						(ConstStr255Param) "\pSynchronizeIO",
						(Ptr*) &links->synchronize_io,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Found the DriverServices library. Now find the functions.
	// Find "PoolAllocateResident"
	result = FindSymbol(links->driver_services,
						(ConstStr255Param) "\pPoolAllocateResident",
						(Ptr*) &links->pool_allocate_resident,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "PoolDeallocate"
	result = FindSymbol(links->driver_services,
						(ConstStr255Param) "\pPoolDeallocate",
						(Ptr*) &links->pool_deallocate,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Attempt to connect to the PCI functions
	result = GetSharedLibrary(	(ConstStr63Param) "\pPCILib",
								kPowerPCCFragArch,
								kLoadCFrag,
								&links->pci,
								&library_address,
								error_name);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Found the PCI library. Now find the functions.
	// Find "ExpMgrConfigReadWord"
	result = FindSymbol(links->pci,
						(ConstStr255Param) "\pExpMgrConfigReadWord",
						(Ptr*) &links->exp_mgr_config_read_word,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		CloseConnection(&links->pci);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "ExpMgrConfigWriteWord"
	result = FindSymbol(links->pci,
						(ConstStr255Param) "\pExpMgrConfigWriteWord",
						(Ptr*) &links->exp_mgr_config_write_word,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		CloseConnection(&links->pci);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "ExpMgrConfigReadByte"
	result = FindSymbol(links->pci,
						(ConstStr255Param) "\pExpMgrConfigReadByte",
						(Ptr*) &links->exp_mgr_config_read_byte,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		CloseConnection(&links->pci);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "ExpMgrConfigWriteByte"
	result = FindSymbol(links->pci,
						(ConstStr255Param) "\pExpMgrConfigWriteByte",
						(Ptr*) &links->exp_mgr_config_write_byte,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		CloseConnection(&links->pci);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "ExpMgrConfigReadLong"
	result = FindSymbol(links->pci,
						(ConstStr255Param) "\pExpMgrConfigReadLong",
						(Ptr*) &links->exp_mgr_config_read_long,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		CloseConnection(&links->pci);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "ExpMgrConfigWriteLong"
	result = FindSymbol(links->pci,
						(ConstStr255Param) "\pExpMgrConfigWriteLong",
						(Ptr*) &links->exp_mgr_config_write_long,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		CloseConnection(&links->pci);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Find "EndianSwap32Bit"
	result = FindSymbol(links->pci,
						(ConstStr255Param) "\pEndianSwap32Bit",
						(Ptr*) &links->endian_swap_32_bit,
						&symbol_class);
	if(result != noErr)
		{
		CloseConnection(&links->name_registry);
		CloseConnection(&links->driver_services);
		CloseConnection(&links->pci);
		return ITC18_STATUS_PCI_NOLINK;
		}

	// Found everything successfully
	return ITC18_STATUS_SUCCESS;
}


static void DynamicLinkUnload(struct DynamicLinkStruct* links)
{
	CloseConnection(&links->name_registry);
	CloseConnection(&links->driver_services);
	CloseConnection(&links->pci);
}


// Determine the logical address of a given PCI bus board
static int PCIGetAddress(	RegEntryIDPtr pentry,
							PCIRegisterNumber device_register,
							LogicalAddress* device_logical_address,
							ByteCount* device_area_length,
							struct DynamicLinkStruct* links)
{
	OSErr result;
	RegPropertyValueSize address_size;
	RegPropertyValueSize logical_size;
	RegPropertyValue* address_property;
	RegPropertyValue* logical_property;
	LogicalAddress* logical_address;
	PCIAssignedAddressPtr pci_address;
	int count;
	int index;
	int status;

	// Find the property "kPCIAssignedAddressProperty"
	result = (*links->registry_property_get_size)(pentry, kPCIAssignedAddressProperty, &address_size);
	if(result != noErr)
		return ITC18_STATUS_PCI_NOMAP;

	address_property = (RegPropertyValue*)(*links->pool_allocate_resident)(address_size, 0);

	result = (*links->registry_property_get)( pentry, kPCIAssignedAddressProperty, address_property, &address_size);
	if(result != noErr)
		{
		(*links->pool_deallocate)(&address_property);
		return ITC18_STATUS_PCI_NOMAP;
		}

	// Find the property "kAAPLDeviceLogicalAddress"
	result = (*links->registry_property_get_size)(pentry, kAAPLDeviceLogicalAddress, &logical_size);
	if(result != noErr)
		{
		(*links->pool_deallocate)(&address_property);
		return ITC18_STATUS_PCI_NOMAP;
		}

	logical_property = (RegPropertyValue*)(*links->pool_allocate_resident)(logical_size, 0);

	result = (*links->registry_property_get)(pentry, kAAPLDeviceLogicalAddress, logical_property, &logical_size);
	if(result != noErr)
		{
		(*links->pool_deallocate)(&address_property);
		(*links->pool_deallocate)(&logical_property);
		return ITC18_STATUS_PCI_NOMAP;
		}

	// Search for the board within the PCI space
	logical_address = (LogicalAddress*) logical_property;

	pci_address = (PCIAssignedAddressPtr) address_property;

	count = address_size / sizeof(PCIAssignedAddress);

	if (count > logical_size/sizeof(logical_address[0]))
		count = logical_size/sizeof(logical_address[0]);

	status = ITC18_STATUS_PCI_NOMAP;

	for(index = 0; index < count; ++index)
		{
		// Note that GetPCIRegisterNumber is a macro, therefore it
		// is not accessed through a shared library.
		if(GetPCIRegisterNumber(pci_address) == device_register)
			{
			if(pci_address->size.hi != 0 || pci_address->size.lo == 0)
				{
				// Address assigned in 64-bit memory space. This
				// is inaccessable.
				status = ITC18_STATUS_PCI_NOMAP;
				break;
				}

			// Desired register found
			status = ITC18_STATUS_SUCCESS;

			*device_logical_address = logical_address[index];
			*device_area_length = pci_address->size.lo;
			break;
			}

		++pci_address;
		}

	(*links->pool_deallocate)(&address_property);
	(*links->pool_deallocate)(&logical_property);

	return status;
}

// Function LocateBoard_PCI
//
// Locate the interface board in the PCI space

static int LocateBoard_PCI(void* device)
{
	RegEntryID entry;
	RegEntryIter iterator;
	OSStatus result;
	OSErr error;
	Boolean done;
	UInt16 command;
	LogicalAddress base;
	ByteCount length;
	int CurrentPCI18 = 0;
	
	RegEntryIterationOp	iterOp;						// TG 6/27/2000
	
	#define kInstrutechDeviceType	"pci1482,2"		// TG 6/27/2000
	#define kInstrutechDeviceType3	"pci1482,3"		// TG 6/27/2000  used on only a few early PCI-18 boards
		
	struct ITC18* itc = (struct ITC18*) device;

	// Attempt to locate the board on the PCI bus
	(*itc->links.registry_entry_ID_init)(&entry);

	result = (*itc->links.registry_entry_iterate_create)(&iterator);
	if(result != noErr)
		{
		(*itc->links.registry_entry_ID_dispose)(&entry);	// TG 6/27/2000
		return ITC18_STATUS_PCI_NOACCESS;
		}

	// loop to check for multiple devices
	iterOp = kRegIterDescendants;		// TG 6/27/2000
	
	for(;;)
		{
		result = (*itc->links.registry_entry_search)(
				&iterator, iterOp, &entry, &done, "name", kInstrutechDeviceType, sizeof(kInstrutechDeviceType));
		// (*links.registry_entry_iterate_dispose)(&iterator);		TG 6/27/2000
		if(result != noErr || done)
			{	
			result = ITC18_STATUS_BOARD_NOT_FOUND;
			break;
			}

		// We have found an ITC-18 PCI-18 interface
		// Enable I/O space access to the PCI bus card
		if(CurrentPCI18 == itc->DeviceNumber)
			{//Done
			error = (*itc->links.exp_mgr_config_read_word)(&entry, (LogicalAddress) 4, &command);
			if(error != noErr)
				{
				result = ITC18_STATUS_BOARD_NOT_FOUND;
				break;
				}

			command |= 1; // enable I/O space access

			error = (*itc->links.exp_mgr_config_write_word)(&entry, (LogicalAddress) 4, command);
			if(error != noErr)
				{
				result = ITC18_STATUS_BOARD_NOT_FOUND;
				break;
				}

			// Map the I/O space into accessable address space
			result = PCIGetAddress(&entry, 0x10, &base, &length, &(itc->links));
			if (result != noErr)
				{
				result = ITC18_STATUS_BOARD_NOT_FOUND;
				break;
				}

			(*itc->links.registry_entry_ID_copy)(&entry,&(itc->links.entry));
			(*itc->links.registry_entry_ID_dispose)(&entry);

			itc->port_latch = ((int) base) + PORT_LATCH;
			itc->port_data = ((int) base) + PORT_DATA;
			break;
			}

		CurrentPCI18++;														// TG 6/27/2000

		iterOp = kRegIterContinue;		// TG 6/14/2000

		//Mike: DO WE NEED IT???
		(*itc->links.registry_entry_ID_dispose)(&entry);
		} 

	(*itc->links.registry_entry_ID_dispose)(&entry);
	(*itc->links.registry_entry_iterate_dispose)(&iterator);	// TG 6/14/2000
	// Done
	return result;
}

	#else //__powerc

struct SPRAMRecord
{
	short boardID;
	char VendorUse1;
	char VendorUse2;
	char VendorUse3;
	char VendorUse4;
	char VendorUse5;
	char VendorUse6;
};

#define NUBUS_SLOT_BASE 9
#define NUBUS_SLOT_LIMIT 15
#define NUBUS_BOARD_ID 1722

static int LocateBoard_NUBUS(struct ITC18* itc)
{
	SpBlock slot_information;
	struct SPRAMRecord slot_parameters;
	FHeaderRec slot_header;
	int slot;
	int base;

/*
// The following code attempts to determine if a NuBus is
// present on the machine. If not, it avoids checking for
// the interface board. This code does not appear to work
// for reasons we do not yet understand. We have temporarily
// disabled it, so the code will always search the NuBus,
// even if none is present. This does not appear to cause
// any problems.

	long bus;

	Gestalt(gestaltSlotAttr, &bus);

	if (bus != gestaltNuBusPresent)
		return ITC18_STATUS_BOARD_NOT_FOUND;
*/
	// Start at the first slot available on the Macintosh

	slot = NUBUS_SLOT_BASE;
	
	// Search all the slots

	while (slot < NUBUS_SLOT_LIMIT)
	{
		// Determine if the slot contains a board

		slot_information.spResult = (long) &slot_header;
		slot_information.spSlot = slot;

		if (!SReadFHeader(&slot_information))
		{
			// Determine if the board is a Mac-23

			slot_information.spResult = (long) &slot_parameters;

			if (!SReadPRAMRec(&slot_information))
			{
				if (slot_parameters.boardID == NUBUS_BOARD_ID)
					break;
			}
		}

		++slot;
	}

	// If all the slots were searched the board does not exist
	// on the NuBus

	if (slot >= NUBUS_SLOT_LIMIT)
		return ITC18_STATUS_BOARD_NOT_FOUND;

	// Determine the location of the board in the I/O space

	base = 0xF0000000 + slot * 0x01100000;

	itc->port_latch = base + 0;
	itc->port_data = base + 0x80000;

	itc->output_word_string = OutputWordString_NUBUS;
	itc->input_word_string = InputWordString_NUBUS;

	return ITC18_STATUS_SUCCESS;
}

	#endif //else - nubus

// Function LocateBoard
//
// Find the board and set up the device structure to refer to it.

static int LocateBoard(struct ITC18* itc)
{
	int status;

#ifdef __powerc
	// Look for the board on the PCI bus only on a PowerPC
	// Macintosh

	unsigned long* pci_control;

//	if (Num_of_PCI18 == -1)				// PCI search has not been done yet. TG 6/27/2000
		status = LocateBoard_PCI(itc);
//	else
//		{	
//		if(itc->DeviceNumber > Num_of_PCI18)
//			return ITC18_STATUS_BOARD_NOT_FOUND;
//		else 
//			status = ITC18_STATUS_SUCCESS;
//		}
					
	if(status == ITC18_STATUS_SUCCESS)
		{ 	
		itc->output_word_string = OutputWordString_PCI;		// TG 6/27/2000
		itc->input_word_string = InputWordString_PCI;		// TG 6/27/2000
			
		// Enable byte swapping
		pci_control = (unsigned long*) (((int) itc->port_latch) + PORT_PCI);
		*pci_control = PCI_SWAP;
		}
	
#else
	status = LocateBoard_NUBUS(itc);
#endif

	return status;
}

#endif	// _MACINTOSH

#ifdef __APPLE__

static int ReadITC18Config_OSX(struct ITC18* itc, UInt8 inOffset, int inSize, int* outNumber) 
{
    return IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
											kITC18ConfigRead,	// an index to the function in the Kernel.
											2,	// the number of scalar input values.
											1,	// no output
											inOffset,
											inSize,
											outNumber);
}

static int WriteITC18Config_OSX(struct ITC18* itc, UInt8 inOffset, int inSize, int inNumber)
{
    return IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
											kITC18ConfigWrite,	// an index to the function in the Kernel.
											3,	// the number of scalar input values.
											0,	// no output
											inOffset,
											inSize,
											inNumber);
}

int LocateBoard18(struct ITC18* itc)
{
	kern_return_t	kr;
	io_iterator_t 	iter;
	io_service_t 	theservice = 0;	//Initialize just to avoid warning
	mach_port_t	master_device_port;
//	io_object_t 	obj;
	int i;
	void* port;
	CFDictionaryRef	classToMatch;
	vm_size_t ofSize=0;
	int revision;
        
	//USB
	CFMutableDictionaryRef dict;
	IOCFPlugInInterface **plugInInterface = NULL;
	IOUSBFindInterfaceRequest InterfaceRequest;
	IOUSBConfigurationDescriptorPtr	confDesc;
	HRESULT result;
	LONG  score;
	USHORT  vendor;
	USHORT  product;
//	USHORT  release;
	CFNumberRef     numberRef;
	LONG    idVendor = 0x1482;
	LONG    idProduct = 0x0011;
        
	if(itc->ITC18dataPort != 0)
		return ITC18_STATUS_DRIVER_OPEN;
    	
	kr = IOMasterPort(MACH_PORT_NULL, &master_device_port);
	if(kr != KERN_SUCCESS || !master_device_port)
		return ITC18_STATUS_BOARD_NOT_FOUND;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)    //PCI
		{
		classToMatch = IOServiceMatching("ITC18PCI"); 
		if(!classToMatch)
			{
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_BOARD_NOT_FOUND;
			}
		}
	else
		{
		classToMatch = IOServiceMatching("ITC18USBDriver"); 
		if(!classToMatch)
			{
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
		}
        
	kr = IOServiceGetMatchingServices(  master_device_port,
										classToMatch,
										&iter);

	if(kr != KERN_SUCCESS)
		{
		mach_port_deallocate(mach_task_self(), master_device_port);
		return ITC18_STATUS_BOARD_NOT_FOUND;
		}

	if(!IOIteratorIsValid(iter))
		{
		mach_port_deallocate(mach_task_self(), master_device_port);
		return ITC18_STATUS_BOARD_NOT_FOUND;
		}
                
	IOIteratorReset(iter);
			
	for (i = 0; i < (itc->DeviceNumber + 1); i++)
		{
		theservice = IOIteratorNext(iter);
		if (!theservice)
			{
			IOObjectRelease(iter);
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_BOARD_NOT_FOUND;
			} 
		else
			if(i < itc->DeviceNumber)
				IOObjectRelease(theservice); // Not the one we want
		}

	kr = IOObjectRelease(iter);       
	kr = IOServiceOpen(theservice, mach_task_self(),0,&(itc->ITC18dataPort));
	// Release the io_service_t now that we're done with it.
	IOObjectRelease(theservice);
	if(kr != KERN_SUCCESS)
		{
		mach_port_deallocate(mach_task_self(), master_device_port);
		return ITC18_STATUS_BOARD_NOT_FOUND;
		}
/*                
	if(kr == kIOReturnUnsupported)
		{
		mach_port_deallocate(mach_task_self(), master_device_port);
		return ITC18_STATUS_BOARD_NOT_FOUND;
		}
*/          

	if(itc->DeviceType == PCI18_DEVICE_TYPE)    //PCI
		{
		kr = IOConnectMapMemory(itc->ITC18dataPort, 
								kITC18_Regs,
								mach_task_self(), 
								(vm_address_t *)&port, 
								&ofSize,
								kIOMapAnywhere+kIOMapInhibitCache);
		if(kr != KERN_SUCCESS)
			{
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_PCI_NOACCESS;
			}
		itc->port_latch = (int)(port + PORT_LATCH);
		itc->port_data  = (int)(port + PORT_DATA);

		itc->output_word_string = OutputWordString_OSX;
		itc->input_word_string = InputWordString_OSX;

		kr = ReadITC18Config_OSX(itc, 8, sizeof(UInt16), &revision);

		*(unsigned long*) (((int) itc->port_latch) + PORT_PCI) = PCI_SWAP;
		}
            
	mach_port_deallocate(mach_task_self(), master_device_port);
        
	//Now Let's do USB
	if(itc->DeviceType == USB18_DEVICE_TYPE)    //USB
		{
		kr = IOMasterPort(MACH_PORT_NULL, &master_device_port);
		if(kr != KERN_SUCCESS || !master_device_port)
			{
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
         
		dict = IOServiceMatching("IOUSBDevice");    //ITC18USBDriver");
		if(!dict)
			{
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}

		numberRef = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &idVendor);
		if (!numberRef)
				{
				kr = IOServiceClose(itc->ITC18dataPort);
				itc->ITC18dataPort = 0;
				mach_port_deallocate(mach_task_self(), master_device_port);
				return ITC18_STATUS_BOARD_NOT_FOUND;
				}
		CFDictionarySetValue(dict, CFSTR(kUSBVendorID), numberRef);
		CFRelease(numberRef);
		numberRef = 0;
		numberRef = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &idProduct);
		if (!numberRef)
				{
				kr = IOServiceClose(itc->ITC18dataPort);
				itc->ITC18dataPort = 0;
				mach_port_deallocate(mach_task_self(), master_device_port);
				return ITC18_STATUS_BOARD_NOT_FOUND;
				}
		CFDictionarySetValue(dict, CFSTR(kUSBProductID), numberRef);
		CFRelease(numberRef);
		numberRef = 0;
        
		kr = IOServiceGetMatchingServices(  master_device_port,
											dict,
											&iter);

		if(!IOIteratorIsValid(iter))
			{
 			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
                
		IOIteratorReset(iter);
			
		for (i = 0; i < (itc->DeviceNumber + 1); i++)
			{
			theservice = IOIteratorNext(iter);
			if (!theservice)
				{
				kr = IOServiceClose(itc->ITC18dataPort);
				itc->ITC18dataPort = 0;
				IOObjectRelease(iter);
				mach_port_deallocate(mach_task_self(), master_device_port);
					return ITC18_STATUS_USB_BOARD_NOT_FOUND;
				} 
			else
				if(i < itc->DeviceNumber)
					IOObjectRelease(theservice); // Not the one we want
			}

		kr = IOObjectRelease(iter);
            
		kr = IOCreatePlugInInterfaceForService( theservice,
												kIOUSBDeviceUserClientTypeID,
												kIOCFPlugInInterfaceID,
												&plugInInterface,
												&score);
		IOObjectRelease(theservice);
		if((kr != kIOReturnSuccess) || !plugInInterface)
			{
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
            
		result = (*plugInInterface)->QueryInterface(plugInInterface,
//													CFUUIDGetUUIDBytes(kIOUSBDeviceInterfaceID),
													CFUUIDGetUUIDBytes(kIOUSBDeviceInterfaceID197),
													(LPVOID)&itc->DeviceInterface);

//Mike 6.16.2006 Found in documentation to use IODestroyPlugInInterface instead of Release																								
//		(*plugInInterface)->Release(plugInInterface);
		(*plugInInterface)->Stop(plugInInterface);
		IODestroyPlugInInterface(plugInInterface);

		if(result || !itc->DeviceInterface)
			{
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
                
		//just for fun/debug: check the values
		kr = (*itc->DeviceInterface)->GetDeviceVendor(itc->DeviceInterface, &vendor);
		if(kr != kIOReturnSuccess || vendor != idVendor)
			{
			(void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;	
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
            
        kr = (*itc->DeviceInterface)->GetDeviceProduct(itc->DeviceInterface, &product);
        if(kr != kIOReturnSuccess || product != idProduct)
            {
            (void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
            itc->DeviceInterface = NULL;	
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
            return ITC18_STATUS_USB_BOARD_NOT_FOUND;
            }
            
//        kr = (*itc->DeviceInterface)->GetDeviceReleaseNumber(itc->DeviceInterface, &release);
        
        kr = (*itc->DeviceInterface)->USBDeviceOpen(itc->DeviceInterface);
        if(kr != kIOReturnSuccess)
            {
            (void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
            itc->DeviceInterface = NULL;	
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
            return ITC18_STATUS_USB_BOARD_NOT_FOUND;
            }

        //Create Interface

        //for fun /debug
        /*
        kr = (*itc->DeviceInterface)->GetNumberOfConfigurations(itc->DeviceInterface, &temp);
        */

		kr = (*itc->DeviceInterface)->GetConfigurationDescriptorPtr(itc->DeviceInterface, 0, &confDesc);
		kr = (*itc->DeviceInterface)->SetConfiguration(itc->DeviceInterface, confDesc->bConfigurationValue);
              
		InterfaceRequest.bInterfaceClass = kIOUSBFindInterfaceDontCare;
		InterfaceRequest.bInterfaceSubClass = kIOUSBFindInterfaceDontCare;
		InterfaceRequest.bInterfaceProtocol = kIOUSBFindInterfaceDontCare;
		InterfaceRequest.bAlternateSetting = kIOUSBFindInterfaceDontCare;

		kr = (*itc->DeviceInterface)->CreateInterfaceIterator(  itc->DeviceInterface,
																&InterfaceRequest,
																&iter);

        if(!IOIteratorIsValid(iter))
            {
			(*itc->DeviceInterface)->USBDeviceClose(itc->DeviceInterface);
			(void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;	
 			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
                
		IOIteratorReset(iter);
			
		//Get only first interface
		theservice = IOIteratorNext(iter);
		if (!theservice)
			{
			IOObjectRelease(iter);
			(*itc->DeviceInterface)->USBDeviceClose(itc->DeviceInterface);
			(void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;	
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
                 
		kr = IOObjectRelease(iter);

		kr = IOCreatePlugInInterfaceForService( theservice,
												kIOUSBInterfaceUserClientTypeID,
												kIOCFPlugInInterfaceID,
												&plugInInterface,
												&score);
		IOObjectRelease(theservice);
		if((kr != kIOReturnSuccess) || !plugInInterface)
			{
			(*itc->DeviceInterface)->USBDeviceClose(itc->DeviceInterface);
			(void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;	
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}
            
		result = (*plugInInterface)->QueryInterface(plugInInterface,
//													CFUUIDGetUUIDBytes(kIOUSBInterfaceInterfaceID),
													CFUUIDGetUUIDBytes(kIOUSBInterfaceInterfaceID197),
													(LPVOID)&itc->InterfaceInterface);
		
//Mike 6.16.2006 Found in documentation to use IODestroyPlugInInterface instead of Release																								
//		(*plugInInterface)->Release(plugInInterface);
		(*plugInInterface)->Stop(plugInInterface);
		IODestroyPlugInInterface(plugInInterface);
		
		if(result || !itc->InterfaceInterface)
			{
			(*itc->DeviceInterface)->USBDeviceClose(itc->DeviceInterface);
			(void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;	
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}

		kr = (*itc->InterfaceInterface)->USBInterfaceOpen(itc->InterfaceInterface);
		if(kr != kIOReturnSuccess)
			{
			(*itc->InterfaceInterface)->Release(itc->InterfaceInterface);
			itc->InterfaceInterface = NULL;	
			(*itc->DeviceInterface)->USBDeviceClose(itc->DeviceInterface);
			(void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_USB_BOARD_NOT_FOUND;
			}

		//Just for fun / debug
 /*			kr = (*itc->InterfaceInterface)->GetNumEndpoints(itc->InterfaceInterface, &temp);
            
            kr = (*itc->InterfaceInterface)->GetPipeProperties(  itc->InterfaceInterface,
                                                                1,
                                                                &direction,
                                                                &number,
                                                                &transfer,
                                                                &maximum,
                                                                &interval);
                       
            kr = (*itc->InterfaceInterface)->GetPipeProperties(  itc->InterfaceInterface,
                                                                2,
                                                                &direction,
                                                                &number,
                                                                &transfer,
                                                                &maximum,
                                                                &interval);
                       
            kr = (*itc->InterfaceInterface)->GetPipeProperties(  itc->InterfaceInterface,
                                                                3,
                                                                &direction,
                                                                &number,
                                                                &transfer,
                                                                &maximum,
                                                                &interval);
*/                       
		itc->output_word_string = OutputWordString_OSX_USB;
		itc->input_word_string = InputWordString_OSX_USB;

		itc->port_latch = PORT_LATCH;
		itc->port_data = PORT_DATA;

//For CALLBACK function 		
		kr = (*itc->InterfaceInterface)->CreateInterfaceAsyncEventSource(itc->InterfaceInterface, &itc->cfSource);
		if(kr != kIOReturnSuccess)
			{
			(*itc->InterfaceInterface)->Release(itc->InterfaceInterface);
			itc->InterfaceInterface = NULL;	
			(*itc->DeviceInterface)->USBDeviceClose(itc->DeviceInterface);
			(void) (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;
			kr = IOServiceClose(itc->ITC18dataPort);
			itc->ITC18dataPort = 0;
			mach_port_deallocate(mach_task_self(), master_device_port);
			return ITC18_STATUS_NO_MEMORY;
			}
		
		CFRunLoopAddSource(CFRunLoopGetCurrent(), itc->cfSource, kCFRunLoopDefaultMode);
		
		mach_port_deallocate(mach_task_self(), master_device_port);
		}
       
return ITC18_STATUS_SUCCESS;
}

#endif	//__APPLE

// Function GeFIFOSize
//
// Read the FIFO size from the ROM.

static int GetFIFOSize(struct ITC18* itc, int* size)
{
	int size_flag = 0;
	int status = 0;

	// Obtain the FIFO size from the configuration ROM

	status = ReadROM(itc, ROM_FIFO_SIZE, &size_flag);

	if (status != 0)
		{
		// Use the default value.
		*size = ITC18_256K_FIFO;
		return ITC18_STATUS_SUCCESS;
		}

	if ((size_flag & ROM_FIFO_SIZE_MASK) != 0)
		{
		// Device has a 1M FIFO
		*size = ITC18_1M_FIFO;
		}
	else
		{
		// Device has a 256K FIFO
		*size = ITC18_256K_FIFO;
		}

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_Initialize
//
// Initialize the device hardware
// Modified TG 6/28/2000

ITC_CALL int ITC18_Initialize(void* device, int LCA_configuration)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	int signature;
	int i;
	long speed, version;
	int range[ITC18_AD_CHANNELS];
	short data[4];	//For optimization

#ifdef _WINDOWS
	CHAR key_data_copy[MAX_PATH + 16] = "";
	ULONG key_type, key_size;
	HKEY key;
#endif
#ifdef macintosh
	SInt16	theVRef;
	SInt32	theDirID;
	FSSpec MacFileSpec;
	OSErr	theErr;
#endif
	char key_data[MAX_PATH + 16];
	local_u2f_header needlheader[1];
	char* u2fdatapointer;
	u2fdatapointer = NULL;

	// If USB Device -> Check if we need reload to the newest version
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
#ifdef _WINDOWS
		//1. Search in the current subdirectory
		strcpy(key_data,"ITC18.U2F");
		//Check U2F file
		status = _access(key_data, 4);
		if(status == 0)
			goto PROCESS_U2F;
		//2. Search in the system subdirectory
		status = GetSystemDirectory(key_data, MAX_PATH);
		if(status != 0)
			{
			strcat(key_data,"\\");
			strcat(key_data,"ITC18.U2F");
			status = _access(key_data, 4);
			if(status == 0)
				goto PROCESS_U2F;
			}
		//3. Search in the registry
		key_size = sizeof(key_data);
		key_type = REG_SZ;

		status = RegOpenKeyEx(	HKEY_LOCAL_MACHINE, 
								"SOFTWARE\\Instrutech\\ITC18 Driver", 
								0, 
								KEY_QUERY_VALUE, 
								&key);

		if(status == ERROR_SUCCESS)
			{
			status = RegQueryValueEx(key,
									"Itc18Config",
									NULL,
									&key_type,
									(UCHAR*)key_data,
									&key_size);
			RegCloseKey(key);
			if(status == ERROR_SUCCESS)
				{
				//Check if file is valid
				if(key_data[0] != 0)
					{
					status = _access(key_data, 4);
					if(status == 0)
						goto PROCESS_U2F;
					strcpy(key_data_copy, key_data);	//save key_data
					strcat(key_data,"ITC18.U2F");
					status = _access(key_data, 4);
					if(status != 0)
						{
						strcpy(key_data, key_data_copy);	//restore save key_data
						strcat(key_data,"\\");
						strcat(key_data,"ITC18.U2F");
						status = _access(key_data, 4);
						if(status == 0)
							goto PROCESS_U2F;
						}
					}
				}			
			}
#endif
#ifdef macintosh
		theErr = FindFolder(kOnSystemDisk, kExtensionFolderType,
							0, &theVRef, &theDirID);
		if(theErr == 0)
			{
			theErr = HGetFInfo (theVRef,
								theDirID,
								"\pITC18.U2Z",
								&fndrInfo);
			if(theErr == 0)
				{
				FSMakeFSSpec(theVRef, theDirID, "\pITC18.U2Z", &MacFileSpec);
				GetFSSFullPath(&MacFileSpec,key_data,':');
				goto PROCESS_U2F;
				}
			}
#endif
#ifdef __APPLE__
		strcpy(key_data,"/System/Library/Extensions/ITC_Driver.kext/Contents/Resources/itc18.u2z");
		status = open(key_data, O_RDONLY, 0);
		if(status > 0)
			{
			close(status);
			goto PROCESS_U2F;
			}
#endif
goto DONT_PROCESS_U2F;
PROCESS_U2F:

		needlheader[0].Function = U2F_ITC18_USB_STANDARD;
		needlheader[0].FunctionVersion = (DWORD)-1;
		needlheader[0].Location = U2F_ITC18_LOCATION_USB;
		needlheader[0].Type		= (DWORD)-1;
		needlheader[0].Speed	= (DWORD)-1;
		needlheader[0].Memory	= (DWORD)-1;
		needlheader[0].Algorithm = (DWORD)-1;
		needlheader[0].ByteSize = (DWORD)-1;

		//Get Size
		status = DecodeU2F(	key_data, 
							ITC18_PRODUCT,
							1,	//Number LCAs/DSPs to extract
							needlheader,
							NULL, //U2F gVersion
							NULL, //U2F lVersion
							NULL  //Pointers to Data
							);

		if(status != U2F_SUCCESS)
			goto DONT_PROCESS_U2F;

		//Check version
		if(needlheader[0].FunctionVersion == 0xFFFFFFFF)
			goto DONT_PROCESS_U2F;
		if(needlheader[0].FunctionVersion <= (unsigned long)itc->USBVersion)
			goto DONT_PROCESS_U2F;

		//Allocate memory
		u2fdatapointer = malloc(needlheader[0].ByteSize);
		if(u2fdatapointer == NULL)
			goto DONT_PROCESS_U2F;

		//Get Data
		status = DecodeU2F(	key_data, 
							ITC18_PRODUCT,
							1,	//Number LCAs/DSPs to extract
							needlheader,
							NULL, //U2F gVersion
							NULL, //U2F lVersion
							(void*)&u2fdatapointer  //Pointers to Data
							);

		//5.12.2006. Get Serial Number
		status = ITC18_GetUSBInfo(itc, NULL, NULL, NULL, &speed);
		if(status != ITC18_STATUS_SUCCESS)
			return status;

		//Replace the serial number
		u2fdatapointer[10] = (char)((speed & 0xF) + 0x30);
		u2fdatapointer[9] = (char)(((speed >> 4) & 0xF) + 0x30);
		u2fdatapointer[12] = (char)(((speed >> 8) & 0xF) + 0x30);
		u2fdatapointer[11] = (char)(((speed >> 12) & 0xF) + 0x30);
		u2fdatapointer[14] = (char)(((speed >> 16) & 0xF) + 0x30);
		u2fdatapointer[13] = (char)(((speed >> 20) & 0xF) + 0x30);
		u2fdatapointer[16] = (char)(((speed >> 24) & 0xF) + 0x30);
		u2fdatapointer[15] = (char)(((speed >> 28) & 0xF) + 0x30);

		status = ITC18_LoadUSB(	itc, 
								needlheader[0].ByteSize,
								u2fdatapointer);
 
		//Looks like USB-16 require a delay. Let's just sleep. How long?
		//Why put it for 18? Just in case
		DelayMicroseconds(10000);

		if(status)
			return ITC18_STATUS_USB_ERROR;

DONT_PROCESS_U2F: 
		if(u2fdatapointer != 0)
			free(u2fdatapointer);

//5.11.2006. Refresh version info
		status = ITC18_GetUSBInfo(itc, NULL, &speed, &version, NULL);
		if(status != ITC18_STATUS_SUCCESS)
			return status;

		if(speed <= 0)
			speed = 1;
		itc->max_transfer_size	= speed << 6;

		itc->USBVersion = version;
		}

	// initialize variables, added TG 3/24/98
	
//	itc->external_clock = 0;
//	itc->interval = 10;
//	itc->invert_digital_inputs = 0;
//	itc->latch_digital_inputs = 0;

	// initialize device information variables, added TG 7/27/01

	itc->fifo_size = 0;
	itc->data_read = 0;
	itc->data_written = 0;

	// Obtain the FIFO size.

	status = GetFIFOSize(itc, &itc->fifo_size);
	if (status != 0)
		return status;

	// Clear all the latches and reset the LCAs.

	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

/*Mike: USB. Optimize the data

	status = OutputWord(itc, itc->port_latch, ACQ_CONTROL);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, FIFO_CONTROL);
	if (status != 0)
		return status;

 	status = OutputWord(itc, itc->port_latch, DATA_SELECT);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, LCA_CONTROL);
	if (status != 0)
		return status;
*/

	data[0] = (short)ACQ_CONTROL;
	data[1] = (short)FIFO_CONTROL;
	data[2] = (short)DATA_SELECT;
	data[3] = (short)LCA_CONTROL;
	status = itc->output_word_string(itc, itc->port_latch, 4, data);
	if (status != 0)
		return status;

	// Program the LCAs and turn the ready light on if successful.
	// TG load the loader LCA 6/28/2000
	
	status = LoadInterfaceLCA(itc, nonisolated_LCA_loader);
	if (status != 0)
		return status;

	status = GetSignature(itc, &signature); 
	if (status != 0)
		return status;

	if (signature != LOADER_SIGNATURE)
		return ITC18_STATUS_SIGNATURE_LOADER;
	 
	// TG Load the appropriate isolated side LCA  TG 6/28/2000
	
	if (LCA_configuration == ITC18_PHASESHIFTER)
		status = LoadIsolatedLCA(itc, isolated_LCA_PhaseShifter);
	else
		{
		if (LCA_configuration == ITC18_DYNAMICCLAMP)
			status = LoadIsolatedLCA(itc, isolated_LCA_DynamicClamp);
		else
			status = LoadIsolatedLCA(itc, isolated_LCA_Standard);
		}

	if (status != 0)
		return status;

	status = GetSignature(itc, &signature);
	if (status != 0)
		return status;

	if (signature != ISOLATED_SIGNATURE)
		return ITC18_STATUS_SIGNATURE_ISOLATED;

	// TG 6/28/2000
	if (itc->fifo_size == ITC18_256K_FIFO)
		status = LoadInterfaceLCA(itc, nonisolated_LCA_256k_FIFO);
	else
		status = LoadInterfaceLCA(itc, nonisolated_LCA_1M_FIFO);

	if (status != 0)
		return status;

	status = GetSignature(itc, &signature);
	if (status != 0)
		return status;

	if (signature != INTERFACE_SIGNATURE)
		return ITC18_STATUS_SIGNATURE_INTERFACE;

	// Turn the ready light on
	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	//Initialize - GREEN is ON
	itc->green_light = 1;
	status = OutputWord(itc, itc->port_latch, ACQ_CONTROL | AC_READY_LIGHT_ON);
	if (status != 0)
		return status;

	// Initialize the gain of each AD channel.
	for (i = 0; i < ITC18_AD_CHANNELS; ++i)
		range[i] = ITC18_AD_RANGE_10V;

	status = ITC18_SetRange(itc, range);
	if (status != 0)
		return status;

	itc->initialized = 0;
	status = ITC18_StopAndInitialize(itc, 1, 1);
	if (status != 0)
		return status;

//	itc->initialized = 1;//status = ITC18_InitializeAcquisition(itc);
	itc->USBFIFOFlag = 0;
	itc->SequenceLength = 0;
	itc->external_clock = -1;
	itc->interval = 0;

	if(itc->USBVersion >= 0x00050000)
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_WRITE_FIFO_DATA);
		if (status != 0)
			return status;
		}

	//Let's set dummy sequence and run to clear EP1
	i = ITC18_OUTPUT_SKIP;
	status = ITC18_SmallRun(	itc,
								1, &i,	//int length, int* instructions,
								4, 0,	//int timer_ticks, int external_clock,
								2, data,//int OutputDataSize, short* OutputData,
								2, data,//int InputDataSize, short* InputData,
								0, 0);	//int external_trigger, int output_enable)
					
	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_InitializeCustom
//
// Initialize the device hardware
// If control_data or isolated_data are 0,
// the default LCA is used.

ITC_CALL int ITC18_InitializeCustom(void* device,
									void* control_data,
									void* isolated_data)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	int signature;
	int i;
	int range[ITC18_AD_CHANNELS];
	short data[4];	//For optimization

	// initialize variables  added TG 3/24/98
//	itc->external_clock = 0;
//	itc->interval = 10;
	itc->invert_digital_inputs = 0;
	itc->latch_digital_inputs = 0;

	// Obtain the FIFO size.
	status = GetFIFOSize(itc, &itc->fifo_size);
	if (status != 0)
		return status;

	// Clear all the latches and reset the LCAs.
	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

/*Mike: USB. Optimize the data

	status = OutputWord(itc, itc->port_latch, ACQ_CONTROL);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, FIFO_CONTROL);
	if (status != 0)
		return status;

 	status = OutputWord(itc, itc->port_latch, DATA_SELECT);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, LCA_CONTROL);
	if (status != 0)
		return status;
*/
	data[0] = (short)ACQ_CONTROL;
	data[1] = (short)FIFO_CONTROL;
	data[2] = (short)DATA_SELECT;
	data[3] = (short)LCA_CONTROL;
	status = itc->output_word_string(itc, itc->port_latch, 4, data);
	if (status != 0)
		return status;

	// Program the LCAs and turn the ready light on if successful.
	// TG load the loader LCA
	status = LoadInterfaceLCA(itc, nonisolated_LCA_loader);
	if (status != 0)
		return status;

	status = GetSignature(itc, &signature);
	if (status != 0)
		return status;

	if (signature != LOADER_SIGNATURE)
		return ITC18_STATUS_SIGNATURE_LOADER;
	 
	if (isolated_data)
		status = LoadIsolatedLCA(itc, (unsigned char *) isolated_data);
	else
		status = LoadIsolatedLCA(itc, isolated_LCA_Standard);

	if (status != 0)
		return status;

	status = GetSignature(itc, &signature);
	if (status != 0)
		return status;

	if (signature != ISOLATED_SIGNATURE)
		return ITC18_STATUS_SIGNATURE_ISOLATED;

	if (control_data)
		status = LoadInterfaceLCA(itc, (unsigned char *) control_data);
	else
		{
		if (itc->fifo_size == ITC18_256K_FIFO)
			status = LoadInterfaceLCA(itc, nonisolated_LCA_256k_FIFO);
		else
			status = LoadInterfaceLCA(itc, nonisolated_LCA_1M_FIFO);
		}

	if (status != 0)
		return status;

	status = GetSignature(itc, &signature);
	if (status != 0)
		return status;

	if (signature != INTERFACE_SIGNATURE)
		return ITC18_STATUS_SIGNATURE_INTERFACE;

	// Turn the ready light on
	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	//Initialize - GREEN is ON
	itc->green_light = 1;
	status = OutputWord(itc, itc->port_latch, ACQ_CONTROL | AC_READY_LIGHT_ON);
	if (status != 0)
		return status;

	// Initialize the gain of each AD channel.
	for (i=0; i < ITC18_AD_CHANNELS; ++i)
		range[i] = ITC18_AD_RANGE_10V;

	status = ITC18_SetRange(itc, range);
	if (status != 0)
		return status;

	itc->initialized = 0;
	status = ITC18_StopAndInitialize(itc, 1, 1);
	if (status != 0)
		return status;

//	itc->initialized = 1;//status = ITC18_InitializeAcquisition(itc);
	itc->USBFIFOFlag = 0;
	itc->SequenceLength = 0;
	itc->external_clock = -1;
	itc->interval = 0;
				
	if(itc->USBVersion >= 0x00050000)
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_WRITE_FIFO_DATA);
		if (status != 0)
			return status;
		}

	//Let's set dummy sequence and run to clear EP1
	i = ITC18_OUTPUT_SKIP;
	status = ITC18_SmallRun(	itc,
								1, &i,	//int length, int* instructions,
								4, 0,	//int timer_ticks, int external_clock,
								2, data,//int OutputDataSize, short* OutputData,
								2, data,//int InputDataSize, short* InputData,
								0, 0);	//int external_trigger, int output_enable)
					
	return ITC18_STATUS_SUCCESS;
}


//Mike: New Function -> Get Version
//Function ITC18_GetVersion

ITC_CALL int ITC18_GetVersion(void* device, void* UserVersion, void* KernelVersion)
{
	version_struct* LocalVersion;
	struct ITC18* itc = (struct ITC18*) device;

#ifdef _WINDOWS
	unsigned long VersionCommand;
	OSVERSIONINFO OsVersionInfo;
	int result;
	int return_length;
#endif

	if(UserVersion != NULL)
		{
		LocalVersion = UserVersion;
		LocalVersion->major_version = MAJOR_VERSION; 
		LocalVersion->minor_version = MINOR_VERSION; 
		local_strcpy(LocalVersion->description, DESCRIPTION, 80);
		local_strcpy(LocalVersion->date, DATE, 80);
		}

	if(KernelVersion != NULL)
		{	
		LocalVersion = KernelVersion;
		LocalVersion->major_version = 0; 
		LocalVersion->minor_version = 0; 
		local_strcpy(LocalVersion->description, DESCRIPTION, 80);
		local_strcpy(LocalVersion->date, DATE, 80);

#ifdef _WINDOWS
	
		OsVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	
		if (!GetVersionEx(&OsVersionInfo))
			return ITC18_STATUS_GET_VERSION;

		if(itc->file == INVALID_HANDLE_VALUE)
			return ITC18_STATUS_DRIVER_OPEN;

		switch (OsVersionInfo.dwPlatformId)
			{
			case VER_PLATFORM_WIN32s:
				return ITC18_STATUS_PCI_NOMULTIPLE;

			case VER_PLATFORM_WIN32_WINDOWS:

			case VER_PLATFORM_WIN32_NT:

				//Mike: USB. Make the same code later
				if(itc->DeviceType == PCI18_DEVICE_TYPE)
					VersionCommand = (unsigned long) IOCTL_ITC_GETVERSION;
				else
					VersionCommand = (unsigned long) IOCTL_GET_DRIVER_VERSION;

				result = DeviceIoControl(
										itc->file,
										VersionCommand,
										NULL,
										0,
										LocalVersion,
										sizeof(version_struct),
										&return_length,
										NULL
										);
			
				if(!result)
					return ITC18_STATUS_GET_VERSION;

				break;

			default:
				return ITC18_STATUS_GET_VERSION;
			}
#endif	//Windows
#ifdef __APPLE__
		IOByteCount	structSize = sizeof(version_struct); 
		kern_return_t 	kernResult;
		if(itc->DeviceType == PCI18_DEVICE_TYPE)
			kernResult = IOConnectMethodScalarIStructureO(  itc->ITC18dataPort,
															kITC18GetVersion,	// an index to the function in the Kernel.
															0,			// the number of scalar input values.
															&structSize,		// the size of the struct output paramter.
															KernelVersion		// a pointer to a struct output parameter.
															);
		else
			kernResult = IOConnectMethodScalarIStructureO(  itc->ITC18dataPort,
															kUSB18GetVersion,	// an index to the function in the Kernel.
															0,			// the number of scalar input values.
															&structSize,		// the size of the struct output paramter.
															KernelVersion		// a pointer to a struct output parameter.
															);
                
		if (kernResult != KERN_SUCCESS)
			return ITC18_STATUS_GET_VERSION;
#endif	//APPLE
#ifdef _MACINTOSH
#define SUPPORTED_KERNEL_VERSION			5
		LocalVersion = (version_struct*)KernelVersion;
		LocalVersion->major_version = SUPPORTED_KERNEL_VERSION;  // Superkludge
		LocalVersion->minor_version = 0; 
		local_strcpy(LocalVersion->description, DESCRIPTION, 80);
		local_strcpy(LocalVersion->date, DATE, 80);
#endif
		}

return ITC18_STATUS_SUCCESS;
}

typedef struct 
{
    unsigned short	VendorID;
    unsigned short  DeviceID;
    unsigned short  Command; 
    unsigned short  Status;
    unsigned char   RevisionID;
    unsigned char   ProgIf;    
    unsigned char   SubClass;  
    unsigned char   BaseClass; 
    unsigned char   CacheLineSize;
    unsigned char   LatencyTimer; 
    unsigned char   HeaderType;   
    unsigned char   BIST;          
    unsigned long   BaseAddresses[6];
	unsigned long	CardBusCISPtr;
    unsigned short	SubsystemVendorID;
	unsigned short	SubsystemID;
	unsigned long	ROMBaseAddress;
    unsigned long   Reserved2[2];
    unsigned char   InterruptLine; 
    unsigned char   InterruptPin;  
    unsigned char   MinimumGrant;  
    unsigned char   MaximumLatency;
}PCI_CONFIG_HEADER_0;

//****************************************************************
//					READ PCI CONFIGURATION
//****************************************************************
ITC_CALL int ITC18_ReadPCIConfig(	void* device,
									void* pciconfig)
{
struct ITC18* itc = (struct ITC18*) device;
#ifdef _WINDOWS
	
	int nOutput;		// Counter written to bufOutput
	Usb_Device_Descriptor pvBuffer;
	PCI_CONFIG_HEADER_0* lpciconfig = pciconfig;

	if(itc->file == INVALID_HANDLE_VALUE)
		return ITC18_STATUS_DRIVER_OPEN;

	//Mike: USB. Does not have PCI config. mimic with USB Device Descriptor
	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		{
		if (!DeviceIoControl(	itc->file,
								(unsigned long) IOCTL_ITC_READPCICONFIG,
								NULL,
								0,
								pciconfig,
								sizeof(PCI_CONFIG_HEADER_0),
								&nOutput,
								NULL)
		   )
			return ITC18_STATUS_NOT_IMPLEMENTED;

		if(nOutput != sizeof(PCI_CONFIG_HEADER_0))
			return ITC18_STATUS_NOT_IMPLEMENTED;
		}
	else
		{
		if (!DeviceIoControl(	itc->file,
								IOCTL_GET_DEVICE_DESCRIPTOR,
								&pvBuffer,
								sizeof (Usb_Device_Descriptor),
								&pvBuffer,
								sizeof (Usb_Device_Descriptor),
								&nOutput,
								NULL)
		   )
			return ITC18_STATUS_NOT_IMPLEMENTED;
				
		if(nOutput != sizeof(Usb_Device_Descriptor))
			return ITC18_STATUS_NOT_IMPLEMENTED;

		ZeroMemory(lpciconfig, sizeof(PCI_CONFIG_HEADER_0));
		lpciconfig->VendorID = pvBuffer.idVendor;
		lpciconfig->DeviceID = pvBuffer.idProduct;

		//Let's get speed, version, 
		ITC18_GetUSBInfo(	itc, 
							&lpciconfig->BaseAddresses[0], //long* REVCTL, 
							&lpciconfig->BaseAddresses[1], //long* Speed, 
							&lpciconfig->BaseAddresses[2], //long* Version, 
							&lpciconfig->BaseAddresses[3]); //long* SerialNumber);
		}	

#endif

#ifdef __APPLE__
	kern_return_t	kr;
	PCI_CONFIG_HEADER_0* lpciconfig = pciconfig;

        if(itc->DeviceType == PCI18_DEVICE_TYPE)
            {
            kr = ReadITC18Config_OSX(itc, 0, sizeof(UInt16), (int*)&lpciconfig->VendorID);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 2, sizeof(UInt16), (int*)&lpciconfig->DeviceID);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 4, sizeof(UInt16), (int*)&lpciconfig->Command);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 6, sizeof(UInt16), (int*)&lpciconfig->Status);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 8, sizeof(UInt8), (int*)&lpciconfig->RevisionID);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 9, sizeof(UInt8), (int*)&lpciconfig->ProgIf);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 10, sizeof(UInt8), (int*)&lpciconfig->SubClass);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 11, sizeof(UInt8), (int*)&lpciconfig->BaseClass);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 12, sizeof(UInt8), (int*)&lpciconfig->CacheLineSize);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 13, sizeof(UInt8), (int*)&lpciconfig->LatencyTimer);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 14, sizeof(UInt8), (int*)&lpciconfig->HeaderType);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 15, sizeof(UInt8), (int*)&lpciconfig->BIST);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 16, sizeof(UInt32), (int*)&lpciconfig->BaseAddresses[0]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 20, sizeof(UInt32), (int*)&lpciconfig->BaseAddresses[1]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 24, sizeof(UInt32), (int*)&lpciconfig->BaseAddresses[2]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 28, sizeof(UInt32), (int*)&lpciconfig->BaseAddresses[3]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 32, sizeof(UInt32), (int*)&lpciconfig->BaseAddresses[4]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 36, sizeof(UInt32), (int*)&lpciconfig->BaseAddresses[5]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 40, sizeof(UInt32), (int*)&lpciconfig->CardBusCISPtr);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 44, sizeof(UInt16), (int*)&lpciconfig->SubsystemVendorID);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 46, sizeof(UInt16), (int*)&lpciconfig->SubsystemID);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 48, sizeof(UInt32), (int*)&lpciconfig->ROMBaseAddress);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 52, sizeof(UInt32), (int*)&lpciconfig->Reserved2[0]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 56, sizeof(UInt32), (int*)&lpciconfig->Reserved2[1]);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 60, sizeof(UInt8), (int*)&lpciconfig->InterruptLine);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 61, sizeof(UInt8), (int*)&lpciconfig->InterruptPin);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 62, sizeof(UInt8), (int*)&lpciconfig->MinimumGrant);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            kr = ReadITC18Config_OSX(itc, 63, sizeof(UInt8), (int*)&lpciconfig->MaximumLatency);
            if (kr != KERN_SUCCESS) 
		return ITC18_STATUS_PCI_NOACCESS;
            }
		//Mike USB Add code for APPLE here
#endif

#ifdef __powerc
PCI_CONFIG_HEADER_0* lpciconfig = pciconfig;
#define ReadPCIConfig(f,r) (*itc->links.f)(&(itc->links.entry),(LogicalAddress)ConfigOffset(r),&(lpciconfig->r))

	int i;	

    ReadPCIConfig(exp_mgr_config_read_word,VendorID);
    ReadPCIConfig(exp_mgr_config_read_word,DeviceID);
    ReadPCIConfig(exp_mgr_config_read_word,Command); 
    ReadPCIConfig(exp_mgr_config_read_word,Status);
    ReadPCIConfig(exp_mgr_config_read_byte,RevisionID);
    ReadPCIConfig(exp_mgr_config_read_byte,ProgIf);    
    ReadPCIConfig(exp_mgr_config_read_byte,SubClass);  
    ReadPCIConfig(exp_mgr_config_read_byte,BaseClass); 
    ReadPCIConfig(exp_mgr_config_read_byte,CacheLineSize);
    ReadPCIConfig(exp_mgr_config_read_byte,LatencyTimer); 
    ReadPCIConfig(exp_mgr_config_read_byte,HeaderType);   
    ReadPCIConfig(exp_mgr_config_read_byte,BIST);          
	for (i = 0; i < 6; i++)
	    ReadPCIConfig(exp_mgr_config_read_long,BaseAddresses[i]);
	ReadPCIConfig(exp_mgr_config_read_long,CardBusCISPtr);
    ReadPCIConfig(exp_mgr_config_read_word,SubsystemVendorID);
	ReadPCIConfig(exp_mgr_config_read_word,SubsystemID);
	ReadPCIConfig(exp_mgr_config_read_long,ROMBaseAddress);
	for (i = 0; i < 2; i++)
	    ReadPCIConfig(exp_mgr_config_read_long,Reserved2[i]);
    ReadPCIConfig(exp_mgr_config_read_byte,InterruptLine); 
    ReadPCIConfig(exp_mgr_config_read_byte,InterruptPin);  
    ReadPCIConfig(exp_mgr_config_read_byte,MinimumGrant);  
    ReadPCIConfig(exp_mgr_config_read_byte,MaximumLatency);

#endif

	return ITC18_STATUS_SUCCESS;
}

//****************************************************************
//					WRITE PCI CONFIGURATION
//****************************************************************
ITC_CALL int ITC18_WritePCIConfig(	void* device,
									void* pciconfig)
{
struct ITC18* itc = (struct ITC18*) device;
#ifdef _WINDOWS
	int nOutput;		// Counter written to bufOutput

	if(itc->file == INVALID_HANDLE_VALUE)
		return ITC18_STATUS_DRIVER_OPEN;

	//Mike: USB. Does not have PCI config. mimic with USB later
	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		{
		if (!DeviceIoControl(itc->file,
							 (unsigned long) IOCTL_ITC_WRITEPCICONFIG,
							 pciconfig,
							 sizeof(PCI_CONFIG_HEADER_0),
							 NULL,
							 0,
							 &nOutput,
							 NULL)
		   )
			return ITC18_STATUS_NOT_IMPLEMENTED;

		if(nOutput != 0 )
			return ITC18_STATUS_NOT_IMPLEMENTED;
		}
#endif

#ifdef __APPLE__
	kern_return_t	kr;
	PCI_CONFIG_HEADER_0* lpciconfig = pciconfig;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		{
        kr = WriteITC18Config_OSX(itc, 0, sizeof(UInt16), lpciconfig->VendorID);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 2, sizeof(UInt16), lpciconfig->DeviceID);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 4, sizeof(UInt16), lpciconfig->Command);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 6, sizeof(UInt16), lpciconfig->Status);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 8, sizeof(UInt8), lpciconfig->RevisionID);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 9, sizeof(UInt8), lpciconfig->ProgIf);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 10, sizeof(UInt8), lpciconfig->SubClass);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 11, sizeof(UInt8), lpciconfig->BaseClass);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 12, sizeof(UInt8), lpciconfig->CacheLineSize);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 13, sizeof(UInt8), lpciconfig->LatencyTimer);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 14, sizeof(UInt8), lpciconfig->HeaderType);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 15, sizeof(UInt8), lpciconfig->BIST);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 16, sizeof(UInt32), lpciconfig->BaseAddresses[0]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 20, sizeof(UInt32), lpciconfig->BaseAddresses[1]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 24, sizeof(UInt32), lpciconfig->BaseAddresses[2]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 28, sizeof(UInt32), lpciconfig->BaseAddresses[3]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 32, sizeof(UInt32), lpciconfig->BaseAddresses[4]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 36, sizeof(UInt32), lpciconfig->BaseAddresses[5]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 40, sizeof(UInt32), lpciconfig->CardBusCISPtr);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 44, sizeof(UInt16), lpciconfig->SubsystemVendorID);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 46, sizeof(UInt16), lpciconfig->SubsystemID);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 48, sizeof(UInt32), lpciconfig->ROMBaseAddress);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 52, sizeof(UInt32), lpciconfig->Reserved2[0]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 56, sizeof(UInt32), lpciconfig->Reserved2[1]);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 60, sizeof(UInt8), lpciconfig->InterruptLine);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 61, sizeof(UInt8), lpciconfig->InterruptPin);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 62, sizeof(UInt8), lpciconfig->MinimumGrant);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
        kr = WriteITC18Config_OSX(itc, 63, sizeof(UInt8), lpciconfig->MaximumLatency);
        if (kr != KERN_SUCCESS) 
			return ITC18_STATUS_PCI_NOACCESS;
		}
	//Mike USB Add code for APPLE here
#endif

#ifdef __powerc
PCI_CONFIG_HEADER_0* lpciconfig = pciconfig;
#define WritePCIConfig(f,r) (*itc->links.f)(&(itc->links.entry),(LogicalAddress)ConfigOffset(r),(lpciconfig->r))

	int i;	

    WritePCIConfig(exp_mgr_config_write_word,VendorID);
    WritePCIConfig(exp_mgr_config_write_word,DeviceID);
    WritePCIConfig(exp_mgr_config_write_word,Command); 
    WritePCIConfig(exp_mgr_config_write_word,Status);
    WritePCIConfig(exp_mgr_config_write_byte,RevisionID);
    WritePCIConfig(exp_mgr_config_write_byte,ProgIf);    
    WritePCIConfig(exp_mgr_config_write_byte,SubClass);  
    WritePCIConfig(exp_mgr_config_write_byte,BaseClass); 
    WritePCIConfig(exp_mgr_config_write_byte,CacheLineSize);
    WritePCIConfig(exp_mgr_config_write_byte,LatencyTimer); 
    WritePCIConfig(exp_mgr_config_write_byte,HeaderType);   
    WritePCIConfig(exp_mgr_config_write_byte,BIST);          
	for(i = 0; i < 6; i++)
	    WritePCIConfig(exp_mgr_config_write_long,BaseAddresses[i]);
	WritePCIConfig(exp_mgr_config_write_long,CardBusCISPtr);
    WritePCIConfig(exp_mgr_config_write_word,SubsystemVendorID);
	WritePCIConfig(exp_mgr_config_write_word,SubsystemID);
	WritePCIConfig(exp_mgr_config_write_long,ROMBaseAddress);
	for (i = 0; i < 2; i++)
	    WritePCIConfig(exp_mgr_config_write_long,Reserved2[i]);
    WritePCIConfig(exp_mgr_config_write_byte,InterruptLine); 
    WritePCIConfig(exp_mgr_config_write_byte,InterruptPin);  
    WritePCIConfig(exp_mgr_config_write_byte,MinimumGrant);  
    WritePCIConfig(exp_mgr_config_write_byte,MaximumLatency);

#endif

	return ITC18_STATUS_SUCCESS;
}

//	Mike 8.1.05 -> Get Driver Handle

ITC_CALL unsigned long ITC18_GetDriverHandle(void* device, void** hDevice)
{
struct ITC18* itc = (struct ITC18 *) device;
unsigned long Error;

	__try
		{
		#ifdef _WINDOWS
		*hDevice = itc->file;
		#endif
		#ifdef __APPLE__
		*hDevice = (void*)itc->ITC18dataPort;
		#endif
		#ifdef macintosh
		*hDevice = (void*)itc->reserve_file;
		#endif
		Error = ITC18_STATUS_SUCCESS;
		}
	__except(1)
		{
		Error = ITC18_STATUS_NO_MEMORY;
		}

return Error;
	
}

// Function ITC18_Open

ITC_CALL int ITC18_Open(void* device, int device_number)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	long speed, version;
	char key_data[MAX_PATH + 16];
#ifdef _WINDOWS
	CHAR key_data_copy[MAX_PATH + 16] = "";
	ULONG key_type, key_size;
	HKEY key;
#endif
#ifdef macintosh
	SInt16	theVRef;
	SInt32	theDirID;
	FInfo	fndrInfo;
	OSErr	theErr;
#endif
#ifdef __APPLE__
	char dummydata[512];
#endif

#ifndef __powerc
	ZeroMemory(itc, sizeof(struct ITC18));
#else
	int i;
	char* myitc;
	myitc = (char*)itc;
	for(i = 0; i < sizeof(struct ITC18); i++)
		{
		*myitc++ = 0;
		}
#endif

	//USB has DeviceType == 1, so input device_number == 0x000100x
	itc->DeviceType = (device_number >> 16) & 0x7FFF;
	itc->DeviceNumber = device_number & 0xFFFF;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		{
#ifdef _WINDOWS
		//Check out if we have "secret file" to force USB-18
		if(GetCurrentDirectory(MAX_PATH, key_data) == 0)
			goto try1;
		strcat(key_data,"\\");
		strcat(key_data,"ForceUSB-18.on");
		if( _access(key_data, 4) != 0)
			{
try1:
			//Check out if we have "secret entry in the registry"
			key_size = sizeof(key_data);
			key_type = REG_SZ;
			status = RegOpenKeyEx(	HKEY_LOCAL_MACHINE, 
									"SOFTWARE\\Instrutech\\ITC18 Driver", 
									0, 
									KEY_QUERY_VALUE, 
									&key);
			if(status != ERROR_SUCCESS)
				goto NDOR;

			status = RegQueryValueEx(key,
									"ForceUSB-18",
									NULL,
									&key_type,
									(UCHAR*)key_data,
									&key_size);
			RegCloseKey(key);
			if(status != ERROR_SUCCESS)
				goto NDOR;
			if(stricmp(key_data, "yes") != 0)
				goto NDOR;
			}
#endif
#ifdef macintosh
		theErr = FindFolder(kOnSystemDisk, kExtensionFolderType,
//		theErr = FindFolder(kOnAppropriateDisk, kDesktopFolderType,
						0, &theVRef, &theDirID);
		if(theErr != 0)
			goto NDOR;
			
		theErr = HGetFInfo (theVRef,
							theDirID,
							"\pForceUSB-18.on",
							&fndrInfo);
		if(theErr != 0)
			goto NDOR;
#endif
#ifdef __APPLE__
		strcpy(key_data,"/System/Library/Extensions/ITC_Driver.kext/Contents/Resources/ForceUSB-18.on");
		//Check if file exist
		status = open(key_data, O_RDONLY, 0);
		if(status <= 0)
			goto NDOR;
		close(status);
#endif
		}
	//Here -> setup USB-18 instead of ITC-18
	itc->DeviceType = USB18_DEVICE_TYPE;
NDOR:

#ifdef __APPLE__
	
	status = LocateBoard18(itc);
        
#else

	#ifdef __powerc
		if(itc->DeviceType != PCI18_DEVICE_TYPE)
			return ITC18_STATUS_USB_NOT_SUPPORTED;

		// Set up the dynamic linking
		status = DynamicLinkLoad(&itc->links);
		if(status != ITC18_STATUS_SUCCESS)
			return status;
	#endif

	status = LocateBoard(itc);

#endif

	if(status != ITC18_STATUS_SUCCESS)
		return status;

	//We have to find out if it is USB high speed or not
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
#ifdef _WINDOWS
		//Place holder for 8051 communication
		itc->myRequest.request		= (BYTE) _USB_REINITIALIZE;	//0xB7;
		itc->myRequest.value		= (WORD) 0;
		itc->myRequest.index		= (WORD) 0x00;
		itc->myRequest.direction	= 1;			//INPUT
		itc->myRequest.requestType	= 2;
		itc->myRequest.recepient	= 0;
		itc->myRequest.requestTypeReservedBits = 0;
#endif
#ifdef __APPLE__
		//Let's allocate temporaly memory for swapping output data
		itc->ITC18_AllocateMemoryB = malloc(_USB_OUTPUT_TRANSFER_SIZE_18_);
		if(itc->ITC18_AllocateMemoryB == NULL)
			return ITC18_STATUS_NO_MEMORY;

		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.bRequest       = (BYTE) _USB_REINITIALIZE;	//0xB7;
		itc->myUSBRequest.wValue         = (WORD) 0;
		itc->myUSBRequest.wIndex         = (WORD) 0x00;
		itc->myUSBRequest.wLength        = 1;
		itc->myUSBRequest.pData          = &speed;
		itc->myUSBRequest.wLenDone       = 0;
		itc->myUSBRequest.noDataTimeout		= 1000;
		itc->myUSBRequest.completionTimeout	= 1000;
/*
		//Reload USB-18: Command 0xB7
		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;

(*itc->InterfaceInterface)->ClearPipeStallBothEnds(itc->InterfaceInterface,
													1);
*/
		itc->ByteOrderFlag = 0;	//Intel

#endif

		status = ITC18_GetUSBInfo(itc, NULL, &speed, &version, NULL);
		if(status != ITC18_STATUS_SUCCESS)
			return status;

		if(speed <= 0)
			speed = 1;
		itc->max_transfer_size	= speed << 6;

		itc->USBVersion = version;
//		if((version >> 16) < SUPPORTED_USB18_VERSION)
//			return ITC18_STATUS_USB_OLD_VERSION;

#ifdef __APPLE__

/*
typedef enum __CFByteOrder {
    CFByteOrderUnknown,
    CFByteOrderLittleEndian,
    CFByteOrderBigEndian
} CFByteOrder;
*/
	itc->ByteOrderFlag = (CFByteOrderGetCurrent() == CFByteOrderBigEndian) ? 1 : 0;	//1 - PPC, 0 - Intel

	//In some applications first call to read FIFO timeouts. Why?
	//Try to force this condition here, to avoid it in the running test.
	
	//Do it for version 5 and later
	if(itc->USBVersion >= 0x00050000)
			{
			itc->myUSBRequest.bRequest = (BYTE) _USB_READ_ROM4_N_TIMES;	//0xD0;
			itc->myUSBRequest.wLength = 0;
			itc->myUSBRequest.pData = NULL;      
			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
			if(itc->USBVersion < 0x00060000)
				{
				version = itc->max_transfer_size;
				itc->myUSBRequest.wValue = 1;
				itc->myUSBRequest.wIndex = itc->USBFIFOFlag;
				}
			else
				{
				version = 2;
				itc->myUSBRequest.wValue = 0;
				itc->myUSBRequest.wIndex = 1;
				}
			status = (*itc->DeviceInterface)->DeviceRequestTO(itc->DeviceInterface, &itc->myUSBRequest);
			status = (*itc->InterfaceInterface)->ReadPipeTO(itc->InterfaceInterface,
															USB18_ROM4_PIPE_READ_MACOSX,
															dummydata,
															&version,
															10,
															10);

			if(status != kIOReturnSuccess)
				(*itc->InterfaceInterface)->ClearPipeStallBothEnds(itc->InterfaceInterface,
																	1);
			}
#endif
		}

#ifndef _WINDOWS
	itc->reserve_file = 0;
#endif

   	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_Close
//
// This closes IO resources used by an ITC18.

ITC_CALL int ITC18_Close(void* device)
{
	struct ITC18* itc = (struct ITC18*) device;
	int reference_count = 1;
	short data[4];	//for USB optimization
	int status;

	// Check for a reserved device and get the driver's reference count which is
	// returned in the return_length.
	// Do not reset the board on the Macintosh because another application may be
	// using it.

#ifdef _WINDOWS
	unsigned long command;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		command = (unsigned long) IOCTL_ITC_RESERVE;
	else
		command = (unsigned long) IOCTL_USB_RESERVE;

	status = DeviceIoControl(	itc->file,
								command,
								NULL,
								0,
								NULL,
								0,
								&reference_count,
								NULL);

	// If the device is not reserved and the reference count is one,
	// it is safe to turn off the Ready Light and clear the registers.
	if (status && (reference_count == 1) &&	((itc->developmentflag & 0x1) == 0))
		{
		if(itc->green_light != 0)
			{
			// Turn off the Ready Light
			status = WaitTXHEM(itc);

			//Kill Green
			itc->green_light = 0;
			status = OutputWord(itc, itc->port_latch, ACQ_CONTROL | AC_READY_LIGHT_OFF);

			// Clear all the bits in the registers.
			status = WaitTXHEM(itc);
			}

		/*Mike: USB. Optimize
		status = OutputWord(itc, itc->port_latch, ACQ_CONTROL);
		status = OutputWord(itc, itc->port_latch, FIFO_CONTROL);
 		status = OutputWord(itc, itc->port_latch, DATA_SELECT);
		status = OutputWord(itc, itc->port_latch, LCA_CONTROL);
		*/
		data[0] = (short)ACQ_CONTROL;
		data[1] = (short)FIFO_CONTROL;
		data[2] = (short)DATA_SELECT;
		data[3] = (short)LCA_CONTROL;

		status = itc->output_word_string(itc, itc->port_latch, 4, data);
	}
#endif

#ifdef _WINDOWS
	if (itc->file != INVALID_HANDLE_VALUE)
		CloseHandle(itc->file);
#endif

#ifdef __powerc
	//Add pci dispose stuff
	if(itc->port_latch != 0)
		{
		(*itc->links.registry_entry_ID_dispose)(&itc->links.entry);
		itc->port_latch = 0;
		}
	DynamicLinkUnload(&itc->links);
#endif

#ifdef __APPLE__
	kern_return_t	kr;

//Check for the device was initialized
if(itc->output_word_string != NULL)
{
ITC18_StopAndInitialize(itc, 1, 1);	
data[0] = (short)ACQ_CONTROL;
data[1] = (short)FIFO_CONTROL;
data[2] = (short)DATA_SELECT;
data[3] = (short)LCA_CONTROL;
status = itc->output_word_string(itc, itc->port_latch, 4, data);
}
	
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		if(itc->ITC18_AllocateMemoryB != NULL)
			free(itc->ITC18_AllocateMemoryB);

		if(itc->InterfaceInterface != NULL)
			{
			CFRunLoopRemoveSource(CFRunLoopGetCurrent(), itc->cfSource, kCFRunLoopDefaultMode);

			(*itc->InterfaceInterface)->USBInterfaceClose(itc->InterfaceInterface);
			(*itc->InterfaceInterface)->Release(itc->InterfaceInterface);
			itc->InterfaceInterface = NULL;
			}
                
		if(itc->DeviceInterface != NULL)
			{
			kr = (*itc->DeviceInterface)->USBDeviceClose(itc->DeviceInterface);
			kr = (*itc->DeviceInterface)->Release(itc->DeviceInterface);
			itc->DeviceInterface = NULL;
			}
		}
		
	kr = IOServiceClose(itc->ITC18dataPort);
	itc->ITC18dataPort = 0;
        
#endif

	return reference_count;
}


// Function ITC18_GetFIFOOverflow
//
// Return a non-zero value in 'overflow' if FIFO overflow has occurred.

ITC_CALL int ITC18_GetFIFOOverflow(void* device, int* overflow)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	int result;

#ifdef __USE_USB_COMMANDS__
	char buffer[1];

	*overflow = 0;

	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
#ifdef _WINDOWS
		//Read this status periodically in 8051 and request latest state
		itc->myRequest.request = (BYTE) _USB_GETFIFOOVERFLOW;	//Get FIFO Overflow 0xD5
		itc->myRequest.direction = 1;			//INPUT

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&status,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
#endif
#ifdef __APPLE__
		//Read this status periodically in 8051 and request latest state
		itc->myUSBRequest.bRequest = (BYTE) _USB_GETFIFOOVERFLOW;	//Get FIFO Overflow 0xD5
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = buffer;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
#endif
		if(buffer[0] & 0x80)
			*overflow = !0;
		}
	else
#endif
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_STATUS);
		if (status != 0)
			return status;

		status = InputWord(itc, itc->port_data, &result);
		if (status != 0)
			return status;

		if (result & 0x8000)
			*overflow = !0;
		}

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_InitializeAcquisition
//
// Reset the FIFO, and reset all data acquisition fields.

ITC_CALL int ITC18_InitializeAcquisition(void* device)
{
	int mask;
	struct ITC18* itc = (struct ITC18*) device;
	int status;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS
	int return_length;
#endif
#endif

	//Do not initialize if in reset state
	if(itc->initialized == 1)
		return ITC18_STATUS_SUCCESS;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS

	if(//itc->DeviceType == USB18_DEVICE_TYPE && 
		itc->USBVersion >= 0x00020002)
		{
		itc->myRequest.request = (BYTE) _USB_INITIALIZE_ACQ;	//InitializeAcquisition 0xDE
		itc->myRequest.direction = 0;			//OUTPUT

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									NULL,
									0,
									&return_length,
									NULL);
		if (!status)
			return ITC18_STATUS_USB_ERROR;
		}
	else
#endif
#ifdef __APPLE__
        
	if(//itc->DeviceType == USB18_DEVICE_TYPE && 
		itc->USBVersion >= 0x00020002)
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_INITIALIZE_ACQ;	//InitializeAcquisition 0xDE
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = 0;
		itc->myUSBRequest.pData = NULL;

		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		}
	else
#endif
#endif
		{
		status = WaitTXHEM(itc);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, FIFO_CONTROL | FC_FIFO_RESET);
		if (status != 0)
			return status;

//		DelayMicroseconds(5);
		DelayXYZ(itc, 5);

		mask = FIFO_CONTROL | FC_FIFO_ENABLE | FC_STOP_OVR;

		status = OutputWord(itc, itc->port_latch, mask);
		if (status != 0)
			return status;
		}

	itc->data_read = 0;
	itc->data_written = 0;
	itc->initialized = 1;

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_SetRange
//
// The (ITC18_AD_CHANNELS) range values should each be one of the
// ITC18_AD_RANGE constant values.

ITC_CALL int ITC18_SetRange(void* device, int* range)
{
	int mask;
	int channel;
	int status;

	struct ITC18* itc = (struct ITC18*) device;

	// The AD range settings are written to the board in pairs, so advance
	// i through the for loop by two.

	for(channel = 0; channel < ITC18_AD_CHANNELS; channel += 2)
		{
		// channel_mask runs 0x00c0 through 0x00f0 and selects the channel.
		mask = (channel << 3) + 0x00c0;

		// OR in the ranges of the two channels selected by the current
		// value of channel_mask.  The higher numbered channel's range ends up
		// in bits 2 and 3, the lower numbered channel's range in bits 0 and 1.
		mask |= range[channel] | (range[channel+1] << 2);

		status = WaitTXHEM(itc);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, ACQ_CONTROL | mask);
		if (status != 0)
			return status;
		}

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetExternalTriggerMode
//
// Non zero 'transition' triggers on a transition only,
// 'invert' triggers low.

ITC_CALL int ITC18_SetExternalTriggerMode(void* device, int transition, int invert)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
//Mike 12.25.2000 - Fix Dan's Bug of Setting Trigger Mode Back to an original
	int mask = ACQ_CONTROL | 0x0020;

	if (transition)
		mask |= AC_EXTERNAL_TRIGGER_TRANSITION;

	if (invert)
		mask |= AC_EXTERNAL_TRIGGER_INVERT;

	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, mask);
	if (status != 0)
		return status;

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_WriteFIFO
//
// Write the contents of the buffer to the FIFO.

ITC_CALL int ITC18_WriteFIFO(void* device, int length, short * buffer)
{
	int status;
	struct ITC18* itc = (struct ITC18*) device;

	if (length <= 0)
		return ITC18_STATUS_WRITE_INVALID;

	itc->initialized = 0;

	if(itc->USBVersion < 0x00050000)
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_WRITE_FIFO_DATA);
		if (status != 0)
			return status;
		}

	status = itc->output_word_string(itc, itc->port_data, length, buffer);
	if (status != 0)
		return status;

	itc->data_written += length;

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_ReadFIFO
//
// Read the contents of the FIFO into the buffer.

ITC_CALL int ITC18_ReadFIFO(void* device, int length, short* target)
{
	int status;

	struct ITC18* itc = (struct ITC18*) device;

#ifdef __MIKE_TEST_TIME__18__
#ifdef _WINDOWS
if(!QueryPerformanceCounter((LARGE_INTEGER*) &Start))
	Start = 0;
#else
Microseconds(&Start);
#endif
#endif

	if (length <= 0)
		return ITC18_STATUS_READ_INVALID;

	itc->initialized = 0;

	if(itc->USBVersion < 0x00050000)
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_FIFO_DATA);
		if (status != 0)
			return status;
		}
//	else
//		itc->USBFIFOFlag = DATA_SELECT | DS_READ_FIFO_DATA;

	status = itc->input_word_string(itc, itc->port_data, length, target);

//	itc->USBFIFOFlag = 0;

	if (status != 0)
		return status;

	itc->data_read += length;

#ifdef __MIKE_TEST_TIME__18__
#ifdef _WINDOWS
if(!QueryPerformanceCounter((LARGE_INTEGER*) &New))
	New = 0;
tTimeRead18[tCounterRead] = (DWORD)(New - Start);
#else
Microseconds(&New);
tTimeRead18[tCounterRead] = New.lo - Start.lo;
#endif
tCounterRead++;
if(tCounterRead > 15)
	tCounterRead = 0;
#endif

	return ITC18_STATUS_SUCCESS;
}


// Function GetFIFOPointer
//
// Return the decoded FIFO pointer.
//
//	size: 0 = 256K FIFO, 1 = 1M FIFO
//
// The low 16 bits of the FIFO pointer are accessed by reading the
// data port after writing DATA_SELECT | DS_READ_FIFO_PTR to the command
// port.  The upper two or four bits are available in bits 0 through
// 3 of the data port after writing DATA_SELECT | DS_READ_STATUS to the
// command port.
static int GetFIFOPointer(struct ITC18* itc, int* pointer)
{
	int low_pointer;
	int high_pointer;
	int status;
	int counter;

	//This function also returns overflow status - use it, instead of calling 
	//separate function
#ifdef _WINDOWS
	char buffer[4];

	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myRequest.request = (BYTE) _USB_GETFIFOPOINTER;	//GetPointer 0xD9
		itc->myRequest.direction = 1;			//INPUT

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									4,
									&low_pointer,
									NULL);
		if (!status)
			return ITC18_STATUS_USB_ERROR;

		low_pointer = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
		high_pointer = (((int)buffer[3] & 0xFF) << 8) | ((int)buffer[2] & 0xFF);
		}
	else
#endif
#ifdef __APPLE__
#ifdef __USE_USB_COMMANDS__
	char buffer[4];

	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_GETFIFOPOINTER;	//GetPointer 0xD9
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = 4;
		itc->myUSBRequest.pData = buffer;
        
		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;

		low_pointer = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
		high_pointer = (((int)buffer[3] & 0xFF) << 8) | ((int)buffer[2] & 0xFF);
		}
	else
#endif
#endif
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_FIFO_PTR);
		if (status != 0)
			return status;

		status = InputWord(itc, itc->port_data, &low_pointer);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_STATUS);
		if (status != 0)
			return status;

		status = InputWord(itc, itc->port_data, &high_pointer);
		if (status != 0)
			return status;
		}

	itc->overflow = high_pointer & 0x8000;
	
	if (itc->fifo_size == ITC18_256K_FIFO) // Form an 18 bit counter.
		{
		// Decode the most significant nine bits.
		high_pointer &= 0x0003;

		high_pointer = (high_pointer << 7) | (low_pointer >> 9);

		high_pointer = FIFO_256K_DECODE_TABLE[high_pointer];

		// Decode the least significant nine bits.

		low_pointer &= 0x1ff;

		low_pointer = FIFO_256K_DECODE_TABLE[low_pointer];
	
		counter = low_pointer | (high_pointer << 9);
		}
	else // Form a 20 bit counter.
		{
		// Decode the most significant ten bits.

		high_pointer &= 0x000f;

		high_pointer = (high_pointer << 6) | (low_pointer >> 10);
                
		high_pointer = FIFO_1M_DECODE_TABLE[high_pointer];

		// Decode the least significant ten bits.

		low_pointer &= 0x3ff;
                
		low_pointer = FIFO_1M_DECODE_TABLE[low_pointer];

		counter = low_pointer | (high_pointer << 10);
		}

	*pointer = counter;

	return ITC18_STATUS_SUCCESS;
}


// Function SetSamplingInterval
//
// Output a 16 bit timer value to the device.
// Non zero 'external_clock' causes the ITC-18 to synchronous with
// an external clock.

ITC_CALL int ITC18_SetSamplingInterval(void* device, int timer_ticks, int external_clock)
{
	int i;
	int status;
	int mask, command = 0;

#ifdef _WINDOWS
	int result;
	char buffer[1];
	int return_length;
#endif
#ifdef __APPLE__
#ifdef __USE_USB_COMMANDS__
	int result;
	char buffer[1];
#endif
#endif

	struct ITC18* itc = (struct ITC18*) device;

	if((itc->external_clock == external_clock) && 
		(itc->interval == timer_ticks))
			return ITC18_STATUS_SUCCESS;

	itc->interval = timer_ticks;

	if(itc->external_clock != external_clock)
		{
		itc->external_clock = external_clock;

		command = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

		if(itc->green_light == 0)
			command |= AC_READY_LIGHT_OFF;
		else
			command |= AC_READY_LIGHT_ON;

		if (itc->latch_digital_inputs)
			command |= AC_LATCH_ENABLE;

		if (itc->external_clock)
			command |= AC_EXTERNAL_CLOCK;
		}

#ifdef _WINDOWS
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myRequest.request = (BYTE) _USB_SETSAMPLING;	//SetSampling 0xD6
		itc->myRequest.direction = 1;			//INPUT
		itc->myRequest.value = (WORD)timer_ticks;
		itc->myRequest.index = (WORD)command;

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
		}
	else
#endif
#ifdef __APPLE__
#ifdef __USE_USB_COMMANDS__
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_SETSAMPLING;	//SetSampling 0xD6
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)timer_ticks;
		itc->myUSBRequest.wIndex = (WORD)command;
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = buffer;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
 			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
		}
	else
#endif
#endif
		{
		// Write the value, four bits at a time.
		for( i = 0; i < sizeof(short)*2; ++i)	
			{
			mask = ACQ_CONTROL | AC_SEND_TIMER_N0 | (i << 4) | (timer_ticks & 0x000f);

			status = WaitTXHEM(itc);
			if (status != 0)
				return status;
			
			status = OutputWord(itc, itc->port_latch, mask);
			if (status != 0)
				return status;
			
			timer_ticks >>= 4;
			}

		if(command != 0)
			{
			// Set the external clock and latch digital inputs bits.
			status = WaitTXHEM(itc);
			if (status != 0)
				return status;

			status = OutputWord(itc, itc->port_latch, command);
			if (status != 0)
				return status;
			}
		}

	return ITC18_STATUS_SUCCESS;
}


// Function SetSequenceInstruction
//
// Write a 16 bit instruction to the sequence RAM.

static int SetSequenceInstruction(struct ITC18* itc, int instruction)
{
	int i;
	int mask;
	int status;

	// Send the 16 bit instruction, 4 bits at a time, the low 4 bits first.
	
	for( i = 0; i < 4; ++i)
		{
		// The i portion of the mask selects the 4 bits being set.
		mask = ACQ_CONTROL | AC_SEND_TIMER_N0 | (i << 4) | (instruction & 0x000f);

		status = WaitTXHEM(itc);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, mask);
		if (status != 0)
			return status;

		instruction >>= 4;
		}

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_Start
//
// Start data acquisition immediately or on external trigger.

ITC_CALL int ITC18_Start(void* device, 
						 int external_trigger, 
						 int output_enable,
						 int stoponoverflow,
						 int reserved)
{
#ifndef _WINDOWS
#pragma unused(reserved)
#endif

	struct ITC18* itc = (struct ITC18*) device;
	int command;
	int mask;
	int status;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS
	int result;
	char buffer[1];
	int return_length;
#endif
#ifdef __APPLE__
	int result;
	char buffer[1];
#endif
#endif

	itc->initialized = 0;

	// Set up the output enable
	mask = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
		
	if(stoponoverflow != 0)
		mask |= FC_STOP_OVR;

	if (!output_enable)
		mask |= FC_DA_INHIBIT;

	command = ACQ_CONTROL;

	// Set digital invertion bits.
	if (itc->invert_digital_inputs)
		command |= AC_INVERT_DIGITAL_INPUTS;

	if (external_trigger & 1)
		command |= AC_ACQ_ON_TRIGGER;
	else
		command |= AC_START_ACQ;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		if(external_trigger & 2)
			itc->myRequest.request = (BYTE) _USB_EXTERNAL_TRIGGER; //Start by trigger 0xE2
		else
			itc->myRequest.request = (BYTE) _USB_START;	//Start 0xD3

		itc->myRequest.direction = 1;			//INPUT
		itc->myRequest.value = (WORD)mask;
		itc->myRequest.index = (WORD)command;

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;

		}
	else
#endif
#ifdef __APPLE__
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		if(external_trigger & 2)
			itc->myUSBRequest.bRequest = (BYTE) _USB_EXTERNAL_TRIGGER; //Start by trigger 0xE2
		else
			itc->myUSBRequest.bRequest = (BYTE) _USB_START;	//Start 0xD3

		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)mask;
		itc->myUSBRequest.wIndex = (WORD)command;
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = buffer;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;

		}
	else
#endif
#endif
		{
		status = OutputWord(itc, itc->port_latch, mask);
		if (status != 0)
			return status;

		// Begin acquisition
		status = WaitTXHEM(itc);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, command);
		}

	return status;
}


// Function ITC18_Stop
//
// Stop any sampling that is in progress.

ITC_CALL int ITC18_Stop(void* device)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	int command;

#ifdef __USE_USB_COMMANDS__
	int result;
	char buffer[1];
	
#ifdef _WINDOWS
	int return_length;
#endif

#endif

	// added command to keep invert bit stable
	command = ACQ_CONTROL | AC_STOP_ACQ;

	// Set digital invertion bits.
	if(itc->invert_digital_inputs)
		command |= AC_INVERT_DIGITAL_INPUTS;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myRequest.request = (BYTE) _USB_STOP;	//Stop 0xD4
		itc->myRequest.direction = 1;			//INPUT
		itc->myRequest.value = (WORD)command;

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
		}
	else
#endif
#ifdef __APPLE__
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_STOP;	//Stop 0xD4
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)command;
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = buffer;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
		}
	else
#endif
#endif
		{
		status = WaitTXHEM(itc);
		if(status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, command);
		}

	return status;
}


//	Function SetSequenceLength
//
//	Write the number of entries in the sequence RAM to the device.

static int SetSequenceLength(struct ITC18* itc, int length)
{
	int i;
	int mask;
	int status;

	// Write the 12 bit sequence length to the device, 4 bits at a time,
	// low 4 bits first.

	for(i = 0; i < 3; ++i)
		{
		mask = ACQ_CONTROL | AC_SEND_SEQL_N0 | i << 4 | (length & 0x000f);

		status = WaitTXHEM(itc);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, mask);
		if (status != 0)
			return status;

		length >>= 4;
		}

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_ReadROM
//
// Read a ROM sector.
// The address must be in the range 0 to ITC18_ROM_SIZE
// and be a multiple of ITC18_ROM_SECTOR_SIZE.
// "data" is assumed to be an array of length ITC18_ROM_SECTOR_SIZE.

ITC_CALL int ITC18_ReadROM(void* device, int address, int size, void* data)
{
	struct ITC18* itc = (struct ITC18*) device;
	unsigned char* byte_data = (unsigned char *) data;
	int value;
	int i;
	int result;

	// The low section of the ROM is reserved for Instrutech.
	// Swap High and Low Part
//Version 4.0 -> DO NOT SWAP. ONLY 4K RESERVED for INSTRUTECH
/*
	if (address < 0 || address >= 2 * ITC18_ROM_SIZE || address % ITC18_ROM_SECTOR_SIZE)
		return ITC18_STATUS_ROM_INVALID_ADDRESS;

	if(address < ITC18_ROM_SIZE)
		address += ITC18_ROM_SIZE;
	else
		address -= ITC18_ROM_SIZE;
*/
	address += 4096;

	if (address < 0 || address >= ITC18_ROM_SIZE || address % ITC18_ROM_SECTOR_SIZE)
		return ITC18_STATUS_ROM_INVALID_ADDRESS;

	//Mike: USB. Need optimization. Move to 8051
	if(size > ITC18_ROM_SECTOR_SIZE)
		size = ITC18_ROM_SECTOR_SIZE;

	for (i = 0; i < size; i++)
		{
		result = ReadROM(itc, address++, &value);
		if (result)
			return result;

		*byte_data++ = value;
		}

	return ITC18_STATUS_SUCCESS;
}

// Function ValidateROM
//
// Validate values written to the ROM.

static int ValidateROM(struct ITC18* itc, int address, int size, unsigned char* data)
{
	int i;
	int value;
	int result;

	// Read from high section.
//Version 4.0 does not use HIGH Section
//	address += ITC18_ROM_SIZE;

	//Mike: USB. Need optimization. Move to 8051
	if(size > ITC18_ROM_SECTOR_SIZE)
		size = ITC18_ROM_SECTOR_SIZE;

	for (i = 0; i < size; i++)
		{
		result = ReadROM(itc, address++, &value);

		if (result)
			return result;

		if (value != *data++)
			return ITC18_STATUS_ROM_WRITE;
		}

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_WriteROM
//
// Write to a ROM sector.
// The address must be in the range 0 to ITC18_ROM_SIZE
// and be a multiple of ITC18_ROM_SECTOR_SIZE.
// All ITC18_ROM_SECTOR_SIZE bytes of the sector must be written at the same time.
// "data" is assumed to be an array of length ITC18_ROM_SECTOR_SIZE.

#define ROM_MODE_ENABLE			0
#define ROM_MODE_ID_ENTRY		1
#define ROM_MODE_ID_EXIT		2
#define ROM_MODE_SECTOR_ERASE	3

int DelayXYZ(void* device, int microseconds)
{
//Hardware Based delay
//each read transaction over PCI bus of PCI-18 takes at least 16 cycles
//each cycle 30 ns, total 480 ns
struct ITC18* itc = (struct ITC18*) device;
int i, status;
int dummy, readnumber;
		
	readnumber = (int)((double)microseconds/0.48 + 0.5);
	for(i = 0; i < readnumber; i++)
		{
		status = InputWord(itc, itc->port_data, &dummy);
		if (status != 0)
			return status;
		}

return ITC18_STATUS_SUCCESS;
}

int WaitROM(void* device, int address)
{
struct ITC18* itc = (struct ITC18*) device;
int status;
int read0, read1;
unsigned long starttime, currenttime;

#ifdef _WINDOWS
	starttime = GetTickCount();
#else
	Delay(0, (unsigned long*)&starttime);
#endif

	for(;;)
		{
		// Read the value0
		status = OutputWord(itc, itc->port_data, address);
		if (status != 0)
			return status;
		status = InputWord(itc, itc->port_data, &read0);
		if (status != 0)
			return status;
		// Read the value1
		status = OutputWord(itc, itc->port_data, address);
		if (status != 0)
			return status;
		status = InputWord(itc, itc->port_data, &read1);
		if (status != 0)
			return status;
		read0 &= 0x40;
		read1 &= 0x40;
		if(read0 == read1)
			return ITC18_STATUS_SUCCESS;
#ifdef _WINDOWS
		currenttime = GetTickCount();
#else
		Delay(0, (unsigned long*)&currenttime);
#endif
		if((currenttime - starttime) > 100)
			return ITC18_STATUS_ROM_TIMEOUT;
		}
}

int SetROMMode(void* device, int mode)
{
struct ITC18* itc = (struct ITC18*) device;
int status;

	status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00AA);
	if (status != 0)
		return status;
	status = OutputWord(itc, itc->port_data, 0x5555);
	if (status != 0)
		return status;
	status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0055);
	if (status != 0)
		return status;
	status = OutputWord(itc, itc->port_data, 0x2AAA);
	if (status != 0)
		return status;
	status = OutputWord(itc, itc->port_data, 0x8000 | 0x2AAA);
	if (status != 0)
		return status;

	switch(mode)
		{
		case ROM_MODE_ENABLE:
			status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00A0);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x5555);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
			break;
		case ROM_MODE_ID_ENTRY:
			status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0090);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x5555);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
			DelayMicroseconds(10);
			break;
		case ROM_MODE_ID_EXIT:
			status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00F0);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x5555);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
			DelayMicroseconds(10);
			break;
		case ROM_MODE_SECTOR_ERASE:
			status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0080);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x5555);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
			break;
		default:
			status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00A0);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x5555);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
			break;
		}

	return status;
}

int GetROMSoftID(void* device, unsigned* SoftID)
{
struct ITC18* itc = (struct ITC18*) device;
int status;
int vendorid;
int deviceid;

	// Load the ITC18LZ LCA.
	status = LoadInterfaceLCA(itc, nonisolated_LCA_write_rom_low);
	if (status != 0)
		return status;

	// Enable EEPROM.
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA);
	if (status != 0)
		return status;

	//Note: Call this function after EEPROM is enable.
	status = SetROMMode(itc, ROM_MODE_ID_ENTRY);
	if (status != 0)
		return status;

	// Disable EEPROM.
 	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
	if (status != 0)
		return status;

	// Set the address to read.
	status = OutputWord(itc, itc->port_data, 0);
	if (status != 0)
		return status;

	// Read the value.
	status = InputWord(itc, itc->port_data, &vendorid);
	if (status != 0)
		return status;

	// Set the address to read.
	status = OutputWord(itc, itc->port_data, 1);
	if (status != 0)
		return status;

	// Read the value.
	status = InputWord(itc, itc->port_data, &deviceid);
	if (status != 0)
		return status;

	*SoftID = ((vendorid & 0xFF) << 8) | (deviceid & 0xFF);

	// Load the ITC18LZ LCA.
	status = LoadInterfaceLCA(itc, nonisolated_LCA_write_rom_low);
	if (status != 0)
		return status;

	// Enable EEPROM.
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA);
	if (status != 0)
		return status;

	status = SetROMMode(itc, ROM_MODE_ID_EXIT);
	if (status != 0)
		return status;

	// Disable EEPROM.
 	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
	return status;
}

ITC_CALL int ITC18_WriteROM(void* device, int address, void* data)
{
	struct ITC18* itc = (struct ITC18*) device;
	unsigned char* byte_data = (unsigned char *) data;
//	int attempt;
	int status;
	int i, j;
	unsigned int SoftID;
	int save_address;

	address += 4096;
	save_address = address;

	if (address < 0 || address >= ITC18_ROM_SIZE || address % ITC18_ROM_SECTOR_SIZE)
		return ITC18_STATUS_ROM_INVALID_ADDRESS;

//Mike:	for (attempt = 0; attempt < ROM_WRITE_RETRY; attempt++)

	status = GetROMSoftID(itc, &SoftID);
	if (status != 0)
		return status;

	//STUB: Set to old ID
	if(SoftID != 0xBFB5)
		SoftID = 0xBF07;

	if(SoftID != 0xBF07 && SoftID != 0xBFB5)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;

	// Load the ITC18LZ LCA.
	status = LoadInterfaceLCA(itc, nonisolated_LCA_write_rom_low);
	if (status != 0)
		return status;

	// Enable EEPROM.
	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_PROG | LC_DATA);
	if (status != 0)
		return status;

	if(SoftID == 0xBF07)	//29EE010 Page ROM
		{
		// Write the data.
		for(i = 0; i < ITC18_ROM_SECTOR_SIZE / ITC18_OLD_ROM_SECTOR_SIZE; i++)
			{

			//Enable software protection.
			status = SetROMMode(itc, ROM_MODE_ENABLE);
			if (status != 0)
				return status;

			for(j = 0; j < ITC18_OLD_ROM_SECTOR_SIZE; j++)
				{
				status = OutputWord(itc, itc->port_latch, 0x9000 | *byte_data++);
				if (status != 0)
					return status;
				status = OutputWord(itc, itc->port_data, 0x7FFF & address);
				if (status != 0)
					return status;
				status = OutputWord(itc, itc->port_data, 0x8000 | address);
				if (status != 0)
					return status;
				address++;
				}

			DelayXYZ(itc, 10000);
			}
		}

	if(SoftID == 0xBFB5)	//39SF010
		{
		//try to erase sector
		status = SetROMMode(itc, ROM_MODE_SECTOR_ERASE);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, 0x9000 | 0x00AA);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x5555);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x8000 | 0x5555);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0055);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x2AAA);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x8000 | 0x2AAA);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, 0x9000 | 0x0030);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, address);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_data, 0x8000 | address);
		if (status != 0)
			return status;

		DelayXYZ(itc, 10000);

		// Write the data.
		for(i = 0; i < ITC18_ROM_SECTOR_SIZE; i++)
			{
			// Enable software protection.
			status = SetROMMode(itc, ROM_MODE_ENABLE);
			if (status != 0)
				return status;

			status = OutputWord(itc, itc->port_latch, 0x9000 | *byte_data++);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x7FFF & address);
			if (status != 0)
				return status;
			status = OutputWord(itc, itc->port_data, 0x8000 | address);
			if (status != 0)
				return status;		

			//Data polling with timeout or just wait 20 mks
//			status = WaitROM(itc, address);
//			if (status != 0)
//				return status;
			DelayXYZ(itc, 20);

			address++;
			}
		}

	// Disable EEPROM.
 	status = OutputWord(itc, itc->port_latch, LCA_CONTROL | LC_DATA);
	if (status != 0)
		return status;

	// A delay of 200 microseconds starts the internal write cycle.
	// The internal write cycle takes 10 ms to complete.

//	DelayMicroseconds(10300);
DelayMicroseconds(10);

	// Check the data.
	address = save_address;
	status = ValidateROM(itc, address, ITC18_ROM_SECTOR_SIZE, (unsigned char *) data);

	if (status == ITC18_STATUS_SUCCESS)
		return ITC18_STATUS_SUCCESS;

	if (status != ITC18_STATUS_ROM_WRITE)
		return status;

	return ITC18_STATUS_ROM_WRITE;
}

// Function ITC18_WriteAuxiliaryDigitalOutput
//
// Write the auxiliary digital outputs asynchronously.

ITC_CALL int ITC18_WriteAuxiliaryDigitalOutput(void* device, int data)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	int i;

#ifdef __USE_USB_COMMANDS__
	if(itc->USBVersion >= 0x00060001)
		{
#ifdef _WINDOWS
		itc->myRequest.request = (BYTE) _USB_WRITE_AUX_OUT;	// ITC18_WriteAuxiliaryDigitalOutput 0xEE
		itc->myRequest.value = (WORD) data;
		itc->myRequest.direction = 0;			//OUTPUT

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									NULL,
									0,
									&i,
									NULL);
		if (!status)
			return ITC18_STATUS_USB_ERROR;
		}
	else
#endif
#ifdef __APPLE__
		itc->myUSBRequest.bRequest = (BYTE) _USB_WRITE_AUX_OUT;	// ITC18_WriteAuxiliaryDigitalOutput 0xEE
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)data;
		itc->myUSBRequest.wLength = 0;
		itc->myUSBRequest.pData = NULL;
		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		}
	else
#endif
#endif
		{
		for(i = 0; i < 16; i++)
			{
			status = OutputWord(itc,
								itc->port_latch,
								LCA_CONTROL | LC_PROG | ((data & 1) << 1));
			if (status != 0)
				return status;

			data >>= 1;
			}

		status = OutputWord(itc,
							itc->port_latch,
							LCA_CONTROL | LC_PROG | LC_RESET);
		if (status != 0)
			return status;
		}


	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetDigitalInputMode
//
// Set the latch and invertion mode for the digital inputs.
// The default settings are non-latched and non-inverted.

ITC_CALL int ITC18_SetDigitalInputMode(void* device, int latch, int invert)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	int mask;

	itc->invert_digital_inputs = invert;
	itc->latch_digital_inputs = latch;

	// We assume the device has been successfully initialized,
	// se we keep the ready light on bit.

	mask = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

	if(itc->green_light == 0)
		mask |= AC_READY_LIGHT_OFF;
	else
		mask |= AC_READY_LIGHT_ON;

	if (latch)
		mask |= AC_LATCH_ENABLE;

	// Check the external clock setting.
	if (itc->external_clock)
		mask |= AC_EXTERNAL_CLOCK;

	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, mask);
	if (status != 0)
		return status;

	mask = ACQ_CONTROL; // | AC_READY_LIGHT_ON;
	if(invert)
		mask |= AC_INVERT_DIGITAL_INPUTS;

	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, mask);
	if (status != 0)
		return status;

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetReadyLight
//
// Turn ON / OFF Ready Light

ITC_CALL int ITC18_SetReadyLight(void* device, int on)
{
	struct ITC18* itc = (struct ITC18*) device;
	int status;
	int mask;

	itc->green_light = on & 0x1;

	mask = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

	if(itc->green_light == 0)
		mask |= AC_READY_LIGHT_OFF;
	else
		mask |= AC_READY_LIGHT_ON;

	if (itc->latch_digital_inputs)
		mask |= AC_LATCH_ENABLE;

	if (itc->external_clock)
		mask |= AC_EXTERNAL_CLOCK;

	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, mask);
	if (status != 0)
		return status;

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_SetSequence
//
// Write (length) instructions into the sequence memory of the device.

ITC_CALL int ITC18_SetSequence(void* device, int length, int* instructions)
{
	struct ITC18* itc = (struct ITC18*) device;

	int entry;
	int mask;
	int status;

#ifdef __USE_USB_COMMANDS__
	char buffer[64];
	int i, command;
	int result;
	int buffersize;
#ifdef _WINDOWS
	int return_length;
#endif
#endif

	if(length > ITC18_SEQUENCE_RAM_SIZE)
		return ITC18_STATUS_WRITE_INVALID;

	i = length << 2;
	if(itc->SequenceLength == length)
		{
		//Check for Sequence itself
		if(memcmp(itc->Sequence, instructions, i) == 0)
			return ITC18_STATUS_SUCCESS;
		}
	
	//Set new Sequence
	itc->SequenceLength = length;
	memcpy(itc->Sequence, instructions, i);
	//Reset sampling to reload it.
	itc->interval = 0;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS

	buffersize = length * sizeof(short);

	if(itc->DeviceType == USB18_DEVICE_TYPE && buffersize < 64)	//Pipe size
		{
		//Reshape buffer from 32 bit to 16 bit
		for(entry = 0, i = 0; entry < length; entry++)
			{
			buffer[i++] = instructions[entry];
			buffer[i++] = instructions[entry] >> 8;
			}

		itc->myRequest.request = (BYTE) _USB_SETSSEQUENCE;	//SetSequence 0xD7
		itc->myRequest.direction = 0;			//Output
											//Call second time?
		itc->myRequest.value = (WORD)length;

		// added command to keep invert bit stable
		command = ACQ_CONTROL | AC_STOP_ACQ;
		// Set digital invertion bits.
		if(itc->invert_digital_inputs)
			command |= AC_INVERT_DIGITAL_INPUTS;
		itc->myRequest.index = (WORD)command;

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									buffersize,
									&return_length,
									NULL);
		if(!result)
			return ITC18_STATUS_USB_ERROR;

/*
		//Check Status
		itc->myRequest.request = (BYTE) 0xD8;	//Check Status
		itc->myRequest.direction = 1;			//Input

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if(!result)
			return ITC18_STATUS_USB_ERROR;

		if(buffer[0] != 1)
			return ITC18_STATUS_TXHEM_TIMEOUT;
*/
		}
	else
#endif
#ifdef __APPLE__

	buffersize = length * sizeof(short);

	if(itc->DeviceType == USB18_DEVICE_TYPE && buffersize < 64)	//Pipe size
		{
		//Reshape buffer from 32 bit to 16 bit
		for(entry = 0, i = 0; entry < length; entry++)
			{
			buffer[i++] = instructions[entry];
			buffer[i++] = instructions[entry] >> 8;
			}

		itc->myUSBRequest.bRequest = (BYTE) _USB_SETSSEQUENCE;	//SetSequence 0xD7
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = buffersize;
		itc->myUSBRequest.pData = buffer;
											//Call second time?
		itc->myUSBRequest.wValue = (WORD)length;

		// added command to keep invert bit stable
		command = ACQ_CONTROL | AC_STOP_ACQ;
		// Set digital invertion bits.
		if(itc->invert_digital_inputs)
			command |= AC_INVERT_DIGITAL_INPUTS;
		itc->myUSBRequest.wIndex = (WORD)command;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		}
        else
#endif
#endif
		{
		// Reset the sequence RAM pointer.
		status = ITC18_Stop(itc);
		if (status != 0)
			return status;

//Mike: Extra Stuff
//		status = WaitTXHEM(itc);
//		if (status != 0)
//			return status;

		// Set the length of the sequence
		status = SetSequenceLength(itc, length);
		if (status != 0)
			return status;

		// Stop the device to reset the sequence counter
		status = ITC18_Stop(itc);
		if (status != 0)
			return status;

//Mike: Extra Stuff
//		status = WaitTXHEM(itc);
//		if (status != 0)
//			return status;

		// Send the sequence to the device
		for(entry = 0; entry < length; ++entry)
			{
			status = SetSequenceInstruction(itc, instructions[entry]);
			if (status != 0)
				return status;

			status = WaitTXHEM(itc);
			if (status != 0)
				return status;

			mask = ACQ_CONTROL | AC_SEQ_WRITE;

			status = OutputWord(itc, itc->port_latch, mask);

			if (status != 0)
				return status;
			}
		}

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_IsClipping
//
// Return the state of the clipping line.  Reading the clipping line
// clears the bit.

ITC_CALL int ITC18_IsClipping(void* device, int* state)
{
	int data;
	int status;

	struct ITC18* itc = (struct ITC18*) device;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS
	int return_length;
	if(//itc->DeviceType == USB18_DEVICE_TYPE && 
		itc->USBVersion >= 0x00020002)
		{
		*state = 0;
		itc->myRequest.request = (BYTE) _USB_IS_CLIPPING;	//IsClipping 0xE4
		itc->myRequest.direction = 1;			//INPUT

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									state,
									1,
									&return_length,
									NULL);
		if (!status)
			return ITC18_STATUS_USB_ERROR;
		}
	else
#endif

#ifdef __APPLE__
	if(//itc->DeviceType == USB18_DEVICE_TYPE && 
		itc->USBVersion >= 0x00020002)
		{
		*state = 0;
		itc->myUSBRequest.bRequest = (BYTE) _USB_IS_CLIPPING;	//IsClipping 0xE4
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = state;

		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		}
	else
#endif

#endif
		{
		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_READ_STATUS);
		if (status != 0)
			return status;

		status = InputWord(itc, itc->port_data, &data);
		if (status != 0)
			return status;

		if (data & STATUS_CLIPERR)
			*state = 1;
		else
			*state = 0;

		status = OutputWord(itc, itc->port_latch, DATA_SELECT | DS_CLIPPING_RESET);
		if (status != 0)
			return status;
		}

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_GetFIFOReadAvailableOverflow
//
// 07.19.04 -> combine 2 function in one

ITC_CALL int ITC18_GetFIFOReadAvailableOverflow(void* device, int* available, int* overflow)
{
	int status;
	struct ITC18* itc = (struct ITC18*) device;

	//Call mother function
	status = ITC18_GetFIFOReadAvailable(device, available);
	*overflow = 0;
	if(itc->overflow != 0)
		*overflow = !0;

	return status;
}

// Function ITC18_GetFIFOReadAvailable
//
// Return the number of acquired samples not yet read out of the FIFO.
// Note that the current FIFO pointer wraps around, and data_read may
// grow without limit.

ITC_CALL int ITC18_GetFIFOReadAvailable(void* device, int* available)
{
	int read_available;
	int pointer;
	int status;

	struct ITC18* itc = (struct ITC18*) device;

	status = GetFIFOPointer(itc, &pointer);
       
	if (status != 0)
		return status;

	read_available = pointer - itc->data_read;
       
	read_available %= itc->fifo_size;

	if (read_available < 0)
		read_available += itc->fifo_size;

	*available = read_available;

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_GetFIFOWriteAvailable
//
// Return the number of FIFO entries available for writing.

ITC_CALL int ITC18_GetFIFOWriteAvailable(void* device, int* available)
{
	int output_data;
	int write_available;

	struct ITC18* itc = (struct ITC18*) device;

	// If the amount of data read exceeds the amount written,
	// the device FIFO has underflowed.

	output_data = itc->data_written - itc->data_read;
	if (output_data < 0)
		return ITC18_STATUS_FIFO_UNDERFLOW;

	// Compute the amount available as the size of the FIFO,
	// less the amount of data waiting to be output in the FIFO.
	write_available = itc->fifo_size - 1 - output_data;

	*available = write_available;

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_GetFIFOSize

ITC_CALL int ITC18_GetFIFOSize(void* device)
{
	struct ITC18* itc = (struct ITC18*) device;

	return itc->fifo_size;
}


// Function ITC18_GetStatusOverflow

ITC_CALL int ITC18_GetStatusOverflow(void* device)
{
#ifndef _WINDOWS
#pragma unused(device)
#endif
	return ITC18_STATUS_FIFO_OVERFLOW;
}

// Selects the register bank for the special DAC shift LCA
// This is only to be used for the EPC-10

ITC_CALL int ITC18_SetBank(void* device, unsigned bank)
{
	int status;
	int mask;
		
	struct ITC18* itc = (struct ITC18*) device;

	mask = ACQ_CONTROL | AC_BANK_SELECT | (bank & 0x1);
		
	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, mask);
	if (status != 0)
		return status;

	return ITC18_STATUS_SUCCESS;
}


// Function ITC18_SetDACShift
// Sets the shift value for DAC's 2 and 3
// Valid shift values, 	0 = No shift
//						1 = 1.25 microseconds
//						2 = 2.50 microseconds
//						3 = 3.75 microseconds

ITC_CALL int ITC18_SetDACShift(void* device, unsigned shift)
{
	int status;
	int mask;
		
	struct ITC18* itc = (struct ITC18*) device;

	status = ITC18_SetBank(itc,1);
	if (status != 0)
		return status;

//	mask = ACQ_CONTROL |  AC_DAC_SHIFT | (shift & 0x3);
		
	mask = ACQ_CONTROL | (shift & 0x3);  //TG 9/22/2000
	
	status = WaitTXHEM(itc);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch, mask);
	if (status != 0)
		return status;

	status = ITC18_SetBank(itc,0);
	if (status != 0)
		return status;

	return ITC18_STATUS_SUCCESS;
}

#ifdef _WINDOWS

// Function ITC18_Release
//
// Release the driver.

ITC_CALL int ITC18_Release(void* device)
{
	struct ITC18* itc = (struct ITC18*) device;
	int result;
	int return_length;
	unsigned long command;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		command = (unsigned long) IOCTL_ITC_RELEASE;
	else
		command = (unsigned long) IOCTL_USB_RELEASE;

	// return_length is required even though the function returns no data.
	result = DeviceIoControl(	itc->file,
								command,
								NULL,
								0,
								NULL,
								0,
								&return_length,
								NULL);
	if (!result)
		return ITC18_STATUS_RELEASE;

return ITC18_STATUS_SUCCESS;
}

// Function ITC18_Reserve
//
// Reserve the driver.

ITC_CALL int ITC18_Reserve(void* device, int* busy)
{
	struct ITC18* itc = (struct ITC18*) device;
	int result;
	int reference_count;
	unsigned long command;
	*busy = 0;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		command = (unsigned long) IOCTL_ITC_RESERVE;
	else
		command = (unsigned long) IOCTL_USB_RESERVE;

	result = DeviceIoControl(	itc->file,
								command,
								NULL,
								0,
								NULL,
								0,
								&reference_count,
								NULL);
	if (!result)
		{
		if (GetLastError() == ERROR_BUSY)
			*busy = 1;
		else
			return ITC18_STATUS_RESERVE;
		}

	return ITC18_STATUS_SUCCESS;
}

#else

// Function ITC18_Release
//
// Release the driver.

ITC_CALL int ITC18_Release(void* device)
{
	struct ITC18* itc = (struct ITC18*) device;

	if (itc->reserve_file)
		{
		FSClose(itc->reserve_file);
		itc->reserve_file = 0;
		}

	return ITC18_STATUS_SUCCESS;
}

// Function ITC18_Reserve
//
// Reserve the driver.

ITC_CALL int ITC18_Reserve(void* device, int* busy)
{
	struct ITC18* itc = (struct ITC18*) device;
	short volume_reference;
	long directory_id;
	int result;
	const unsigned char* name = "\pITC18Reserve";
	OSType creator = (OSType) "????";
	OSType type = (OSType) "TEXT";

	*busy = 0;

	if (itc->reserve_file)
		return ITC18_STATUS_SUCCESS;

	result = FindFolder(kOnSystemDisk,
						kPreferencesFolderType,
						kCreateFolder,
						&volume_reference,
						&directory_id);
	if (result)
		return ITC18_STATUS_PREFERENCES_FOLDER;

	result = HOpen(	volume_reference,
					directory_id,
					name,
					fsWrPerm,
					&itc->reserve_file);
	if (result == permErr || result == opWrErr)
		{
		// File is opened by somebody else.

		itc->reserve_file = 0;
		*busy = 1;
		return ITC18_STATUS_SUCCESS;
		}
	else if (result == fnfErr)
		{
		// Create and open the file.
		result = HCreate(	volume_reference,
							directory_id,
							name,
							creator,
							type);
		if (result)
			return ITC18_STATUS_CREATE_RESERVE_FILE;

		result = HOpen(	volume_reference,
						directory_id,
						name,
						fsWrPerm,
						&itc->reserve_file);
		if (result)
			{
			itc->reserve_file = 0;
			return ITC18_STATUS_OPEN_RESERVE_FILE;
			}

		return ITC18_STATUS_SUCCESS;
		}
	else if (result)
		{
		return ITC18_STATUS_OPEN_RESERVE_FILE;
		}
	
	return ITC18_STATUS_SUCCESS;
}

#endif

//Mike: Allocate Memory
//Function ITC18_AllocateMemory

ITC_CALL int ITC18_AllocateMemory(void* device, int MemorySizeInBytes, void** LinearAddress)
{

	struct ITC18* itc = (struct ITC18*) device;

#ifdef _WINDOWS
	int result;
	unsigned long command;

	OSVERSIONINFO OsVersionInfo;
	int return_length;
	
	OsVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	
	if (!GetVersionEx(&OsVersionInfo))
		return ITC18_STATUS_GET_VERSION;

	if(itc->file == INVALID_HANDLE_VALUE)
		return ITC18_STATUS_DRIVER_OPEN;

	switch (OsVersionInfo.dwPlatformId)
		{
		case VER_PLATFORM_WIN32s:
			return ITC18_STATUS_NOT_IMPLEMENTED;

		case VER_PLATFORM_WIN32_WINDOWS:

		case VER_PLATFORM_WIN32_NT:

			if(itc->DeviceType == PCI18_DEVICE_TYPE)
				command = (unsigned long) IOCTL_ITC_ALLOCATEMEMORY;
			else
				command = (unsigned long) IOCTL_ALLOCATE_MEMORY;

			result = DeviceIoControl(	itc->file,
										command,
										&MemorySizeInBytes,
										sizeof(int),
										LinearAddress,
										sizeof(void**),
										&return_length,
										NULL);
			if(!result)
				return ITC18_STATUS_NOT_IMPLEMENTED;

			if(*LinearAddress == NULL)
				return ITC18_STATUS_NO_MEMORY;
			break;

		default:
			return ITC18_STATUS_NOT_IMPLEMENTED;
		}

#endif

#ifdef _MACINTOSH

//	if (ITC18_AllocateMemoryB==NULL)
//		ITC18_AllocateMemoryB = (void**)calloc(sizeof(void*)*MAX_ITC18_NUMBER,1);

	if (itc->ITC18_AllocateMemoryB != NULL)
		{
//		ITC18_AllocateMemoryB[itc->DeviceNumber] = realloc(ITC18_AllocateMemoryB[itc->DeviceNumber],MemorySizeInBytes);
		}
	else
		{
//		ITC18_AllocateMemoryB[itc->DeviceNumber] = malloc(MemorySizeInBytes);
		
		itc->ITC18_AllocateMemoryB = (*itc->links.pool_allocate_resident)(MemorySizeInBytes,0);
		}
		
	*LinearAddress = itc->ITC18_AllocateMemoryB;
	if (*LinearAddress == NULL)
		return ITC18_STATUS_NO_MEMORY;
		
#endif

#ifdef __APPLE__
/*
	//Mike use for now regular memory allocation. switch to ph. memory later
	if (itc->ITC18_AllocateMemoryB != NULL)
		itc->ITC18_AllocateMemoryB = realloc(itc->ITC18_AllocateMemoryB, MemorySizeInBytes);
	else
		itc->ITC18_AllocateMemoryB = malloc(MemorySizeInBytes);
		
	*LinearAddress = itc->ITC18_AllocateMemoryB;
	if (*LinearAddress == NULL)
		return ITC18_STATUS_NO_MEMORY;
*/
	kern_return_t kernResult;
	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		kernResult = IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
													kITC18AllocateMemory,	// an index to the function in the Kernel.
													1,	// the number of scalar input values.
													1,	// virtual address
													MemorySizeInBytes,
													LinearAddress);
	else
		kernResult = IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
													kUSB18AllocateMemory,	// an index to the function in the Kernel.
													1,	// the number of scalar input values.
													1,	// virtual address
													MemorySizeInBytes,
													LinearAddress);
	if(kernResult != KERN_SUCCESS) 
		return ITC18_STATUS_NO_MEMORY;
 
	if(*LinearAddress == NULL)
		return ITC18_STATUS_NO_MEMORY;               
#endif

	return ITC18_STATUS_SUCCESS;
}

//Mike: Free Memory
//Function ITC18_FreeMemory

ITC_CALL int ITC18_FreeMemory(void* device)
{

	struct ITC18* itc = (struct ITC18*) device;

#ifdef _WINDOWS
	int result;
	unsigned long command;

	OSVERSIONINFO OsVersionInfo;
	int return_length;
	
	OsVersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	
	if (!GetVersionEx(&OsVersionInfo))
		return ITC18_STATUS_GET_VERSION;

	if(itc->file == INVALID_HANDLE_VALUE)
		return ITC18_STATUS_DRIVER_OPEN;

	switch (OsVersionInfo.dwPlatformId)
		{
		case VER_PLATFORM_WIN32s:
			return ITC18_STATUS_NOT_IMPLEMENTED;

		case VER_PLATFORM_WIN32_WINDOWS:

		case VER_PLATFORM_WIN32_NT:

			if(itc->DeviceType == PCI18_DEVICE_TYPE)
				command = (unsigned long) IOCTL_ITC_FREEMEMORY;
			else
				command = (unsigned long) IOCTL_FREEMEMORY;

			result = DeviceIoControl(
									itc->file,
									command,
									NULL,
									0,
									NULL,
									0,
									&return_length,
									NULL
									);

			if(!result)
				return ITC18_STATUS_NOT_IMPLEMENTED;
			break;

		default:
			return ITC18_STATUS_NOT_IMPLEMENTED;
		}

#endif

#ifdef _MACINTOSH

	if (itc->ITC18_AllocateMemoryB == NULL)
		return ITC18_STATUS_NO_MEMORY;

	(*itc->links.pool_deallocate)(itc->ITC18_AllocateMemoryB);
	itc->ITC18_AllocateMemoryB = NULL;

#endif

#ifdef __APPLE__
/*
	//Mike use for now regular memory allocation. switch to ph. memory later
	if (itc->ITC18_AllocateMemoryB == NULL)
		return ITC18_STATUS_NO_MEMORY;

	free(itc->ITC18_AllocateMemoryB);
	itc->ITC18_AllocateMemoryB = NULL;
*/
	kern_return_t kernResult;
	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		kernResult = IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
													kITC18FreeMemory,	// an index to the function in the Kernel.
                                        			0,	// the number of scalar input values.
                                        			0);
	else
		kernResult = IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
                                        			kUSB18FreeMemory,	// an index to the function in the Kernel.
                                        			0,	// the number of scalar input values.
                                        			0);
        
	if(kernResult != KERN_SUCCESS) 
		return ITC18_STATUS_NO_MEMORY;

#endif

return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_ReadPCIROMSector(void* device, int Address, unsigned char* PCIData)
{
	struct ITC18* itc = (struct ITC18*) device;
	int i, status, read;
	unsigned char* data;
	int address;
	
	data = PCIData;
	address = Address;

	//Mike: USB. There are no PCI EEPROM, however USB has it's own EEPROM. ADD
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;
		
	for(i = 0; i < PCI_ROM_SECTOR_SIZE; i++)
		{
		status = OutputWord(itc, itc->port_latch + PORT_PCI, address);

		if (status != 0)
			return status;

		status = InputWord(itc, itc->port_latch + PORT_PCI_DATA, &read);

		*data++ = read;

		if (status != 0)
			return status;

		address++;
		}

   	return ITC18_STATUS_SUCCESS;
}

int ITC18_WaitPCIROM(void* device, int address)
{
struct ITC18* itc = (struct ITC18*) device;
int status;
int read0, read1;
unsigned long starttime, currenttime;

#ifdef _WINDOWS
	starttime = GetTickCount();
#else
	Delay(0, (unsigned long*)&starttime);
#endif

	//Mike: USB. There are no PCI EEPROM, however USB has it's own EEPROM. ADD
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;

	for(;;)
		{
		// Read the value0
		status = OutputWord(itc, itc->port_latch + PORT_PCI, address);
		if (status != 0)
			return status;
		status = InputWord(itc, itc->port_latch + PORT_PCI_DATA, &read0);
		if (status != 0)
			return status;
		// Read the value1
		status = OutputWord(itc, itc->port_latch + PORT_PCI, address);
		if (status != 0)
			return status;
		status = InputWord(itc, itc->port_latch + PORT_PCI_DATA, &read1);
		if (status != 0)
			return status;
		read0 &= 0x40;
		read1 &= 0x40;
		if(read0 == read1)
			return ITC18_STATUS_SUCCESS;
#ifdef _WINDOWS
		currenttime = GetTickCount();
#else
		Delay(0, (unsigned long*)&currenttime);
#endif
		if((currenttime - starttime) > 100)
			return ITC18_STATUS_ROM_TIMEOUT;
		}
}

int ITC18_SetPCIROMMode(void* device, int mode)
{
struct ITC18* itc = (struct ITC18*) device;
int status;

	//Mike: USB. There are no PCI EEPROM, however USB has it's own EEPROM. ADD
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;

	status = OutputWord(itc, itc->port_latch + PORT_PCI, 0x5555);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x80AA);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch + PORT_PCI, 0x2AAA);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x8055);
	if (status != 0)
		return status;

	status = OutputWord(itc, itc->port_latch + PORT_PCI, 0x5555);
	if (status != 0)
		return status;

	switch(mode)
		{
		case ROM_MODE_ENABLE:
			status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x80A0);
			break;
		case ROM_MODE_ID_ENTRY:
			status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x8090);
			DelayMicroseconds(10);
			break;
		case ROM_MODE_ID_EXIT:
			status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x80F0);
			DelayMicroseconds(10);
			break;
		case ROM_MODE_SECTOR_ERASE:
			status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x8080);
			break;
		default:
			status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x80A0);
			break;
		}

	return status;
}

int ITC18_GetPCIROMSoftID(void* device, unsigned* SoftID)
{
struct ITC18* itc = (struct ITC18*) device;
int status;
int vendorid;
int deviceid;

	//Mike: USB. There are no PCI EEPROM, however USB has it's own EEPROM. ADD
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;

	//Note: Call this function after EEPROM is enable.
	status = ITC18_SetPCIROMMode(itc, ROM_MODE_ID_ENTRY);
	if (status != 0)
		return status;

	// Set the address to read.
	status = OutputWord(itc, itc->port_latch + PORT_PCI, 0);
	if (status != 0)
		return status;

	// Read the value.
	status = InputWord(itc, itc->port_latch + PORT_PCI_DATA, &vendorid);
	if (status != 0)
		return status;

	// Set the address to read.
	status = OutputWord(itc, itc->port_latch + PORT_PCI, 1);
	if (status != 0)
		return status;

	// Read the value.
	status = InputWord(itc, itc->port_latch + PORT_PCI_DATA, &deviceid);
	if (status != 0)
		return status;

	*SoftID = ((vendorid & 0xFF) << 8) | (deviceid & 0xFF);

	status = ITC18_SetPCIROMMode(itc, ROM_MODE_ID_EXIT);
	return status;
}


ITC_CALL int ITC18_WritePCIROMSector(void* device, int Address, unsigned char* PCIData)
{
	struct ITC18* itc = (struct ITC18*) device;
	int i, j, status;
	int write;
	unsigned char* data;
	int address;
	unsigned int SoftID;
	
	//Mike: USB. There are no PCI EEPROM, however USB has it's own EEPROM. ADD
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;

	data = PCIData;
	address = Address;

	//Address must be in lower part of EPROM!!!
	if (address < 0 || address >= PCI_ROM_SIZE || address % PCI_ROM_SECTOR_SIZE)
		return ITC18_STATUS_ROM_INVALID_ADDRESS;

	status = ITC18_GetPCIROMSoftID(itc, &SoftID);
	if (status != 0)
		return status;

	//STUB: Set to old ID
	if(SoftID != 0xBFB5)
		SoftID = 0xBF07;

	if(SoftID != 0xBF07 && SoftID != 0xBFB5)
		return ITC18_STATUS_ROM_NOT_SUPPORTED;

	if(SoftID == 0xBF07)
		{
		//Page ROM
		// Write the data.
		for(i = 0; i < PCI_ROM_SECTOR_SIZE / PCI_OLD_ROM_SECTOR_SIZE; i++)
			{
			//Enable software protection.
			status = ITC18_SetPCIROMMode(itc, ROM_MODE_ENABLE);
			if (status != 0)
				return status;

			for(j = 0; j < PCI_OLD_ROM_SECTOR_SIZE; j++)
				{
				status = OutputWord(itc, itc->port_latch + PORT_PCI, address);
				if (status != 0)
					return status;

				write = 0x8000 | (*data++ & 0xFF);
				status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, write);
				if (status != 0)
					return status;

				address++;
				}

			status = ITC18_WaitPCIROM(itc, Address);
			if (status != 0)
				return status;
			}
		}

	if(SoftID == 0xBFB5)
		{
		//try to erase sector
		status = ITC18_SetPCIROMMode(itc, ROM_MODE_SECTOR_ERASE);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch + PORT_PCI, 0x5555);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x80AA);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_latch + PORT_PCI, 0x2AAA);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x8055);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_latch + PORT_PCI, Address);
		if (status != 0)
			return status;
		status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, 0x8030);
		if (status != 0)
			return status;

		status = ITC18_WaitPCIROM(itc, Address);
		if (status != 0)
			return status;

		// Write the data.
		for(i = 0; i < PCI_ROM_SECTOR_SIZE; i++)
			{
			// Enable software protection.
			status = ITC18_SetPCIROMMode(itc, ROM_MODE_ENABLE);
			if (status != 0)
				return status;

			status = OutputWord(itc, itc->port_latch + PORT_PCI, address);
			if (status != 0)
				return status;

			write = 0x8000 | (*data++ & 0xFF);
			status = OutputWord(itc, itc->port_latch + PORT_PCI_DATA, write);
			if (status != 0)
				return status;

			//Data polling with timeout or just wait 20 mks
			status = ITC18_WaitPCIROM(itc, address);
			if (status != 0)
				return status;

			address++;
			}
		}

   	return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_GetPCISerialNumber(void* device, int* SerialNumber)
{
	struct ITC18* itc = (struct ITC18*) device;
	int i, status, read;
	int address;
	

#ifdef _WINDOWS		
//	int nOutput;		// Counter written to bufOutput
//	ULONG ulLength;
//	Usb_Device_Descriptor pvBuffer;
//	GET_STRING_DESCRIPTOR_IN input;
//	Usb_String_Descriptor* myString;
//	PVOID pvStringBuffer;
	address = 0;
#else
	address = PCI_SWAP;
#endif

	*SerialNumber = 0;

	//Mike: USB. There are no PCI EEPROM, however USB has it's own EEPROM.
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
/*Do not get Serial Number from the USB DeviceDescriptor string
		if	(!DeviceIoControl(	itc->file,
								IOCTL_GET_DEVICE_DESCRIPTOR,
								&pvBuffer,
								sizeof (Usb_Device_Descriptor),
								&pvBuffer,
								sizeof (Usb_Device_Descriptor),
								&nOutput,
								NULL)
			)
			return ITC18_STATUS_NOT_IMPLEMENTED;
				
		if(nOutput != sizeof(Usb_Device_Descriptor))
			return ITC18_STATUS_NOT_IMPLEMENTED;

		//pvBuffer.iSerialNumber - String Number (3)
		input.Index = pvBuffer.iSerialNumber;
		input.LanguageId = 27; // From EzMain: NOTE: frameworks ignores it anyway

		pvStringBuffer = malloc (sizeof (Usb_String_Descriptor) + 128);
		if(pvStringBuffer == NULL)
			return ITC18_STATUS_NO_MEMORY;

		if	(!DeviceIoControl(	itc->file,
								IOCTL_GET_STRING_DESCRIPTOR,
								&input,
								sizeof (GET_STRING_DESCRIPTOR_IN),
								pvStringBuffer,
								sizeof (Usb_String_Descriptor),
								(unsigned long *)&nOutput,
								NULL)
			)
			{
			free(pvStringBuffer);
			return ITC18_STATUS_NOT_IMPLEMENTED;
			}

		ulLength = GET_STRING_DESCRIPTOR_LENGTH(pvStringBuffer);

		// Now get the entire descriptor
		pvStringBuffer = realloc (pvStringBuffer, ulLength);
		if(pvStringBuffer == NULL)
			return ITC18_STATUS_NO_MEMORY;


		// Perform the Get-Descriptor IOCTL
		if	(!DeviceIoControl(	itc->file,
								IOCTL_GET_STRING_DESCRIPTOR,
								&input,
								ulLength,
								pvStringBuffer,
								ulLength,
								(unsigned long *)&nOutput,
								NULL)
			)
			{
			free(pvStringBuffer);
			return ITC18_STATUS_NOT_IMPLEMENTED;
			}

		myString = (Usb_String_Descriptor*) pvStringBuffer;
		*SerialNumber = _wtol(myString->bString);
		free(pvStringBuffer);

#else
		*SerialNumber = 0;
#endif
*/
		status = ITC18_GetUSBInfo(itc, NULL, NULL, NULL, (long*)SerialNumber);
		if(status != ITC18_STATUS_SUCCESS)
			return status;
		}
	else
		{
		for(i = 0; i < 4; i++)
			{
			status = OutputWord(itc, itc->port_latch + PORT_PCI, address);

			if (status != 0)
				return status;

			status = InputWord(itc, itc->port_latch + PORT_PCI_DATA, &read);

			*SerialNumber |= (read & 0xFF) << (i * 8);

			if (status != 0)
				return status;

			address++;
			}
		}

   	return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_GetDeviceInfo(void* device, int* DeviceType, int* DeviceNumber)
{
struct ITC18* itc = (struct ITC18*) device;

	if(DeviceType != NULL)
		*DeviceType = itc->DeviceType;
    
	if(DeviceNumber != NULL)
		*DeviceNumber = itc->DeviceNumber;

return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_GetUSBInfo(void* device, long* REVCTL, long* Speed, long* Version, long* SerialNumber)
{
#ifndef _MACINTOSH
int result;
#endif
#ifdef _WINDOWS
int return_length;
#endif

char buffer[8];

struct ITC18* itc = (struct ITC18*) device;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		return ITC18_STATUS_NOT_IMPLEMENTED;
		
#ifdef _WINDOWS

	if((itc->developmentflag & 0x1) == 1)
		{
		buffer[0] = 0;
		buffer[1] = 8;

		buffer[2] = 0;
		buffer[3] = 0;

		buffer[4] = 0;
		buffer[5] = 0;
		buffer[6] = 0;
		buffer[7] = 0;
		}
	else
		{
		itc->myRequest.request = (BYTE)_USB_GETBOX_INFO;	//Request INFO 0xC5
		itc->myRequest.direction = 1;			//INPUT
		itc->myRequest.value = (MAJOR_VERSION << 8) | MINOR_VERSION;
		itc->myRequest.index = itc->ByteOrderFlag;	//Windows (Intel = 0)

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									8,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		}

#endif

#ifdef __APPLE__

	itc->myUSBRequest.bRequest = (BYTE)_USB_GETBOX_INFO;	//Request INFO 0xC5
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wValue = (MAJOR_VERSION << 8) | MINOR_VERSION;
	itc->myUSBRequest.wIndex = itc->ByteOrderFlag;	//MacOSX (PPC = 1 or Intel = 0)
	itc->myUSBRequest.wLength = 8;
	itc->myUSBRequest.pData = buffer;

	result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (result != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif

#ifdef _MACINTOSH
	return ITC18_STATUS_NOT_IMPLEMENTED;
#endif

	if(REVCTL != NULL)
		*REVCTL = (long)buffer[0] & 0xFF;
            
	if(Speed != NULL)
		*Speed = (long)buffer[1] & 0xFF;

	if(Version != NULL)
		*Version = ((long)buffer[3] & 0xFF) << 16 | ((long)buffer[2] & 0xFF);

	if(SerialNumber != NULL)
		*SerialNumber = ((long)buffer[7] & 0xFF) << 24 | ((long)buffer[6] & 0xFF) << 16 | 
								((long)buffer[5] & 0xFF) << 8 | ((long)buffer[4] & 0xFF);

return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_SetUSBDigitalOutput(void* device, int DigitalOutput)
{
int result;
#ifdef _WINDOWS
int return_length;
#endif

struct ITC18* itc = (struct ITC18*) device;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		return ITC18_STATUS_NOT_IMPLEMENTED;
		
#ifdef _WINDOWS

	itc->myRequest.request = (BYTE) _USB_WRITE_SCSI_PORTC;	//Write SCSI Port 0xDB
	itc->myRequest.value = (WORD)DigitalOutput;
	itc->myRequest.direction = 0;			//OUTPUT

	result = DeviceIoControl(	itc->file,
								IOCTL_VENDOR_OR_CLASS_REQUEST ,
								&itc->myRequest,
								sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
								NULL,
								0,
								&return_length,
								NULL);
	if (!result)
		return ITC18_STATUS_USB_ERROR;
		
#endif

#ifdef __APPLE__

	itc->myUSBRequest.bRequest = (BYTE) _USB_WRITE_SCSI_PORTC;	//Write SCSI Port 0xDB
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wValue = (WORD)DigitalOutput;
	itc->myUSBRequest.wLength = 0;
	itc->myUSBRequest.pData = NULL;

	result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (result != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif

#ifdef _MACINTOSH
	return ITC18_STATUS_NOT_IMPLEMENTED;
#endif

            
return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_GetUSBDigitalInput(void* device, int* DigitalInput)
{
int result;
char buffer[2];
#ifdef _WINDOWS
int return_length;
#endif

struct ITC18* itc = (struct ITC18*) device;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		return ITC18_STATUS_NOT_IMPLEMENTED;
		
#ifdef _WINDOWS

	itc->myRequest.request = (BYTE) _USB_READ_SCSI_PORTC;	//Read SCSI Port 0xDA
	itc->myRequest.direction = 1;			//INPUT

	result = DeviceIoControl(	itc->file,
								IOCTL_VENDOR_OR_CLASS_REQUEST ,
								&itc->myRequest,
								sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
								buffer,
								2,
								&return_length,
								NULL);
	if (!result)
		return ITC18_STATUS_USB_ERROR;
		
#endif

#ifdef __APPLE__

	itc->myUSBRequest.bRequest = (BYTE) _USB_READ_SCSI_PORTC;	//Read SCSI Port 0xDA
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wLength = 2;
	itc->myUSBRequest.pData = buffer;

	result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (result != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif

#ifdef _MACINTOSH
	return ITC18_STATUS_NOT_IMPLEMENTED;
#endif

	if(DigitalInput != NULL)
		*DigitalInput = (int)(buffer[0] & 0xFF) | (((int)(buffer[1]) & 0xFF) << 8);
            
return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_SetUSBUserBit(void* device, int Value)
{
int result;
char buffer[2];
#ifdef _WINDOWS
int return_length;
BULK_TRANSFER_CONTROL USBControl;
#endif

struct ITC18* itc = (struct ITC18*) device;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		return ITC18_STATUS_NOT_IMPLEMENTED;

	
	if(itc->USBVersion >= 0x00020006 && itc->USBVersion <= 0x00030000)
		{
		buffer[0] = (BYTE) _USB_SET_RESET_USER_LINE;	//Set User Output 0xDC
		buffer[1] = Value;
#ifdef _WINDOWS

		//Write to PIPE 1
		USBControl.pipeNum = USB18_PIPE1_OUT;
		result = DeviceIoControl(	itc->file,
									IOCTL_BULK_WRITE,
									&USBControl,
									sizeof(BULK_TRANSFER_CONTROL),
									buffer,
									2,
									&return_length, 
									NULL);
		if(!result)
			return ITC18_STATUS_WRITE_ERROR;
		}
	else
		{
		itc->myRequest.request = (BYTE) _USB_SET_RESET_USER_LINE;	//Set User Output 0xDC
		itc->myRequest.value = (WORD)Value;
		itc->myRequest.direction = 0;			//OUTPUT

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									NULL,
									0,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		}
#endif
#ifdef __APPLE__

		//Write to PIPE 1
		result = (*itc->InterfaceInterface)->WritePipeTO(   itc->InterfaceInterface,
															USB18_PIPE1_OUT_MACOSX,
															buffer,
															2,
															1000,
															1000);
		if (result != kIOReturnSuccess)
			{
			(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																USB18_PIPE1_OUT_MACOSX);
			return ITC18_STATUS_WRITE_ERROR;
			}
		}
	else
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_SET_RESET_USER_LINE;	//Set User Output 0xDC
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)Value;
		itc->myUSBRequest.wLength = 0;
		itc->myUSBRequest.pData = NULL;
	
		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		}
#endif

#ifdef _MACINTOSH
	return ITC18_STATUS_NOT_IMPLEMENTED;
#endif

            
return ITC18_STATUS_SUCCESS;
}

//Life Timer
ITC_CALL int ITC18_GetTimer(void* device, LONGLONG* Timer)
{
int result;
char buffer[8];
#ifdef _WINDOWS
int return_length;
#endif

struct ITC18* itc = (struct ITC18*) device;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		return ITC18_STATUS_NOT_IMPLEMENTED;

	if(itc->USBVersion < 0x00020000)
		return ITC18_STATUS_USB_OLD_VERSION;
		
#ifdef _WINDOWS

	itc->myRequest.request = (BYTE) _USB_READ_LIFETIMER;	//Read LifeTimer 0xDF
	itc->myRequest.direction = 1;			//INPUT

	result = DeviceIoControl(	itc->file,
								IOCTL_VENDOR_OR_CLASS_REQUEST ,
								&itc->myRequest,
								sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
								buffer,
								8,
								&return_length,
								NULL);
	if (!result)
		return ITC18_STATUS_USB_ERROR;
		
#endif

#ifdef __APPLE__

	itc->myUSBRequest.bRequest = (BYTE) _USB_READ_LIFETIMER;	//Read LifeTimer 0xDF
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wLength = 8;
	itc->myUSBRequest.pData = buffer;

	result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (result != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif

#ifdef _MACINTOSH
	return ITC18_STATUS_NOT_IMPLEMENTED;
#endif

	if(Timer != NULL)
		*Timer = (LONGLONG)(buffer[0] & 0xFF) | (((LONGLONG)(buffer[1]) & 0xFF) << 8) | 
					(((LONGLONG)(buffer[2]) & 0xFF) << 16) | (((LONGLONG)(buffer[3]) & 0xFF) << 24) |
					(((LONGLONG)(buffer[4]) & 0xFF) << 32) | (((LONGLONG)(buffer[5]) & 0xFF) << 40) |
					(((LONGLONG)(buffer[6]) & 0xFF) << 48) | (((LONGLONG)(buffer[7]) & 0xFF) << 56);
            
return ITC18_STATUS_SUCCESS;
}

//Start/Stop Timer
ITC_CALL int ITC18_GetAcqTimer(void* device, LONGLONG* StartTimer, LONGLONG* StopTimer)
{
int result;
char buffer[16];
#ifdef _WINDOWS
int return_length;
#endif

struct ITC18* itc = (struct ITC18*) device;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		return ITC18_STATUS_NOT_IMPLEMENTED;

	if(itc->USBVersion < 0x00020000)
		return ITC18_STATUS_USB_OLD_VERSION;
		
#ifdef _WINDOWS

	itc->myRequest.request = (BYTE) _USB_READ_S_TIMER;	//Read Start/Stop Timer 0xE0
	itc->myRequest.direction = 1;			//INPUT

	result = DeviceIoControl(	itc->file,
								IOCTL_VENDOR_OR_CLASS_REQUEST ,
								&itc->myRequest,
								sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
								buffer,
								16,
								&return_length,
								NULL);
	if (!result)
		return ITC18_STATUS_USB_ERROR;
		
#endif

#ifdef __APPLE__

	itc->myUSBRequest.bRequest = (BYTE) _USB_READ_S_TIMER;	//Read Start/Stop Timer 0xE0
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wLength = 16;
	itc->myUSBRequest.pData = buffer;

	result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (result != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif

#ifdef _MACINTOSH
	return ITC18_STATUS_NOT_IMPLEMENTED;
#endif

	if(StartTimer != NULL)
		*StartTimer = (LONGLONG)(buffer[0] & 0xFF) | (((LONGLONG)(buffer[1]) & 0xFF) << 8) | 
					(((LONGLONG)(buffer[2]) & 0xFF) << 16) | (((LONGLONG)(buffer[3]) & 0xFF) << 24) |
					(((LONGLONG)(buffer[4]) & 0xFF) << 32) | (((LONGLONG)(buffer[5]) & 0xFF) << 40) |
					(((LONGLONG)(buffer[6]) & 0xFF) << 48) | (((LONGLONG)(buffer[7]) & 0xFF) << 56);
            
	if(StopTimer != NULL)
		*StopTimer = (LONGLONG)(buffer[8] & 0xFF) | (((LONGLONG)(buffer[9]) & 0xFF) << 8) | 
					(((LONGLONG)(buffer[10]) & 0xFF) << 16) | (((LONGLONG)(buffer[11]) & 0xFF) << 24) |
					(((LONGLONG)(buffer[12]) & 0xFF) << 32) | (((LONGLONG)(buffer[13]) & 0xFF) << 40) |
					(((LONGLONG)(buffer[14]) & 0xFF) << 48) | (((LONGLONG)(buffer[15]) & 0xFF) << 56);
            
return ITC18_STATUS_SUCCESS;
}

//Control Timer 1/2 - Event Counter
ITC_CALL int ITC18_ControlTimers(void* device, long Control1, long* Counter1, long Control2, long* Counter2)
{
//Control Format
//Bit 0 - Start(1) / Stop(0 - default)
//Bit 1 - Reset
//Bit 7 - Set Mode:
//Bit 2 - CLK/4(1) / CLK/12(0 - default)
//Bit 3 - Timer(0) / Counter(1 - default)
//For Timer 1 Only:
//Bit 4 - Use GATE (INT1 Should be high). Require hardware modification
//Bit 6:5
//	00 - 13 bit counter
//	01 - 16 bit counter (default)
//	10 - 8 bit counter with autoreload
//	11 - Timer stopped

int result;
char buffer[4];
#ifdef _WINDOWS
int return_length;
#endif

struct ITC18* itc = (struct ITC18*) device;

	if(itc->DeviceType != USB18_DEVICE_TYPE)
		return ITC18_STATUS_NOT_IMPLEMENTED;

	if(itc->USBVersion < 0x00020000)
		return ITC18_STATUS_USB_OLD_VERSION;
		
#ifdef _WINDOWS

	itc->myRequest.request = (BYTE) _USB_CONTROL_TIMERS;	//Control Timer1 0xE1
	itc->myRequest.value = (WORD) Control1;
	itc->myRequest.index = (WORD) Control2;
	itc->myRequest.direction = 1;			//INPUT

	result = DeviceIoControl(	itc->file,
								IOCTL_VENDOR_OR_CLASS_REQUEST ,
								&itc->myRequest,
								sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
								buffer,
								4,
								&return_length,
								NULL);
	if (!result)
		return ITC18_STATUS_USB_ERROR;
		
#endif

#ifdef __APPLE__

	itc->myUSBRequest.bRequest = (BYTE) (BYTE) _USB_CONTROL_TIMERS;	//Control Timer 1/2 0xE1
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wValue = (WORD)Control1;
	itc->myUSBRequest.wIndex = (WORD)Control2;
	itc->myUSBRequest.wLength = 4;
	itc->myUSBRequest.pData = buffer;

	result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (result != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif

#ifdef _MACINTOSH
	return ITC18_STATUS_NOT_IMPLEMENTED;
#endif

	if(Counter1 != NULL)
		*Counter1 = (LONG)(buffer[0] & 0xFF) | (((LONG)(buffer[1]) & 0xFF) << 8);           
           
	if(Counter2 != NULL)
		*Counter2 = (LONG)(buffer[2] & 0xFF) | (((LONG)(buffer[3]) & 0xFF) << 8);           
                    
return ITC18_STATUS_SUCCESS;
}

ITC_CALL int ITC18_StartByTimer(void* device, 
								int external_trigger, 
								int output_enable, 
								int stoponoverflow, 
								int reserved,
								LONGLONG Timer)
{
#ifndef _WINDOWS
#pragma unused(reserved)
#endif

	struct ITC18* itc = (struct ITC18*) device;
	int command;
	int mask;
	int status;
	int i;
	char ctemp;
	char buffer[8];

#ifdef __USE_USB_COMMANDS__
	int result;
#ifdef _WINDOWS
	int return_length;
#endif
#endif

	if(itc->USBVersion < 0x00020000)
		return ITC18_STATUS_USB_OLD_VERSION;

	itc->initialized = 0;

	// Set up the output enable
	mask = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
		
	if(stoponoverflow != 0)
		mask |= FC_STOP_OVR;

	if (!output_enable)
		mask |= FC_DA_INHIBIT;

	command = ACQ_CONTROL;

	// Set digital invertion bits.
	if (itc->invert_digital_inputs)
		command |= AC_INVERT_DIGITAL_INPUTS;

	if (external_trigger & 1)
		command |= AC_ACQ_ON_TRIGGER;
	else
		command |= AC_START_ACQ;

	for(i = 0; i < 8; i++)
		{
		ctemp = (char)(Timer & 0xFF);
		buffer[i] = ctemp;
		Timer = Timer >> 8;
		}

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myRequest.request = (BYTE) _USB_START_BY_TIMER;	//Start by Timer 0xE3

		itc->myRequest.direction = 0;			//OUTPUT
		itc->myRequest.value = (WORD)mask;
		itc->myRequest.index = (WORD)command;

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									8,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;

		return ITC18_STATUS_SUCCESS;
		}
	else
#endif
#ifdef __APPLE__
	if(itc->DeviceType == USB18_DEVICE_TYPE)
		{
		itc->myUSBRequest.bRequest = (BYTE) _USB_START_BY_TIMER;	//Start by Timer 0xE3

		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)mask;
		itc->myUSBRequest.wIndex = (WORD)command;
		itc->myUSBRequest.wLength = 8;
		itc->myUSBRequest.pData = buffer;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;

		return ITC18_STATUS_SUCCESS;
		}
	else
#endif
#endif
		{
		//ADD: Use Windows Timer

		status = OutputWord(itc, itc->port_latch, mask);
		if (status != 0)
			return status;

		// Begin acquisition
		status = WaitTXHEM(itc);
		if (status != 0)
			return status;

		status = OutputWord(itc, itc->port_latch, command);
		}

	return status;
}

typedef struct 
{
   WORD Offset;
} ITC18_ANCHOR_DOWNLOAD_CONTROL;

struct MemSeg
{
	DWORD TAddr; //Target Address
	DWORD HAddr; //Host Address
	DWORD Size;  //block size
	DWORD Stat;  //status
	char* pData; //data bytes
};

#define TGT_IMG_SIZE 0x10000 //64KB (65,536 Byte) target image
#define TGT_SEG_SIZE 16		//16 byte segments
#define MAXSTR 256 // Maximum length of Intel Hex file string
#define MAX_EP0_XFER_SIZE (1024*4) // 4K Control EP0 transfer limit imposed by OS 

typedef struct
{
	DWORD TAddr; //Target Address
	DWORD HAddr; //Host Address
	DWORD Size;  //block size
	DWORD Stat;  //status
	char* pData; //data bytes
}MemSeg;

typedef struct 
{
	CHAR data[TGT_IMG_SIZE]; //target image store
}TMemImg;

typedef struct
{
	TMemImg* pImg;	//pointer to image
	int nSeg;		//segment count
	MemSeg pSeg[TGT_IMG_SIZE/TGT_SEG_SIZE]; //info about segments
}TMemCache;

ITC_CALL int ITC18_LoadUSB(	void* device, 
							int Length,
							char* Data)
{
struct ITC18* itc = (struct ITC18*) device;
unsigned long status;
#ifdef _WINDOWS
VENDOR_REQUEST_IN	myUSBRequest;
unsigned long nBytes;
#endif
ITC18_ANCHOR_DOWNLOAD_CONTROL downloadControl;
char* DataBlock;
int tLength;
#ifdef __APPLE__
char buffer[1];
#endif

TMemCache m_MemCache;	//target mem cache info
TMemImg m_MemImg;		//target memory image

int i, exitflag = 0;
char str[MAXSTR];
unsigned byte;
int curSeg = 0;			// current seg record 
int recType;
unsigned addr = 0;
int cnt;
unsigned int totalRead = 0;
// offsets of fields within record -- may change later due to "spaces" setting
int CNTFIELD  = 1;
int ADDRFIELD = 3;
int RECFIELD  = 7;
int DATAFIELD = 9;
char* ptr;

	//0. Decode Data 
	
	m_MemCache.pImg = &m_MemImg;
	m_MemCache.nSeg = 0;

	tLength = 0;
	for(;;)
		{
		//Read one string
		i = 0;
		while(Data[tLength] != 0x0D)
			{
			str[i++] = Data[tLength++];
			if(i > MAXSTR)	//Check for string length
				return ITC18_STATUS_READ_ERROR;
			if(tLength > Length)	//Check for data length
				return ITC18_STATUS_READ_ERROR;
			}
		tLength++;	//Skip "next line"
		if(Data[tLength++] != 0x0A)
			return ITC18_STATUS_READ_ERROR;
		if(str[0] != ':')
			return ITC18_STATUS_READ_ERROR;
		if(str[1] == ' ')
			{
			CNTFIELD    = 1 + 1;
			ADDRFIELD   = 3 + 2;
			RECFIELD    = 7 + 3;
			DATAFIELD   = 9 + 4;
			}

		sscanf(str+RECFIELD,"%2x",&recType);
		ptr = (char*)m_MemCache.pImg;

		switch(recType)
			{
			case 2: 
				sscanf(str+DATAFIELD,"%4x",&curSeg);
				curSeg *= 0x10;
				break;
			case 0: 
				sscanf(str+CNTFIELD,"%2x",&cnt);
				sscanf(str+ADDRFIELD,"%4x",&addr);
				if(addr >= TGT_IMG_SIZE)	//Check for valid address
					return ITC18_STATUS_READ_ERROR;

				ptr += addr; // get pointer to location in image
			
				if(m_MemCache.nSeg && 
					(m_MemCache.pSeg[m_MemCache.nSeg - 1].TAddr == 
						addr - m_MemCache.pSeg[m_MemCache.nSeg - 1].Size) &&
					(m_MemCache.pSeg[m_MemCache.nSeg - 1].Size + cnt <= MAX_EP0_XFER_SIZE) )
					{ // if the segment is contiguous to the last segment, and it's not too big yet
					m_MemCache.pSeg[m_MemCache.nSeg - 1].Size += cnt; // append to previous segment
					}
				else
					{ // start a new segment
					m_MemCache.pSeg[m_MemCache.nSeg].TAddr = addr;
					m_MemCache.pSeg[m_MemCache.nSeg].Size = cnt;
					m_MemCache.pSeg[m_MemCache.nSeg].pData = ptr;
					m_MemCache.nSeg++;
					}
						
				for(i = 0; i < cnt; i++)
					{
					sscanf(str+DATAFIELD+i*2,"%2x",&byte);
					*(ptr + i) = byte;
					totalRead++;
					}
				break;

			case 1: 
				exitflag = 1;
				break;
			
			default:
				break;
			}
		if(exitflag == 1)
			break;
		}

	//Now let's download it.
	//load all high mem first

	for(i = 0; i < m_MemCache.nSeg; i++)
		{
		if(m_MemCache.pSeg[i].TAddr >= 0x2000)
			{
			//Mike: We should not load above 16K (0x2000 - 8K for older chip)
			return ITC18_STATUS_READ_ERROR;
#ifdef _WINDOWS		
			itc->myRequest.request = (BYTE) 0xA3;

			itc->myRequest.direction = 0;			//OUTPUT
			itc->myRequest.value = (WORD)m_MemCache.pSeg[i].TAddr;
			itc->myRequest.index = (WORD)0;

			status = DeviceIoControl(	itc->file,
										IOCTL_VENDOR_OR_CLASS_REQUEST ,
										&itc->myRequest,
										sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
										m_MemCache.pSeg[i].pData,
										m_MemCache.pSeg[i].Size,
										(unsigned long *)&nBytes,
										NULL);
			if(!status)
				return ITC18_STATUS_USB_ERROR;
#endif
#ifdef __APPLE__
			itc->myUSBRequest.bRequest = (BYTE) 0xA3;

			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
			itc->myUSBRequest.wValue = (WORD)m_MemCache.pSeg[i].TAddr;
			itc->myUSBRequest.wIndex = (WORD)0;
			itc->myUSBRequest.wLength = m_MemCache.pSeg[i].Size;
			itc->myUSBRequest.pData = m_MemCache.pSeg[i].pData;

			status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
																&itc->myUSBRequest);
			if (status != kIOReturnSuccess)
				return ITC18_STATUS_USB_ERROR;
#endif								
			}
		}

	//1. Stop USB
#ifdef _WINDOWS		
	myUSBRequest.bRequest = 0xA0;
	myUSBRequest.wValue = 0xE600;
	myUSBRequest.wIndex = 0x00;
	myUSBRequest.wLength = 0x01;
	myUSBRequest.bData = 1;	//1 - Stop, 0 - Run
	myUSBRequest.direction = 0x00;
				
	status = DeviceIoControl(	itc->file,
								IOCTL_VENDOR_REQUEST,
								&myUSBRequest,
								sizeof(VENDOR_REQUEST_IN),
								NULL,
								0,
								(unsigned long *)&nBytes,
								NULL);
	if(!status)
		return ITC18_STATUS_USB_ERROR;
#endif
#ifdef __APPLE__
	itc->myUSBRequest.bRequest = (BYTE) 0xA0;
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wValue = (WORD)0xE600;
	itc->myUSBRequest.wIndex = (WORD)0;
	itc->myUSBRequest.wLength = 1;
	buffer[0] = 1;
	itc->myUSBRequest.pData = buffer;

	status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (status != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif
					
	//2. DOWNLOAD CODE
	for(i = 0; i < m_MemCache.nSeg; i++)
		{ //load all low mem last
//		if(theApp.m_MemCache.pSeg[j].TAddr < 0x2000) mike Change to 16K for LP2
		if(m_MemCache.pSeg[i].TAddr < 0x4000)	
			{
			DataBlock = m_MemCache.pSeg[i].pData;
			tLength = m_MemCache.pSeg[i].Size;
			downloadControl.Offset = (unsigned short)m_MemCache.pSeg[i].TAddr;
#ifdef _WINDOWS			

			status = DeviceIoControl(	itc->file,
										IOCTL_DEVELOPMENT_DOWNLOAD,
										&downloadControl,
										sizeof(ITC18_ANCHOR_DOWNLOAD_CONTROL),
										DataBlock,
										tLength,
										(unsigned long *)&nBytes,
										NULL);
			if(!status)
				return ITC18_STATUS_USB_ERROR;
#endif										
#ifdef __APPLE__
			//We don't have low level command. So let's N chuncks
			itc->myUSBRequest.bRequest = (BYTE) 0xA0;
			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
			itc->myUSBRequest.wIndex = (WORD)0;
			itc->myUSBRequest.wLength = 64;
			itc->myUSBRequest.wValue = downloadControl.Offset;
			itc->myUSBRequest.pData = DataBlock;

			for(cnt = 0; cnt < tLength / 64; cnt++)
				{
				status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
																	&itc->myUSBRequest);
				itc->myUSBRequest.pData += 64;
				itc->myUSBRequest.wValue += 64;
				if (status != kIOReturnSuccess)
					return ITC18_STATUS_USB_ERROR;
				}
				
			tLength = tLength % 64;
			if(tLength != 0)
				{
				itc->myUSBRequest.wLength = tLength;
				
				status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
																	&itc->myUSBRequest);
				if (status != kIOReturnSuccess)
					return ITC18_STATUS_USB_ERROR;
				}
#endif										
			}
		}

	/////////////////////////////////////////////////

	//3. Run 8051
#ifdef _WINDOWS		
	myUSBRequest.bRequest = 0xA0;
	myUSBRequest.wValue = 0xE600;
	myUSBRequest.wIndex = 0x00;
	myUSBRequest.wLength = 0x01;
	myUSBRequest.bData = 0;	//1 - Stop, 0 - Run
	myUSBRequest.direction = 0x00;
				
	status = DeviceIoControl(	itc->file,
								IOCTL_VENDOR_REQUEST,
								&myUSBRequest,
								sizeof(VENDOR_REQUEST_IN),
								NULL,
								0,
								(unsigned long *)&nBytes,
								NULL);
	if(!status)
		return ITC18_STATUS_USB_ERROR;
#endif
#ifdef __APPLE__
	itc->myUSBRequest.bRequest = (BYTE) 0xA0;
	itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
	itc->myUSBRequest.wValue = (WORD)0xE600;
	itc->myUSBRequest.wIndex = (WORD)0;
	itc->myUSBRequest.wLength = 1;
	buffer[0] = 0;
	itc->myUSBRequest.pData = buffer;

	status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
														&itc->myUSBRequest);
	if (status != kIOReturnSuccess)
		return ITC18_STATUS_USB_ERROR;
#endif

return ITC18_STATUS_SUCCESS;
}

#ifdef __APPLE__

ITC_CALL unsigned long ITC18_ReadRegistry(void* device, unsigned long RegID, unsigned long* Value) 
{
struct ITC18* itc = (struct ITC18*) device;
unsigned int index;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		index = kITC18GetRegistry;
	else
		index = kUSB18GetRegistry;
	
	return IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
											index,	// an index to the function in the Kernel.
											1,	// reg id
											1,	// return value
											RegID,
											Value);
}

ITC_CALL unsigned long ITC18_WriteRegistry(void* device, unsigned long RegID, unsigned long Value) 
{
struct ITC18* itc = (struct ITC18*) device;
unsigned int index;

	if(itc->DeviceType == PCI18_DEVICE_TYPE)
		index = kITC18SetRegistry;
	else
		index = kUSB18SetRegistry;
	
	return IOConnectMethodScalarIScalarO(	itc->ITC18dataPort,
											index,	// an index to the function in the Kernel.
											2,	// the number of scalar input values.
											0,	// no output
											RegID,
											Value);
}

#endif

//10.17.2005 Optimization functions

ITC_CALL int ITC18_StopAndInitialize(void* device, int stop, int initialize)
{
struct ITC18* itc = (struct ITC18*) device;
int status = ITC18_STATUS_SUCCESS;
int result, command;
char buffer[1];
	
#ifdef _WINDOWS
	int return_length;
#endif

	if(stop && initialize && 
			(itc->USBVersion >= 0x00020004))
		{
		// added command to keep invert bit stable
		command = ACQ_CONTROL | AC_STOP_ACQ;
		// Set digital invertion bits.
		if(itc->invert_digital_inputs)
			command |= AC_INVERT_DIGITAL_INPUTS;

		itc->data_read = 0;
		itc->data_written = 0;
		itc->initialized = 1;
		
#ifdef _WINDOWS
		itc->myRequest.request = (BYTE) _USB_STOP_INITIALIZE;	//StopAndInitialize 0xE5
		itc->myRequest.direction = 1;			//INPUT
		itc->myRequest.value = (WORD)command;

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
#endif
#ifdef __APPLE__
		itc->myUSBRequest.bRequest = (BYTE) _USB_STOP_INITIALIZE;	//StopAndInitialize 0xE5
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wValue = (WORD)command;
		itc->myUSBRequest.wLength = 1;
		itc->myUSBRequest.pData = buffer;

		result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (result != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;
#endif
		}
	else
		{
		if(stop)
			{
			status = ITC18_Stop(device);
			if(status != ITC18_STATUS_SUCCESS)
				return status;
			}
		if(initialize)	
			status = ITC18_InitializeAcquisition(device);
		}
	return status;
}


ITC_CALL int ITC18_SetupAcquisition(void* device, 
									int stop,
									int initialize, 
									int length, int* instructions,
									int timer_ticks, int external_clock,
									int start,
									int external_trigger, 
									int output_enable,
									int stoponoverflow,
									int reserved)
{
struct ITC18* itc = (struct ITC18*) device;
int status;
int command, sequenceflag;

	int entry;
	int i;
#ifdef _WINDOWS
	int return_length;
#endif
	int buffersize;
	char buffer[64];


	buffersize = length * sizeof(short) + 4 + 4;
					//Sequence + 4 (sampling) + 4 (starting)

	if((buffersize < 64) && 
			(itc->USBVersion >= 0x00020004))
		{
		i = 0;
		//First:  buffer Timer
		buffer[i++] = timer_ticks;				// [0]
		buffer[i++] = timer_ticks >> 8;			// [1]
		//Second: Timer Command
		command = 0;
		if(itc->external_clock != external_clock)
			{
			itc->external_clock = external_clock;

			command = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

			if(itc->green_light == 0)
				command |= AC_READY_LIGHT_OFF;
			else
				command |= AC_READY_LIGHT_ON;

			if (itc->latch_digital_inputs)
				command |= AC_LATCH_ENABLE;

			if (itc->external_clock)
				command |= AC_EXTERNAL_CLOCK;
			}

		buffer[i++] = command;					// [2]
		buffer[i++] = command >> 8;				// [3]

		//Third: Start Data
		command = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
		
		if(stoponoverflow != 0)
			command |= FC_STOP_OVR;

		if (!output_enable)
			command |= FC_DA_INHIBIT;

		buffer[i++] = command;					// [4]
		buffer[i++] = command >> 8;				// [5]

		//Fourth: Start Data
		command = ACQ_CONTROL;

		// Set digital invertion bits.
		if (itc->invert_digital_inputs)
			command |= AC_INVERT_DIGITAL_INPUTS;

		if (external_trigger & 1)
			command |= AC_ACQ_ON_TRIGGER;
		else
			command |= AC_START_ACQ;

		buffer[i++] = command;					// [6]
		buffer[i++] = command >> 8;				// [7]

		if(length > 0)
			{
			sequenceflag = 0;
			if(itc->SequenceLength == length)
				{
				//Check for Sequence itself
				if(memcmp(itc->Sequence, instructions, length << 2) == 0)
					sequenceflag = 1;
				}
			if(sequenceflag == 1)
				length = 0;
			else
				{
				//Set new Sequence
				itc->SequenceLength = length;
				memcpy(itc->Sequence, instructions, length << 2);
				}

			//Reshape sequence buffer from 32 bit to 16 bit
			for(entry = 0; entry < length; entry++)
				{
				buffer[i++] = instructions[entry];
				buffer[i++] = instructions[entry] >> 8;
				}
			}

		//Bit oriented command
		i = 0;
		if(stop)
			i |= 0x01;
		if(initialize)
			{
			if(itc->initialized == 0)
				{
				i |= 0x02;
				itc->initialized = 1;
				itc->data_read = 0;
				itc->data_written = 0;
				}
			}

//		itc->interval = timer_ticks;
		if(timer_ticks > 0)
			{
			if(itc->interval != timer_ticks || length != 0)
				{
				i |= 0x04;
				itc->interval = timer_ticks;
				}
			}
		if(start)
			{
			i |= 0x08;
			itc->initialized = 0;
			}

		//This is STOP Command, used in stop and setsequence
		command = ACQ_CONTROL | AC_STOP_ACQ;
		// Set digital invertion bits.
		if(itc->invert_digital_inputs)
			command |= AC_INVERT_DIGITAL_INPUTS;

#ifdef _WINDOWS
		itc->myRequest.request = (BYTE) _USB_SETUP_ACQUISITON;	//SetupAcquisition 0xE6
		itc->myRequest.direction = 0;			//Output

		itc->myRequest.value = (WORD)((i << 8) | length);
		// added command to keep invert bit stable
		itc->myRequest.index = (WORD)command;

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									buffersize,
									&return_length,
									NULL);
		if(!status)
			return ITC18_STATUS_USB_ERROR;
		
		return ITC18_STATUS_SUCCESS;
#endif
#ifdef __APPLE__

		itc->myUSBRequest.bRequest = (BYTE) _USB_SETUP_ACQUISITON;	//SetupAcquisition 0xE6
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = buffersize;
		itc->myUSBRequest.pData = buffer;
		itc->myUSBRequest.wValue =  (WORD)((i << 8) | length);
		// added command to keep invert bit stable
		itc->myUSBRequest.wIndex = (WORD)command;

		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;

		return ITC18_STATUS_SUCCESS;
#endif
		}
	else
		{
		status = ITC18_STATUS_SUCCESS;
		if(stop)
			{
			status = ITC18_Stop(device);
			if(status != ITC18_STATUS_SUCCESS)
				return status;
			}
		if(initialize)	
			{
			status = ITC18_InitializeAcquisition(device);
			if(status != ITC18_STATUS_SUCCESS)
				return status;
			}

		if(length > 0)
			{
			status = ITC18_SetSequence(device, length, instructions);
			if(status != ITC18_STATUS_SUCCESS)
				return status;
			}

		if(timer_ticks > 0)
			{
			status = ITC18_SetSamplingInterval(device, timer_ticks, external_clock);
			if(status != ITC18_STATUS_SUCCESS)
				return status;
			}

		if(start)
			{
			status = ITC18_Start(	device, 
									external_trigger, 
									output_enable, 
									stoponoverflow,
									reserved);
			}

		}
	return status;
}


ITC_CALL int ITC18_SmallRun(void* device,
							int length, int* instructions,
							int timer_ticks, int external_clock,
							int OutputDataSize, short* OutputData,
							int InputDataSize, short* InputData,
							int external_trigger, int output_enable)
{
struct ITC18* itc = (struct ITC18*) device;
int status;
int available;
unsigned int limit;
int command, sequenceflag;
unsigned long starttime, currenttime;

	int entry;
	int i, j, limit0, limit1;
	unsigned long buffersize;
	char buffer[64];
#ifdef _WINDOWS	
	int return_length;
	BULK_TRANSFER_CONTROL USBControl;
#endif

	limit = max(InputDataSize, OutputDataSize) + 3;

	buffersize = (length + OutputDataSize) * sizeof(short) + 4 + 4 + 2 + 4;
					//(Sequence & Data) + 4 (sampling) + 4 (starting) + 2 (data sizes) + for counter

	if((buffersize < 64) && (InputDataSize < 32) &&
			(itc->USBVersion >= 0x00020005))
		{
		i = 0;
		//First:  buffer Timer
		buffer[i++] = timer_ticks;				// [0]
		buffer[i++] = timer_ticks >> 8;			// [1]
		//Second: Timer Command
		command = 0;
		if(itc->external_clock != external_clock)
			{
			itc->external_clock = external_clock;

			command = ACQ_CONTROL; // | AC_READY_LIGHT_ON;

			if(itc->green_light == 0)
				command |= AC_READY_LIGHT_OFF;
			else
				command |= AC_READY_LIGHT_ON;

			if (itc->latch_digital_inputs)
				command |= AC_LATCH_ENABLE;

			if (itc->external_clock)
				command |= AC_EXTERNAL_CLOCK;
			}

		buffer[i++] = command;					// [2]
		buffer[i++] = command >> 8;				// [3]

		//Third: Start Data
		command = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
		
//		if(stoponoverflow != 0)
			command |= FC_STOP_OVR;

		if (!output_enable)
			command |= FC_DA_INHIBIT;

		buffer[i++] = command;					//[4]
		buffer[i++] = command >> 8;				//[5]

		//Fourth: Start Data
		command = ACQ_CONTROL;

		// Set digital invertion bits.
		if (itc->invert_digital_inputs)
			command |= AC_INVERT_DIGITAL_INPUTS;

		if (external_trigger & 1)
			command |= AC_ACQ_ON_TRIGGER;
		else
			command |= AC_START_ACQ;

		buffer[i++] = command;					// [6]
		buffer[i++] = command >> 8;				// [7]

		//Fifth: Data Sizes
		buffer[i++] = OutputDataSize;			// [8]
		buffer[i++] = InputDataSize;			// [9]

		//Now we need a maximum counter for compare

//Convert limit and "limit + 1" to state
		if (itc->fifo_size == ITC18_256K_FIFO) // Form an 18 bit counter.
			{
			//Actually limit is a small number in this case.
			//limit_low = limit & 0x1FF;

			//Actually limit_high in our case is always 0
			//limit_high = (limit >> 9) & 0x1FF;
			
			//Search the table, untill Arthur gives me the better way
			//Hard code value "0"
			for(j = 0; j < 512; j++)
				{
				if(limit == FIFO_256K_DECODE_TABLE[j])
					{
					limit0 = j;
					break;
					}
				}
			limit++;
			for(j = 0; j < 512; j++)
				{
				if(limit == FIFO_256K_DECODE_TABLE[j])
					{
					limit1 = j;
					break;
					}
				}
			}
		else // Form a 20 bit counter.
			{
			for(j = 0; j < 1024; j++)
				{
				if(limit == FIFO_1M_DECODE_TABLE[j])
					{
					limit0 = j;
					break;
					}
				}
			limit++;
			for(j = 0; j < 1024; j++)
				{
				if(limit == FIFO_1M_DECODE_TABLE[j])
					{
					limit1 = j;
					break;
					}
				}
			}

		buffer[i++] = limit0;			// [10]
		buffer[i++] = limit0 >> 8;		// [11]
		buffer[i++] = limit1;			// [12]
		buffer[i++] = limit1 >> 8;		// [13]

		if(length > 0)
			{
			sequenceflag = 0;
			if(itc->SequenceLength == length)
				{
				//Check for Sequence itself
				if(memcmp(itc->Sequence, instructions, length << 2) == 0)
					sequenceflag = 1;
				}
			if(sequenceflag == 1)
				length = 0;
			else
				{
				//Set new Sequence
				itc->SequenceLength = length;
				memcpy(itc->Sequence, instructions, length << 2);
				}

			//Reshape sequence buffer from 32 bit to 16 bit
			for(entry = 0; entry < length; entry++)
				{
				buffer[i++] = instructions[entry];
				buffer[i++] = instructions[entry] >> 8;
				}
			}

		//Add Data Buffer
		for(entry = 0; entry < OutputDataSize; entry++)
			{
			buffer[i++] = (char)(OutputData[entry]);
			buffer[i++] = (char)(OutputData[entry] >> 8);
			}

		i = 0;
		if(itc->initialized == 0)
			i |= 0x02;
		if(timer_ticks > 0)
			{
			i |= 0x04;
			itc->interval = timer_ticks;
			}

#ifdef __APPLE__
		if(itc->ByteOrderFlag)
			i |= 0x08;	//SWAP Data during FIFORead
#endif

		itc->initialized = 1;
		itc->data_read = 0;
		itc->data_written = 0;

		//This is STOP Command, used in stop and setsequence
		command = ACQ_CONTROL | AC_STOP_ACQ;
		// Set digital invertion bits.
		if(itc->invert_digital_inputs)
			command |= AC_INVERT_DIGITAL_INPUTS;

#ifdef _WINDOWS
		itc->myRequest.request = (BYTE) _USB_SMALL_RUN;	//SmallRun 0xE7
		itc->myRequest.direction = 0;			//Output

		itc->myRequest.value = (WORD)((i << 8) | length);
		// added command to keep invert bit stable
		itc->myRequest.index = (WORD)command;

		status = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									buffersize,
									&return_length,
									NULL);
		if(!status)
			return ITC18_STATUS_USB_ERROR;

		if(InputDataSize > 0)
			{
			USBControl.pipeNum = USB18_PIPE1_IN;	//Read only from EP1. Pipe 5
			//Now We have to read Input from EP1
			status = DeviceIoControl(	itc->file,
										IOCTL_BULK_READ,
										&USBControl,
										sizeof(BULK_TRANSFER_CONTROL),
										InputData,
										InputDataSize << 1,
										&return_length, 
										NULL);
			if (!status)
				return ITC18_STATUS_READ_ERROR;		
			}
		return ITC18_STATUS_SUCCESS;
#endif
#ifdef __APPLE__

		itc->myUSBRequest.bRequest = (BYTE) _USB_SMALL_RUN;	//SmallRun 0xE7
		itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
		itc->myUSBRequest.wLength = buffersize;
		itc->myUSBRequest.pData = buffer;
		itc->myUSBRequest.wValue =  (WORD)((i << 8) | length);
		// added command to keep invert bit stable
		itc->myUSBRequest.wIndex = (WORD)command;

		itc->myUSBRequest.noDataTimeout		= 10000;
		itc->myUSBRequest.completionTimeout	= 10000;
		status = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
															&itc->myUSBRequest);
		itc->myUSBRequest.noDataTimeout		= 1000;
		itc->myUSBRequest.completionTimeout	= 1000;
		if (status != kIOReturnSuccess)
			return ITC18_STATUS_USB_ERROR;

		if(InputDataSize > 0)
			{
			buffersize = InputDataSize << 1;
			status = (*itc->InterfaceInterface)->ReadPipeTO(itc->InterfaceInterface,
															USB18_PIPE1_IN_MACOSX,
															InputData,
															&buffersize,
															1000,
															1000);
                                                        
			if (status != kIOReturnSuccess)
				{
				(*itc->InterfaceInterface)->ClearPipeStallBothEnds(	itc->InterfaceInterface,
																	USB18_PIPE1_IN_MACOSX);
				return ITC18_STATUS_READ_ERROR;
				}
			}
		return ITC18_STATUS_SUCCESS;
#endif
		}
	else
		{
		status = ITC18_InitializeAcquisition(device);
		if(status != ITC18_STATUS_SUCCESS)
			return status;
		if(OutputDataSize > 0)
			{
			status = ITC18_WriteFIFO(device, OutputDataSize, OutputData);
			if(status != ITC18_STATUS_SUCCESS)
				return status;
			}
/*
		status = ITC18_SetSequence(device, length, instructions);
		if(status != ITC18_STATUS_SUCCESS)
			return status;
		status = ITC18_SetSamplingInterval(device, timer_ticks, external_clock);
		if(status != ITC18_STATUS_SUCCESS)
			return status;
		status = ITC18_Start(device, external_trigger, output_enable, 1, 0);
*/
		status = ITC18_SetupAcquisition(device, 
										0,	//int stop,
										0,	//int initialize, 
										length, instructions, 
										timer_ticks, external_clock,
										1,	//int start,
										external_trigger,	//int external_trigger, 
										output_enable,	//int output_enable,
										1,	//int stoponoverflow,
										0);	//int reserved)

	//Wait for result with timeout option
#ifdef _WINDOWS
		starttime = GetTickCount();
#else
		Delay(0, (unsigned long*)&starttime);
#endif

		i = 0;

		do
			{
			status = ITC18_GetFIFOReadAvailableOverflow(device, &available, &command);
			if(command != 0 || status != ITC18_STATUS_SUCCESS)
				{
				//Overflow
				ITC18_StopAndInitialize(device, 1, 1);	
				return ITC18_STATUS_FIFO_OVERFLOW;
				}

#ifdef _WINDOWS
			currenttime = GetTickCount();			//return milliseconds
#else
			Delay(0, (unsigned long*)&currenttime);
#endif
			//Timeout in case counter does not increment for one tick (10ms)
			if((currenttime - starttime) > (timer_ticks * 1.25) + 55)
				{
	//			ITC16_Stop(Info->LocalInfo);	
				ITC18_StopAndInitialize(device, 1, 1);	
				return ITC18_STATUS_ROM_TIMEOUT;
				}
			//Reset timer, if counter increments
			if(i != available)
				{
				i = available;
#ifdef _WINDOWS
				starttime = GetTickCount();
#else
				Delay(0, (unsigned long*)&starttime);
#endif
				}
			}
		while(available < (int)limit);

		if(InputDataSize > 0)
			{
			status = ITC18_ReadFIFO(device, 3, (short*)buffer);
			status = ITC18_ReadFIFO(device, InputDataSize, InputData);
			}
		ITC18_StopAndInitialize(device, 1, 1);
		}
	return status;
}

ITC_CALL int ITC18_SingleWriteROM34(void* device, int Port, int Value)
{
struct ITC18* itc = (struct ITC18*) device;
#ifdef _WINDOWS
ULONG return_length;
#endif
short data;
int result;

		if(itc->USBVersion >= 0x00050000)
			{
#ifdef _WINDOWS
			//Redirect writing to ROM3
			itc->myRequest.request = (BYTE) _USB_A_WRITE_ROM3;		// Actual Write ROM3 0xEA
			itc->myRequest.direction = 0;			//OUTPUT
			itc->myRequest.value = Value;
			itc->myRequest.index = Port;

			result = DeviceIoControl(	itc->file,
										IOCTL_VENDOR_OR_CLASS_REQUEST ,
										&itc->myRequest,
										sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
										NULL,
										0,
										&return_length,
										NULL);
			if (!result)
				return ITC18_STATUS_WRITE_ERROR;
#endif
#ifdef __APPLE__
			//Redirect writing to ROM3
			itc->myUSBRequest.bRequest = (BYTE) _USB_A_WRITE_ROM3;		// Write ROM3 0xEA
			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBOut, kUSBVendor, kUSBDevice);
			itc->myUSBRequest.wValue = Value;
			itc->myUSBRequest.wLength = 0;
			itc->myUSBRequest.wIndex = Port;

#ifdef _USE_CONTROL_REQUEST_
			result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
																&itc->myUSBRequest);
#else
			result = (*itc->InterfaceInterface)->ControlRequest(	itc->InterfaceInterface, 
																	0,
																	&itc->myUSBRequest);
#endif
			if (result != kIOReturnSuccess)
				return ITC18_STATUS_WRITE_ERROR;
#endif
			result = 0;
			}
		else
			{
			data = Value;
			result = itc->output_word_string(itc, Port, 1, &data);
			}
		

	return result;
}

ITC_CALL int ITC18_SingleReadROM4(void* device, short* Value)
{
struct ITC18* itc = (struct ITC18*) device;
#ifdef _WINDOWS
ULONG return_length;
#endif
char buffer[2];
int result;

		if(itc->USBVersion >= 0x00050001)
			{
#ifdef _WINDOWS
			//Redirect writing to ROM3
			itc->myRequest.request = (BYTE) _USB_A_READ_ROM4;		// Read ROM4 0xEC
			itc->myRequest.direction = 1;			//INPUT

			result = DeviceIoControl(	itc->file,
										IOCTL_VENDOR_OR_CLASS_REQUEST ,
										&itc->myRequest,
										sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
										buffer,
										2,
										&return_length,
										NULL);
			if (!result)
				return ITC18_STATUS_WRITE_ERROR;
#endif
#ifdef __APPLE__
			//Redirect writing to ROM3
			itc->myUSBRequest.bRequest = (BYTE) _USB_A_READ_ROM4;		// Read ROM4 0xEC
			itc->myUSBRequest.bmRequestType  = USBmakebmRequestType(kUSBIn, kUSBVendor, kUSBDevice);
			itc->myUSBRequest.wLength = 2;
			itc->myUSBRequest.pData = buffer;

#ifdef _USE_CONTROL_REQUEST_
			result = (*itc->DeviceInterface)->DeviceRequestTO(	itc->DeviceInterface, 
																&itc->myUSBRequest);
#else
			result = (*itc->InterfaceInterface)->ControlRequest(	itc->InterfaceInterface, 
																	0,
																	&itc->myUSBRequest);
#endif
			if (result != kIOReturnSuccess)
				return ITC18_STATUS_WRITE_ERROR;
#endif
			*Value = (((int)buffer[1] & 0xFF) << 8) | ((int)buffer[0] & 0xFF);
			result = 0;
			}
		else
			{
			result = itc->input_word_string(itc, itc->port_data, 1, Value);
			}
		

	return result;
}

///////////////////////////////////////////////////////////////////////
/////////////// USB DC ////////////////////////////////////////////////
ITC_CALL int ITC18_StartUSBDC(	void* device, 
								int external_trigger, 
								int output_enable,
								int stoponoverflow,
								int stoponunderrun)
{
	int command;
	int mask;
	struct ITC18* itc = (struct ITC18*) device;

#ifdef __USE_USB_COMMANDS__
#ifdef _WINDOWS
	int result;
	char buffer[1];
	int return_length;
#endif
#endif


	if(itc->USBVersion < 0x00070000)
		return ITC18_STATUS_USB_ONLY;

	itc->initialized = 0;

	// Set up the output enable
	mask = FIFO_CONTROL | FC_FIFO_ENABLE;	// 1.26.04 | FC_STOP_OVR;
		
	if(stoponoverflow != 0)
		mask |= FC_STOP_OVR;

	if (!output_enable)
		mask |= FC_DA_INHIBIT;

	command = ACQ_CONTROL;

	// Set digital invertion bits.
	if (itc->invert_digital_inputs)
		command |= AC_INVERT_DIGITAL_INPUTS;

	if (external_trigger & 1)
		command |= AC_ACQ_ON_TRIGGER;
	else
		command |= AC_START_ACQ;

#ifdef _WINDOWS
	if(external_trigger & 2)
		itc->myRequest.request = (BYTE) _USB_EXTERNAL_TRIGGER; //Start by trigger 0xE2
	else
itc->myRequest.request = (BYTE) 0xEF;

		itc->myRequest.direction = 1;			//INPUT
		itc->myRequest.value = (WORD)mask;
		itc->myRequest.index = (WORD)command;

		result = DeviceIoControl(	itc->file,
									IOCTL_VENDOR_OR_CLASS_REQUEST ,
									&itc->myRequest,
									sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
									buffer,
									1,
									&return_length,
									NULL);
		if (!result)
			return ITC18_STATUS_USB_ERROR;
		if(buffer[0] == 1)
			return ITC18_STATUS_SUCCESS;
		else
			return ITC18_STATUS_TXHEM_TIMEOUT;

#endif

#ifdef __APPLE__
#endif

	return ITC18_STATUS_SUCCESS;
}


