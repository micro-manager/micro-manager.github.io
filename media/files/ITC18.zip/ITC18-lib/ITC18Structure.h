//Copyright (c), Instrutech Corp.
//10.13.2005
//Internal structure file for the ITC18 driver
//Use to be in ITC18.c file, but needed for different use

struct ITC18
{
	// Low-level hardware access functions
	int (*output_word_string)
		(struct ITC18* itc, int port, int count, short *data);
	int (*input_word_string)
		(struct ITC18* itc, int port, int count, short *data);

	// Access information
	int latch0;
	int latch1;
 	int current_port;

	int port_latch;
	int port_data;
#ifdef __APPLE__
	UInt32 logicalAddr;
	io_connect_t	ITC18dataPort;
#endif        

#ifndef _WINDOWS
	//void** ITC18_AllocateMemoryB = NULL;
	void* ITC18_AllocateMemoryB;
#endif

	// Device information
	int fifo_size;
	int data_read;
	int data_written;

	int overflow;

	// Parameter information
	int interval;
	int invert_digital_inputs;
	int latch_digital_inputs;
	int external_clock;

	//Mike
	int green_light;

#ifdef _WINDOWS
	HANDLE file;
#else
	short reserve_file;
#endif

	int DeviceType;			//Mike 6.23.04 "0" - PCI/ISA, "1" - USB
	int DeviceNumber;

#ifdef __powerc
	// DriverServices library
	struct DynamicLinkStruct links;
	int revision;
#endif

#ifdef __APPLE__
	//MacOSX USB
	IOUSBDeviceInterface197    **DeviceInterface;
	IOUSBInterfaceInterface197 **InterfaceInterface;
//	IOUSBDeviceInterface		**DeviceInterface;
//	IOUSBInterfaceInterface		**InterfaceInterface;
#endif

	//For USB
	unsigned long max_transfer_size;
	int developmentflag;

#ifdef _WINDOWS
	VENDOR_OR_CLASS_REQUEST_CONTROL	myRequest;
#endif

#ifdef __APPLE__
	IOUSBDevRequestTO myUSBRequest;
#endif
	long USBVersion;
	int initialized;
	int USBFIFOFlag;
	int SequenceLength;
#ifndef ITC18_SEQUENCE_RAM_SIZE
#define ITC18_SEQUENCE_RAM_SIZE		4096
#endif
	int Sequence[ITC18_SEQUENCE_RAM_SIZE];

#ifdef __APPLE__
    CFRunLoopSourceRef		cfSource;
#endif
	int ByteOrderFlag;
};

