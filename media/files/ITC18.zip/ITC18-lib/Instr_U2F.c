//03.14.2000
//Create DLL and Static library to use in all drivers to extract
//data from U2F files.
//U2F SubFunctions

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WINDOWS
#include "windows.h"
#include "winioctl.h"
#include <lzexpand.h>
#endif _WINDOWS

#ifdef __APPLE__
#include <zlib.h>
#define __try
#define __except(qqq) if (0)
#define wsprintf sprintf
#endif // __APPLE__

#ifdef macintosh
#include <zlib.h>
#define __try
#define __except(qqq) if (0)
#define wsprintf sprintf
#endif

#include "Instr_U2F.h"

#ifdef _ZLIB_H
#define LZRead(file,buff,size) gzread((file),(buff),(size))
#define LZClose(f) gzclose(f)
#define LZSeek(f,o,w) gzseek(f,(o),(w))
#endif // _ZLIB_H
//****************************************************************
//This function returns Information String
//****************************************************************
INSTR_U2F LONG GetInfoU2F (	LONG SelectID,
							LONG ProductID,
							LONG id,
							LONG SizeOfInfo,
							char* info)
{
LONG Error = U2F_SUCCESS;
char lbuffer[128];

	switch(SelectID)
		{
		case PRODUCT_ID: 
			switch(id)
				{
				case ITC16_PRODUCT:
					strcpy(lbuffer, "ITC16");
					break;
				case ITC18_PRODUCT:
					strcpy(lbuffer, "ITC18");
					break;
				case DVP32_PRODUCT:
					strcpy(lbuffer, "DVP32");
					break;
				case ITC1600_PRODUCT:
					strcpy(lbuffer, "ITC1600");
					break;
				default:
					wsprintf(lbuffer, "This product (%ld) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;

		case FUNCTION_ID:
			switch(ProductID)
				{
				case ITC16_PRODUCT:
					if(id == U2F_ITC16_USB_STANDARD)
						strcpy(lbuffer, "USB16 Standard code");
					else
						{
						wsprintf(lbuffer, "This function (%ld) for ITC16 is not defined", id);
						Error = U2F_ERROR_PARAMETER;
						}
					break;
				case ITC18_PRODUCT:
					switch(id)
						{
						case U2F_ITC18_LCA_PEROM_SYSTEM:
							strcpy(lbuffer, "ITC18 Program system PEROM");
							break;
						case U2F_ITC18_LCA_PEROM_USER:
							strcpy(lbuffer, "ITC18 Program user PEROM");
							break;
						case U2F_ITC18_LCA_BOOTLOADER:
							strcpy(lbuffer, "ITC18 Bootloader Interface");
							break;
						case U2F_ITC18_LCA_ISO_STANDARD:
							strcpy(lbuffer, "ITC18 Standard Isolated");
							break;
						case U2F_ITC18_LCA_ISO_PHSHIFT:
							strcpy(lbuffer, "ITC18 Phase shift Isolated");
							break;
						case U2F_ITC18_LCA_ISO_DYNCLAMP:
							strcpy(lbuffer, "ITC18 Dynamic clamp Isolated");
							break;
						case U2F_ITC18_LCA_COMP_CMOS_256KW:
							strcpy(lbuffer, "ITC18 256K Samples CMOS Interface");
							break;
						case U2F_ITC18_LCA_COMP_CMOS_1MW:
							strcpy(lbuffer, "ITC18 1M Samples CMOS Interface");
							break;
						case U2F_ITC18_LCA_COMP_TTL_1MW:
							strcpy(lbuffer, "ITC18 1M Samples TTL Interface");
							break;
						case U2F_ITC18_LCA_COMP_PCM:
							strcpy(lbuffer, "ITC18 PCM Interface");
							break;
						case U2F_ITC18_USB_STANDARD:
							strcpy(lbuffer, "USB18 Standard code");
							break;
						default:
							wsprintf(lbuffer, "This function (%ld) for ITC18 is not defined", id);
							Error = U2F_ERROR_PARAMETER;
						}
					break;
				case DVP32_PRODUCT:
					switch(id)
						{
						case U2F_DVP32_DSP_BOOTLOADER:
							strcpy(lbuffer, "DVP32 DSP Bootloader code");
							break;
						case U2F_DVP32_DSP_STANDARD:
							strcpy(lbuffer, "DVP32 DSP Standard kernel code");
							break;
						case U2F_DVP32_LCA_CABLE_STANDARD_4:
							strcpy(lbuffer, "DVP32 Standard cable interface");
							break;
						case U2F_DVP32_LCA_DSP_STANDARD_3:
							strcpy(lbuffer, "DVP32 Standard DSP interface");
							break;
						case U2F_DVP32_LCA_SIGNED_STANDARD_1:
							strcpy(lbuffer, "DVP32 Standard Signed pipeline");
							break;
						case U2F_DVP32_LCA_UNSIGNED_STANDARD_1:
							strcpy(lbuffer, "DVP32 Standard Unsigned pipeline");
							break;
						case U2F_DVP32_LCA_OVERLAY_STANDARD_2:
							strcpy(lbuffer, "DVP32 Standard Overlay interface");
							break;
						default:
							wsprintf(lbuffer, "This function (%ld) for DVP32 is not defined", id);
							Error = U2F_ERROR_PARAMETER;
						}
					break;
				case ITC1600_PRODUCT:
					switch(id)
						{
						case U2F_ITC1600_DSP_STANDARD:
							strcpy(lbuffer, "ITC1600 DSP Standard kernel code");
							break;
						case U2F_ITC1600_DSP_EEPROMLOADER:
							strcpy(lbuffer, "ITC1600 DSP Code to Program EEPROM");
							break;
						case U2F_ITC1600_DSP_BOOTLOADER:
							strcpy(lbuffer, "ITC1600 DSP Bootloader Code");
							break;
						case U2F_ITC1600_DSP_SYSTEMLOADER:
							strcpy(lbuffer, "ITC1600 DSP Systemloader Code");
							break;
						case U2F_ITC1600_DSP_TESTER:
							strcpy(lbuffer, "ITC1600 DSP Tester Code");
							break;
						case U2F_ITC1600_DSP_RACKLOADER:
							strcpy(lbuffer, "ITC1600 DSP Rackloader Code");
							break;
						case U2F_ITC1600_DSP_OUTPUTSPECIAL:
							strcpy(lbuffer, "ITC1600 DSP Special Output Code");
							break;
						case U2F_ITC1600_LCA_HOST_STANDARD:
							strcpy(lbuffer, "ITC1600 Standard Host Interface");
							break;
						case U2F_ITC1600_LCA_RACK_STANDARD:
							strcpy(lbuffer, "ITC1600 Standard Rack Interface");
							break;
						default:
							wsprintf(lbuffer, "This function (%ld) for ITC1600 is not defined", id);
							Error = U2F_ERROR_PARAMETER;
						}
					break;
				default:
					wsprintf(lbuffer, "This product (%ld) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;

		case LOCATION_ID:
			switch(ProductID)
				{
				case ITC16_PRODUCT:
					if(id == U2F_ITC16_LOCATION_USB)
						strcpy(lbuffer, "USB16 Microprocessor");
					else
						{
						wsprintf(lbuffer, "This device (%ld) for ITC18 is not defined", id);
						Error = U2F_ERROR_PARAMETER;
						}
					break;
				case ITC18_PRODUCT:
					switch(id)
						{
						case U2F_ITC18_LOCATION_ISO:
							strcpy(lbuffer, "ITC18 Isolated FPGA");
							break;
						case U2F_ITC18_LOCATION_COMP:
							strcpy(lbuffer, "ITC18 Interface FPGA");
							break;
						case U2F_ITC18_LOCATION_USB:
							strcpy(lbuffer, "USB18 Microprocessor");
							break;
						default:
							wsprintf(lbuffer, "This device (%ld) for ITC18 is not defined", id);
							Error = U2F_ERROR_PARAMETER;
						}
					break;
				case DVP32_PRODUCT:
					switch(id)
						{
						case U2F_DVP32_LOCATION_DSP:
							strcpy(lbuffer, "DVP32 DSP");
							break;
						case U2F_DVP32_LOCATION_LCA1:
							strcpy(lbuffer, "DVP32 FPGA 1");
							break;
						case U2F_DVP32_LOCATION_LCA2:
							strcpy(lbuffer, "DVP32 FPGA 2");
							break;
						case U2F_DVP32_LOCATION_LCA3:
							strcpy(lbuffer, "DVP32 FPGA 3");
							break;
						case U2F_DVP32_LOCATION_LCA4:
							strcpy(lbuffer, "DVP32 FPGA 4");
							break;
						default:
							wsprintf(lbuffer, "This device (%ld) for DVP32 is not defined", id);
							Error = U2F_ERROR_PARAMETER;
						}
					break;
				case ITC1600_PRODUCT:
					switch(id)
						{
						case U2F_ITC1600_LOCATION_DSP:
							strcpy(lbuffer, "ITC1600 DSP");
							break;
						case U2F_ITC1600_LOCATION_HOST_LCA:
							strcpy(lbuffer, "ITC1600 Host FPGA");
							break;
						case U2F_ITC1600_LOCATION_RACK_LCA:
							strcpy(lbuffer, "ITC1600 Rack FPGA");
							break;
						default:
							wsprintf(lbuffer, "This device (%ld) for ITC1600 is not defined", id);
							Error = U2F_ERROR_PARAMETER;
						}
					break;
				default:
					wsprintf(lbuffer, "This product (%ld) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;

		case DEVICE_ID:
			switch(id)
				{
				case U2F_DEVICE_TYPE_TMS320C32:
					strcpy(lbuffer, "TI DSP TMS320C32");
					break;
				case U2F_DEVICE_TYPE_DSP56301:
					strcpy(lbuffer, "Motorola DSP 56301");
					break;
				case U2F_DEVICE_TYPE_FX2LP:
					strcpy(lbuffer, "Cypress FX2LP");
					break;
				case U2F_DEVICE_TYPE_3190A:
					strcpy(lbuffer, "Xilinx FPGA 3190A");
					break;
				case U2F_DEVICE_TYPE_3195A:
					strcpy(lbuffer, "Xilinx FPGA 3195A");
					break;
				case U2F_DEVICE_TYPE_4005XL:
					strcpy(lbuffer, "Xilinx FPGA 4005XL");
					break;
				case U2F_DEVICE_TYPE_4013XL:
					strcpy(lbuffer, "Xilinx FPGA 4013XL");
					break;
				case U2F_DEVICE_TYPE_XCS30XL:
					strcpy(lbuffer, "Xilinx FPGA XCS30XL");
					break;
				default:
					wsprintf(lbuffer, "This device (%ld) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;

		case SPEED_ID:
			switch(id)
				{
				case U2F_DEVICE_SPEED_40MHZ:
					strcpy(lbuffer, "40 MHz");
					break;
				case U2F_DEVICE_SPEED_80MHZ:
					strcpy(lbuffer, "80 MHz");
					break;
				case U2F_DEVICE_SPEED_100MHZ:
					strcpy(lbuffer, "100 MHz");
					break;
				case U2F_DEVICE_SPEED_48MHZ:
					strcpy(lbuffer, "48 MHz");
					break;
				case U2F_DEVICE_XILINX_5:
					strcpy(lbuffer, "XILINX -5");
					break;
				case U2F_DEVICE_XILINX_4:
					strcpy(lbuffer, "XILINX -4");
					break;
				case U2F_DEVICE_XILINX_3:
					strcpy(lbuffer, "XILINX -3");
					break;
				default:
					wsprintf(lbuffer, "This speed (%ld) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;

		case MEMORY_ID:
			switch(id)
				{
				case U2F_MEMORY_NO:
					strcpy(lbuffer, "No memory required");
					break;
				case U2F_MEMORY_128Kx32:
					strcpy(lbuffer, "Memory: 128Kx32");
					break;
				case U2F_MEMORY_128Kx24:
					strcpy(lbuffer, "Memory: 128Kx24");
					break;
				case U2F_MEMORY_5V_CMOS_256Kx16:
					strcpy(lbuffer, "Memory: 5V CMOS 256Kx16");
					break;
				case U2F_MEMORY_5V_CMOS_1Mx16:
					strcpy(lbuffer, "Memory: 5V CMOS 1Mx16");
					break;
				case U2F_MEMORY_3_3V_TTL_1Mx16:
					strcpy(lbuffer, "Memory: 3.3V TTL 1Mx16");
					break;
				case U2F_MEMORY_4Kx8_INTERNAL:
					strcpy(lbuffer, "Memory: 4Kx8 Internal");
					break;
				case U2F_MEMORY_8Kx8_INTERNAL:
					strcpy(lbuffer, "Memory: 8Kx8 Internal");
					break;
				case U2F_MEMORY_16Kx8_INTERNAL:
					strcpy(lbuffer, "Memory: 16Kx8 Internal");
					break;
				case U2F_MEMORY_32Kx8_INTERNAL:
					strcpy(lbuffer, "Memory: 32Kx8 Internal");
					break;
				default:
					wsprintf(lbuffer, "This memory (%ld) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;

		case ALGORITHM_ID:
			switch(id)
				{
				case U2F_PROGRAM_ALG_NA:
					strcpy(lbuffer, "No special algorithm required");
					break;
				case U2F_PROGRAM_ALG_LCA_STANDARD_SPEED:
					strcpy(lbuffer, "Standard algorithm speed");
					break;
				case U2F_PROGRAM_ALG_LCA_FAST_SPEED:
					strcpy(lbuffer, "Fast algorithm speed");
					break;
				default:
					wsprintf(lbuffer, "This algorithm (%ld) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;

		case ERROR_ID:
			switch(id)
				{
				case U2F_SUCCESS:
					strcpy(lbuffer, "Success");
					break;
				case U2F_ERROR_OPEN:
					strcpy(lbuffer, "Open file error");
					break;
				case U2F_ERROR_READ:
					strcpy(lbuffer, "Read file error");
					break;
				case U2F_ERROR_SEEK:
					strcpy(lbuffer, "Seek file error");
					break;
				case U2F_ERROR_CHECKSUM:
					strcpy(lbuffer, "Checksum error");
					break;
				case U2F_ERROR_CHUNK:
					strcpy(lbuffer, "Chunk error");
					break;
				case U2F_ERROR_VERSION:
					strcpy(lbuffer, "Version error");
					break;
				case U2F_ERROR_PRODUCT:
					strcpy(lbuffer, "Product error");
					break;
				case U2F_ERROR_MEMORY:
					strcpy(lbuffer, "Memory error");
					break;
				case U2F_ERROR_PARAMETER:
					strcpy(lbuffer, "Parameter error");
					break;
				default:
					wsprintf(lbuffer, "This error (0x%lX) is not defined", id);
					Error = U2F_ERROR_PARAMETER;
				}
			break;
		default:
			wsprintf(lbuffer, "This type of ID (%ld) is not defined", SelectID);
			Error = U2F_ERROR_PARAMETER;
		}

	__try
		{
		strncpy(info, lbuffer, min(SizeOfInfo, sizeof(lbuffer)));
		}
	__except(1)
		{
		return U2F_ERROR_MEMORY;
		}

return Error;
}

//****************************************************************
//This function returns Global Header Information
//Checks for Cheksum.
//****************************************************************
INSTR_U2F LONG GetHeaderU2F (char* filename,
							global_u2f_header* header)
{
#ifndef _ZLIB_H
LONG file;
OFSTRUCT myfile;
#else
gzFile file;
#endif
global_u2f_header gheader;
ULONG sum;
LONG Error=U2F_SUCCESS;

	//Open Compressed file
#ifndef _ZLIB_H
	if((file=LZOpenFile(filename,&myfile,OF_READ)) < 0)
		return U2F_ERROR_OPEN;
#else
	file = gzopen(filename,"rb");
	if (file == NULL)
		return U2F_ERROR_OPEN;
#endif
	//Read global header to fileout
	if( LZRead(file,(char*)&gheader,sizeof(gheader)) !=
				sizeof(gheader))
				{
				Error = U2F_ERROR_READ;
				goto EX;
				}

	//Check Global Header CheckSum
	sum =	gheader.Version        +
			gheader.ProductCode    +								
			gheader.NumberOfChunks +
			CHECKSUM_ADD;

	if(gheader.VersionChecksum != sum)
		{
		Error = U2F_ERROR_CHECKSUM;
		goto EX;
		}

	__try
		{
		CopyMemory(header, &gheader, sizeof(gheader));
		}
	__except(1)
		{
		Error = U2F_ERROR_MEMORY;
		}
EX:
	LZClose(file);
	return Error;
}

//****************************************************************
// This function to get size for data
// Decode U2F file / check data
// Get version and data
// Input:	Number of Chunks to extract
//			Local headers for this chunks 
// Output: Version of U2F , Size for Data
// Use lversion to check if Chunk is present
//****************************************************************
INSTR_U2F LONG GetSizeU2F(	char* filename, 
							ULONG product,
							ULONG Number,	//Number LCAs/DSPs to extract
							local_u2f_header needlheader[],
							LONG *gversion, //U2F Version
							LONG lversion[], //U2F Version
							LONG psize[]     //Pointers to ByteSize
						 )
{
#ifndef _ZLIB_H
LONG file;
OFSTRUCT myfile;
#else
gzFile file;
#endif
ULONG i,k;
global_u2f_header gheader;
local_u2f_header  lheader;
ULONG sum,temp;
LONG Error=U2F_SUCCESS;

	//Open Compressed file
#ifndef _ZLIB_H
	if((file=LZOpenFile(filename,&myfile,OF_READ)) < 0)
		return U2F_ERROR_OPEN;
#else
	file = gzopen(filename,"rb");
	if (file == NULL)
		return U2F_ERROR_OPEN;
#endif

	//Read global header to fileout
	if( LZRead(file,(char*)&gheader,sizeof(gheader)) !=
				sizeof(gheader))
				{
				Error = U2F_ERROR_READ;
				goto EX;
				}

	//Check Global Header CheckSum
	sum =	gheader.Version        +
			gheader.ProductCode    +								
			gheader.NumberOfChunks +
			CHECKSUM_ADD;

	if(gheader.VersionChecksum != sum)
		{
		Error = U2F_ERROR_CHECKSUM;
		goto EX;
		}

	//Check if this U2F for our PRODUCT
	if(product != -1)
		if(gheader.ProductCode != product)
			{
			Error = U2F_ERROR_PRODUCT;
			goto EX;
			}

	__try
		{
		//Return Version number
		if(gversion != NULL)
			*gversion = gheader.Version;

		//Indicate that chunk is not exist
		for(k = 0; k < Number; k++)
			{
			if(lversion != NULL)
				lversion[k] = -1;
			if(psize != NULL)
				psize[k] = 0;
			}
		}
	__except(1)
		{
		Error = U2F_ERROR_MEMORY;
		goto EX;
		}

	//Read U2F
	for(i = 0; i < gheader.NumberOfChunks; i++)
		{
		//Read local header 
		if( LZRead(file,(char*)&lheader,sizeof(lheader)) !=
				sizeof(lheader))
				{
				Error = U2F_ERROR_READ;
				goto EX;
				}
		
		//Check Local Header CheckSum
		sum =	lheader.Function		+
				lheader.FunctionVersion +
				lheader.Location	    +								
				lheader.Type			+								
				lheader.Speed		    +								
				lheader.Memory		    +								
				lheader.ByteSize		+
				lheader.Algorithm		+
				CHECKSUM_ADD;

		if(lheader.HeaderChecksum != sum)
				{
				Error = U2F_ERROR_CHECKSUM;
				goto EX;
				}

		//find if we need to extract data
		temp = -1;
		__try
			{
			for(k = 0; k < Number; k++)
				{
				//Don't compare checksum
				if(	(needlheader[k].Function == lheader.Function || needlheader[k].Function == -1) &&
					(needlheader[k].FunctionVersion == lheader.FunctionVersion || 
						needlheader[k].FunctionVersion == 0 || needlheader[k].FunctionVersion == -1) &&
					(needlheader[k].Location == lheader.Location || needlheader[k].Location == -1) &&
					(needlheader[k].Type     == lheader.Type	 || needlheader[k].Type     == -1) &&
					(needlheader[k].Speed    == lheader.Speed	 || needlheader[k].Speed    == -1) &&
					(needlheader[k].Memory   == lheader.Memory	 || needlheader[k].Memory   == -1) &&
					(needlheader[k].ByteSize == lheader.ByteSize || 
						needlheader[k].ByteSize == 0 || needlheader[k].ByteSize == -1)&&
					(needlheader[k].Algorithm== lheader.Algorithm|| needlheader[k].Algorithm== -1))
						{
						temp = k;
						break;
						}
				}		
		
			if(temp != -1) //Ours Chunk
				{
				if(psize != NULL)
					psize[temp] = lheader.ByteSize;
				if(lversion != NULL)
					lversion[temp] = lheader.FunctionVersion;
				if(needlheader[k].Function == -1)
					needlheader[k].Function = lheader.Function;
				if(needlheader[k].FunctionVersion == -1)
					needlheader[k].FunctionVersion = lheader.FunctionVersion;
				if(needlheader[k].Location == -1)
					needlheader[k].Location = lheader.Location;
				if(needlheader[k].Type == -1)
					needlheader[k].Type = lheader.Type;
				if(needlheader[k].Speed == -1)
					needlheader[k].Speed = lheader.Speed;
				if(needlheader[k].Memory == -1)
					needlheader[k].Memory = lheader.Memory;
				if(needlheader[k].ByteSize == -1)
					needlheader[k].ByteSize = lheader.ByteSize;
				if(needlheader[k].Algorithm == -1)
					needlheader[k].Algorithm = lheader.Algorithm;
				if(needlheader[k].HeaderChecksum == -1)
					needlheader[k].HeaderChecksum = lheader.HeaderChecksum;
				}	

			}
		__except(1)
			{
			Error = U2F_ERROR_MEMORY;
			goto EX;
			}

		//Skip data
		LZSeek(file,((lheader.ByteSize+3)/4)*4+4,1); // 1 -means current position
		} // End of FOR - number of chunks

EX:
	LZClose(file);
	return Error;
}




//****************************************************************
// Decode U2F file / check data
// Get version and data
// Input:	Number of Chunks to extract
//			Local headers for this chunks 
// Output: data, Version of U2F 
// Use lversion to check if Chunk is present
//****************************************************************
INSTR_U2F LONG DecodeU2F(	char* filename, 
							ULONG product,
							ULONG Number,	//Number LCAs/DSPs to extract
							local_u2f_header needlheader[],
							LONG *gversion, //U2F Version
							LONG lversion[], //U2F Version
							void* pted[]     //Pointers to Data
						)
{
#ifndef _ZLIB_H
LONG file;
OFSTRUCT myfile;
#else
gzFile file;
#endif
ULONG i,j,k;
global_u2f_header gheader;
local_u2f_header  lheader;
ULONG sum,temp;
ldiv_t mydiv;
unsigned char c;
BYTE *data;
ULONG local=0;
LONG Error=U2F_SUCCESS;

	//Open Compressed file
#ifndef _ZLIB_H
	if((file=LZOpenFile(filename,&myfile,OF_READ)) < 0)
		return U2F_ERROR_OPEN;
#else
	file = gzopen(filename,"rb");
	if (file == NULL)
		return U2F_ERROR_OPEN;
#endif

	//Read global header to fileout
	if( LZRead(file,(char*)&gheader,sizeof(gheader)) !=
				sizeof(gheader))
				{
				Error = U2F_ERROR_READ;
				goto EX;
				}

	//Check Global Header CheckSum
	sum =	gheader.Version        +
			gheader.ProductCode    +								
			gheader.NumberOfChunks +
			CHECKSUM_ADD;

	if(gheader.VersionChecksum != sum)
		{
		Error = U2F_ERROR_CHECKSUM;
		goto EX;
		}

	//Check if it is DVP32 U2F
	if(product != -1)
		if(gheader.ProductCode != product)
			{
			Error = U2F_ERROR_PRODUCT;
			goto EX;
			}

	__try
		{
		//Return Version number
		if(gversion != NULL)
			*gversion = gheader.Version;

		//Indicate that chunk is not exist
		for(k = 0; k < Number; k++)
			{
			if(lversion != NULL)
				lversion[k] = -1;
			}
		}
	__except(1)
		{
		Error = U2F_ERROR_MEMORY;
		goto EX;
		}

	//Read U2F
	for(i = 0; i < gheader.NumberOfChunks; i++)
		{
		//Read local header 
		if( LZRead(file,(char*)&lheader,sizeof(lheader)) !=
				sizeof(lheader))
				{
				Error = U2F_ERROR_READ;
				goto EX;
				}
		
		
		//Check Local Header CheckSum
		sum =	lheader.Function		+
				lheader.FunctionVersion +
				lheader.Location	    +								
				lheader.Type			+								
				lheader.Speed		    +								
				lheader.Memory		    +								
				lheader.ByteSize		+
				lheader.Algorithm		+
				CHECKSUM_ADD;

		if(lheader.HeaderChecksum != sum)
				{
				Error = U2F_ERROR_CHECKSUM;
				goto EX;
				}

		//find if we need to extract data
		temp = -1;
		__try
			{
			for(k = 0; k < Number; k++)
				{
				//Don't compare checksum
				if(	(needlheader[k].Function == lheader.Function || needlheader[k].Function == -1) &&
					(needlheader[k].FunctionVersion == lheader.FunctionVersion || 
						needlheader[k].FunctionVersion == 0 || needlheader[k].FunctionVersion == -1) &&
					(needlheader[k].Location == lheader.Location || needlheader[k].Location == -1) &&
					(needlheader[k].Type     == lheader.Type	 || needlheader[k].Type     == -1) &&
					(needlheader[k].Speed    == lheader.Speed	 || needlheader[k].Speed    == -1) &&
					(needlheader[k].Memory   == lheader.Memory	 || needlheader[k].Memory   == -1) &&
					((needlheader[k].ByteSize == lheader.ByteSize) || 
						(needlheader[k].ByteSize == 0 || needlheader[k].ByteSize == -1))&&
					(needlheader[k].Algorithm== lheader.Algorithm|| needlheader[k].Algorithm== -1))
						{
						temp = k;
						break;
						}
				}//end of for(k)
		
			if(temp != -1) //Ours Chunk
				{
				if(pted != NULL)
					data = (BYTE*)pted[temp];
				else
					data = NULL;
				if(lversion != NULL)
					lversion[temp] = lheader.FunctionVersion;
				if(needlheader[k].Function == -1)
					needlheader[k].Function = lheader.Function;
				if(needlheader[k].FunctionVersion == -1)
					needlheader[k].FunctionVersion = lheader.FunctionVersion;
				if(needlheader[k].Location == -1)
					needlheader[k].Location = lheader.Location;
				if(needlheader[k].Type == -1)
					needlheader[k].Type = lheader.Type;
				if(needlheader[k].Speed == -1)
					needlheader[k].Speed = lheader.Speed;
				if(needlheader[k].Memory == -1)
					needlheader[k].Memory = lheader.Memory;
				if(needlheader[k].ByteSize == -1)
					needlheader[k].ByteSize = lheader.ByteSize;
				if(needlheader[k].Algorithm == -1)
					needlheader[k].Algorithm = lheader.Algorithm;
				if(needlheader[k].HeaderChecksum == -1)
					needlheader[k].HeaderChecksum = lheader.HeaderChecksum;

				if(data != NULL)
					{
					//Extract Data
					mydiv = ldiv(lheader.ByteSize,4);

					//Copy everything as is to T2F file + calculate check sum
					sum = 0;
					for(j = 0; j < (ULONG)mydiv.quot; j++)
						{
						temp = 0;
						for(k = 0; k < 4; k++)
							{
							//Read one byte
							if(LZRead(file,(char*)&c,1) != 1)
								{
								Error = U2F_ERROR_READ;
								goto EX;
								}
				
							*data++ = (BYTE)(c & 0xFF);
						
							temp |= ((LONG)(c & 0xFF)) << k*8;
							}
						sum += temp;

						} //End of FOR - bytes in file
		
					for(k = 0; k < (ULONG)mydiv.rem; k++)
						{
						temp = 0;
						if(LZRead(file,(char*)&c,1) != 1)
							{
							Error = U2F_ERROR_READ;
							goto EX;
							}

						*data++ = (BYTE)(c & 0xFF);

						temp |= ((LONG)(c & 0xFF)) << k*8;
						}

					sum += temp;
					//This is extra bytes to align to DWORD
					if(mydiv.rem != 0)
						for(k = 0; k < (ULONG)(4-mydiv.rem); k++)
							{
							if(LZRead(file,(char*)&c,1) != 1)
								{
								Error = U2F_ERROR_READ;
								goto EX;
								}
							}

					sum += CHECKSUM_ADD;

					//Read data CheckSum
					if( LZRead(file,(char*)&temp,sizeof(ULONG)) != sizeof(ULONG))
						{
						Error = U2F_ERROR_READ;
						goto EX;
						}
		
					//Check data CheckSum
					if(temp != sum)
						{
						Error = U2F_ERROR_CHECKSUM;
						goto EX;
						}

					//Check if we need more data
					local++;
					if(local >= Number)
						break;
					}
				else	//Data == NULL -> //Skip this chunk
					LZSeek(file,((lheader.ByteSize+3)/4)*4+4,1); // 1 -means current position
				}	
			else	//Skip this chunk
				LZSeek(file,((lheader.ByteSize+3)/4)*4+4,1); // 1 -means current position
			}
		__except(1)
			{
			Error = U2F_ERROR_MEMORY;
			goto EX;
			}

		} // End of FOR - number of chunks

EX:
	LZClose(file);
	return Error;
}

//*******************************************************************************
