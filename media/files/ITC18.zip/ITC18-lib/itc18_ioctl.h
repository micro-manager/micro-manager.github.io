// Control code definitions for kernel-mode driver.
//
// Copyright (c) Instrutech Corporation, 1996
//
// These definitions are used by both the Windows 95 VxD and the
// Windows NT kernel-mode driver. Under Windows NT, the read and
// write operations are performed directly by read and write
// requests, rather than through the DeviceIoControl codes listed
// here.

#define ITC_TYPE (32768+0)

// The function codes must be greater than 0x800 in order to set
// bit 13 in the control code. Bit 13 indicates a custom function code.

#define ITC_FUNCTION_SET_PORT	0x900
#define ITC_FUNCTION_READ		0x901
#define ITC_FUNCTION_WRITE		0x902
#define ITC_FUNCTION_RESERVE	0x903
#define ITC_FUNCTION_RELEASE	0x904

//Mike: add new functions:
#define ITC_FUNCTION_GETVERSION		0x800
#define ITC_FUNCTION_WRITEPCICONFIG	0x801
#define ITC_FUNCTION_READPCICONFIG	0x802
#define ITC_FUNCTION_ALLOCATEMEMORY	0x803
#define ITC_FUNCTION_FREEMEMORY		0x804

// The following definitions are symbolic, based on macros included in
// the Microsoft Windows NT DDK. Unfortunately, the Microsoft Windows 95
// DDK does not contain the same macros. Therefore these symbolic definitions
// cannot be used.
//
//#define IOCTL_ITC_SET_PORT \ 
//    CTL_CODE(ITC_TYPE,  ITC_FUNCTION_SET_PORT, METHOD_BUFFERED, FILE_ANY_ACCESS)
//
//#define IOCTL_ITC_READ \ 
//    CTL_CODE(ITC_TYPE, ITC_FUNCTION_READ, METHOD_IN_DIRECT, FILE_ANY_ACCESS)
//
//#define IOCTL_ITC_WRITE \ 
//    CTL_CODE(ITC_TYPE,  ITC_FUNCTION_WRITE, METHOD_OUT_DIRECT, FILE_ANY_ACCESS)

// The following definitions are equivalent to the symbolic definitions preceding.
// They are constructed from the Windows NT DDK DevIoCtl.h file definitions. These
// definitions must be used, since the symbolic definitions are not available to
// code compiled using the Windows 95 DDK.

#define IOCTL_ITC_SET_PORT \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_SET_PORT << 2) | (0))

#define IOCTL_ITC_READ \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_READ << 2) | (1))

#define IOCTL_ITC_WRITE \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_WRITE << 2) | (2))

#define IOCTL_ITC_RESERVE \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_RESERVE << 2) | (0))

#define IOCTL_ITC_RELEASE \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_RELEASE << 2) | (0))

//Mike
#define IOCTL_ITC_GETVERSION \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_GETVERSION << 2) | (0))

#define IOCTL_ITC_WRITEPCICONFIG \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_WRITEPCICONFIG << 2) | (0))

#define IOCTL_ITC_READPCICONFIG \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_READPCICONFIG << 2) | (0))

#define IOCTL_ITC_ALLOCATEMEMORY \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_ALLOCATEMEMORY << 2) | (0))

#define IOCTL_ITC_FREEMEMORY \
	((ITC_TYPE << 16) | (0 << 14) | (ITC_FUNCTION_FREEMEMORY << 2) | (0))
