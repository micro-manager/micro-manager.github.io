Scion 1394 Camera Library Installation.  

The Scion 1394 camera libraries will be installed in System/Library/Frameworks directory.





